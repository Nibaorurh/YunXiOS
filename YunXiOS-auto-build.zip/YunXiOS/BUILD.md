# 自动构建 iOS IPA

本项目包含 GitHub Actions 工作流：

- 文件：`.github/workflows/build-ios.yml`
- 触发：推送到 `main` / `master`，或在 GitHub Actions 页面手动运行 `Build YunXiOS IPA`
- Runner：`macos-14`
- 构建方式：`xcodebuild`，目标为 `iphoneos`，关闭代码签名
- 产物：Actions 运行完成后，在 **Artifacts → YunXiOS-unsigned-ipa** 下载

## 使用步骤

1. 在 GitHub 新建一个仓库。
2. 把本目录全部文件上传到仓库根目录（包括 `.github` 隐藏目录）。
3. 打开仓库的 **Actions**。
4. 选择 **Build YunXiOS IPA**。
5. 点击 **Run workflow**。
6. 构建成功后，在该次运行页面底部下载 `YunXiOS-unsigned-ipa`。

## 重要说明

这个工作流生成的是**未签名 IPA**。未签名 IPA 不等于已经能在所有设备上安装；TrollStore、越狱安装器以及具体 iOS 版本对可安装格式有自己的要求，必须在目标设备上实际测试。若安装器要求有效签名、特殊 entitlements 或特定打包方式，还需要后续签名/重打包步骤。

当前环境没有 macOS/Xcode，无法在这里直接执行真机 iOS 编译，因此 GitHub Actions 是实际编译验证入口。
