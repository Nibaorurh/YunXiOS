# YunX iOS — 云析 iOS 移植版

这是基于 CYQawa/YunX Android 项目的 iOS 原生移植工程，目标为 **iOS 16.2+**。

## 已包含

- SwiftUI 原生界面：解析 / 下载 / 设置 / 关于
- 分享链接自动识别：夸克、UC、迅雷、百度、139、123 云盘
- 分享目录浏览与文件选择
- 夸克：stoken、分页文件列表、唯一临时转存目录、异步转存、直链、清理目录
- UC：分享 Token、分页列表、转存任务、直链
- 百度：分享校验、文件列表、dlink
- 123 云盘：分享列表和下载接口适配骨架
- 139：分享 AES-CBC 加密接口、目录列表、OBS 预签名直链
- 迅雷：分享列表、文件详情直链；认证字段为 `accessToken|deviceId|captchaToken`
- 下载管理：任务持久化、Range 分片、最多 16 个并发分片、`.part` 断点文件、暂停/继续/删除
- Cookie/JWT 等认证信息持久化
- Web 登录页的 Cookie 提取入口（夸克 / UC / 百度 / 139）

## 打开方式

Mac 上使用 Xcode 15+ 打开：

`YunXiOS.xcodeproj`

目标版本为 iOS 16.2。首次构建需要在 Xcode 的 Signing & Capabilities 中选择你自己的 Team / Bundle Identifier。TrollStore 或越狱安装属于设备侧安装流程，不由源码本身决定。

## 认证说明

设置页可以保存各平台认证信息。

- 夸克 / UC / 百度：优先保存完整 Cookie
- 139：保存原项目使用的认证串（通常需要包含 Authorization）
- 123：保存 Bearer JWT；公共分享浏览可不登录
- 迅雷：保存 `accessToken|deviceId|captchaToken`

## 下载说明

下载器将任务写入 App Support，并使用分片 `.part` 文件实现任务恢复。iOS 的系统后台执行受到系统策略限制；这版优先保证前台高速并发和断点恢复。真正的系统级后台 URLSession 下载代理可以在后续版本继续接入。

## 开源协议

本移植工程包含并基于原 YunX 项目的 **GNU AGPL-3.0** 授权代码/逻辑。请保留许可证与版权声明，并按 AGPL-3.0 要求处理对外分发和修改后的源代码。

原项目：<https://github.com/CYQawa/YunX>
