import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var model: AppModel
    @State private var selected = SharePlatform.quark
    @State private var credential = ""
    @State private var showWebLogin = false
    @State private var showAbout = false
    var body: some View {
        NavigationStack {
            Form {
                Section("认证") {
                    Picker("网盘",selection:$selected){ForEach(SharePlatform.allCases){Text($0.rawValue).tag($0)}}
                    SecureField("Cookie / JWT / accessToken|deviceId|captcha",text:$credential)
                    Button("保存") { model.save(platform:selected,credential:credential); credential="" }
                    if [.quark,.uc,.baidu,.c139].contains(selected) { Button("打开网页登录并提取 Cookie") { showWebLogin=true } }
                    Text(credentialHint).font(.caption).foregroundStyle(.secondary)
                }
                Section("已保存") { ForEach(SharePlatform.allCases) { p in HStack{Text(p.rawValue); Spacer(); Text(model.credential(for:p).isEmpty ? "未配置":"已配置").foregroundStyle(.secondary)} } }
                Section("其它") { Button("关于") { showAbout=true } }
            }.navigationTitle("设置")
        }
        .sheet(isPresented:$showWebLogin){ WebCookieLoginView(platform:selected){ cookie in model.save(platform:selected,credential:cookie); showWebLogin=false } }
        .sheet(isPresented:$showAbout){ AboutView() }
        .onAppear{credential=model.credential(for:selected)}
        .onChange(of: selected) { v in credential = model.credential(for: v) }
    }
    private var credentialHint:String { switch selected { case .quark,.uc,.baidu: return "浏览器登录后点击提取 Cookie；也可手动粘贴完整 Cookie。"; case .c139:return "139 管理接口通常需要包含 Authorization 的认证串；分享浏览可不登录。"; case .pan123:return "123 云盘使用 Bearer JWT；公共分享浏览可不登录。"; case .xunlei:return "迅雷填写 accessToken|deviceId|captchaToken。" } }
}
