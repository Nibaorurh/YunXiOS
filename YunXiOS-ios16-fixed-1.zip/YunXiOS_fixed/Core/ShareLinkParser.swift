import Foundation

public enum ShareLinkParser {
    public static func parse(_ text: String) -> ParsedShare? {
        guard let raw = text.range(of: #"https?://[^\s]+"#, options: .regularExpression) else { return nil }
        var url = String(text[raw])
        while let last = url.last, ["。", "，", ",", "；", ";", ")", "]", "}", "\"", "'"].contains(String(last)) { url.removeLast() }
        let urlPwd = value(url, pattern: #"[?&]pwd=([A-Za-z0-9]+)"#)
        let textPwd = value(text, pattern: #"(?:提取码|访问码|密码)[：:]\s*([A-Za-z0-9]{4,8})"#)
        let pwd = urlPwd ?? textPwd
        let candidates: [(SharePlatform, String)] = [
            (.quark, #"pan\.quark\.cn/s/([A-Za-z0-9]+)"#),
            (.uc, #"drive\.uc\.cn/s/([A-Za-z0-9]+)"#),
            (.xunlei, #"pan\.xunlei\.com/s/([A-Za-z0-9_-]+)"#),
            (.baidu, #"pan\.baidu\.com/s/(1[A-Za-z0-9_-]+)"#),
            (.c139, #"yun\.139\.com/shareweb/.*?/w/i/([A-Za-z0-9_-]+)"#),
            (.pan123, #"123(?:865|pan)\.(?:com|cn)/s/([A-Za-z0-9]+-[A-Za-z0-9]+)"#),
            (.pan123, #"share\.123pan\.cn/123pan/([A-Za-z0-9-]+)"#),
            (.pan123, #"api/srr\?sk=([A-Za-z0-9-]+)"#)
        ]
        for (platform, pattern) in candidates {
            if let value = value(url, pattern: pattern) {
                let id = platform == .baidu ? String(value.dropFirst()) : value
                return ParsedShare(shareID: id, password: pwd, platform: platform)
            }
        }
        return nil
    }
    private static func value(_ text: String, pattern: String) -> String? {
        guard let r = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let m = r.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)), m.numberOfRanges > 1,
              let rr = Range(m.range(at: 1), in: text) else { return nil }
        return String(text[rr])
    }
}
