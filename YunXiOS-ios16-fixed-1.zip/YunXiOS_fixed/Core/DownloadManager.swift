import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

public actor DownloadManager {
    public static let shared = DownloadManager()
    private var tasks:[UUID:DownloadTask] = [:]
    private var workers:[UUID:Task<Void,Never>] = [:]
    private let storeURL:URL
    private let maxChunks = 16
    public init() { let dir=FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0]; try? FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true); storeURL=dir.appendingPathComponent("yunx-downloads.json"); load() }
    public func all() -> [DownloadTask] { tasks.values.sorted{$0.createdAt<$1.createdAt} }
    public func enqueue(_ link:DownloadLink, platform:SharePlatform?=nil) async -> UUID { let save=destination(for:link.filename); let t=DownloadTask(url:link.url,filename:link.filename,totalSize:link.size,savePath:save.path,headers:link.headers,cleanupFID:link.cleanupDirectoryFID,platform:platform); tasks[t.id]=t; persist(); start(t.id); return t.id }
    public func pause(_ id:UUID){ workers[id]?.cancel(); workers[id]=nil; if var t=tasks[id]{t.status = .paused; tasks[id]=t; persist()} }
    public func remove(_ id:UUID){ workers[id]?.cancel(); workers[id]=nil; if let t=tasks.removeValue(forKey:id){ try? FileManager.default.removeItem(at:URL(fileURLWithPath:t.savePath).deletingLastPathComponent()); persist()} }
    public func resume(_ id:UUID){ if workers[id] == nil { start(id) } }
    private func start(_ id:UUID){ workers[id]=Task{[weak self] in await self?.run(id) } }
    private func run(_ id:UUID) async { guard var task=tasks[id] else{return}; task.status = .downloading; tasks[id]=task; persist(); do { let size=try await probe(task); if var x=tasks[id]{x.totalSize=size>0 ? size:x.totalSize; tasks[id]=x; persist()}; try await download(id: id); if var x=tasks[id]{x.status = .completed; x.downloadedSize=x.totalSize; x.averageSpeed=0; tasks[id]=x; persist()} } catch is CancellationError { } catch { if var x=tasks[id]{x.status = .failed;x.error=error.localizedDescription;tasks[id]=x;persist()} } }
    private func probe(_ t:DownloadTask) async throws -> Int64 { var r=URLRequest(url:t.url); r.httpMethod="HEAD"; t.headers.forEach{r.setValue($0.value,forHTTPHeaderField:$0.key)}; let (d,resp)=try await URLSession.shared.data(for:r); _=d; return Int64(resp.expectedContentLength>0 ? resp.expectedContentLength:0) }
    private func download(id:UUID) async throws { guard let t=tasks[id] else{return}; let size=t.totalSize; let dir=URL(fileURLWithPath:t.savePath).deletingLastPathComponent(); try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true); if size<=0 { var r=URLRequest(url:t.url); t.headers.forEach{r.setValue($0.value,forHTTPHeaderField:$0.key)}; let (data,_)=try await URLSession.shared.data(for:r); try data.write(to:URL(fileURLWithPath:t.savePath),options:.atomic); if var x=tasks[id]{x.downloadedSize=Int64(data.count);tasks[id]=x;persist()}; return }
        let chunks=min(maxChunks,max(1,Int((size+4_194_303)/4_194_304))); let chunkDir=dir.appendingPathComponent(".yunx-\(id.uuidString)"); try FileManager.default.createDirectory(at:chunkDir,withIntermediateDirectories:true); try await withThrowingTaskGroup(of:(Int,Int64).self){group in for i in 0..<chunks{let start=Int64(i)*((size+Int64(chunks)-1)/Int64(chunks)); let end=min(size-1,Int64(i+1)*((size+Int64(chunks)-1)/Int64(chunks))-1); let part=chunkDir.appendingPathComponent("\(i).part"); let existing=(try? FileManager.default.attributesOfItem(atPath:part.path)[.size] as? NSNumber)?.int64Value ?? 0; if existing >= end-start+1 {continue}; group.addTask{ var r=URLRequest(url:t.url); r.setValue("bytes=\(start+existing)-\(end)",forHTTPHeaderField:"Range"); t.headers.forEach{r.setValue($0.value,forHTTPHeaderField:$0.key)}; let (data,_)=try await URLSession.shared.data(for:r); if Task.isCancelled {throw CancellationError()}; if existing==0{try data.write(to:part,options:.atomic)}else{let h=try FileHandle(forWritingTo:part); try h.seekToEnd(); try h.write(contentsOf:data); try h.close()}; return (i,Int64(existing)+Int64(data.count)) } }; for try await (_,_) in group{} }
        try FileManager.default.createFile(atPath:t.savePath,contents:nil); let out=try FileHandle(forWritingTo:URL(fileURLWithPath:t.savePath)); for i in 0..<chunks{let p=chunkDir.appendingPathComponent("\(i).part"); let d=try Data(contentsOf:p); try out.write(contentsOf:d)}; try out.close(); try? FileManager.default.removeItem(at:chunkDir); if var x=tasks[id]{x.downloadedSize=size;tasks[id]=x;persist()}
    }
    private func destination(for name:String)->(url:URL,path:String){let base=FileManager.default.urls(for:.documentDirectory,in:.userDomainMask)[0].appendingPathComponent("Downloads",isDirectory:true); try? FileManager.default.createDirectory(at:base,withIntermediateDirectories:true); let safe=name.replacingOccurrences(of:"/",with:"_"); return (base.appendingPathComponent(safe),base.appendingPathComponent(safe).path)}
    private func load(){if let d=try? Data(contentsOf:storeURL),let x=try? JSONDecoder().decode([UUID:DownloadTask].self,from:d){tasks=x}}
    private func persist(){if let d=try? JSONEncoder().encode(tasks){try? d.write(to:storeURL,options:.atomic)}}
}
