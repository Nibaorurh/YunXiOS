import Foundation
#if canImport(CryptoKit)
import CryptoKit
#endif
#if canImport(CommonCrypto)
import CommonCrypto
#endif

public enum CryptoSupport {
    public static func md5(_ string: String) -> String {
        #if canImport(CryptoKit)
        return Insecure.MD5.hash(data: Data(string.utf8)).map { String(format:"%02x", $0) }.joined()
        #else
        return MD5.hash(Data(string.utf8))
        #endif
    }
    public static func crc32(_ data: Data) -> String {
        var crc: UInt32 = 0xffffffff
        for b in data { crc ^= UInt32(b); for _ in 0..<8 { crc = (crc >> 1) ^ (0xedb88320 & UInt32(bitPattern: -Int32(crc & 1))) } }
        return String(format: "%08x", crc ^ 0xffffffff)
    }
    #if canImport(CommonCrypto)
    public static func aesCBCEncrypt(_ plaintext: Data, key: Data, iv: Data) throws -> Data {
        var out = Data(count: plaintext.count + kCCBlockSizeAES128); var moved = 0
        let status = out.withUnsafeMutableBytes { outPtr in plaintext.withUnsafeBytes { inPtr in key.withUnsafeBytes { keyPtr in iv.withUnsafeBytes { ivPtr in
            CCCrypt(CCOperation(kCCEncrypt), CCAlgorithm(kCCAlgorithmAES), CCOptions(kCCOptionPKCS7Padding), keyPtr.baseAddress, key.count, ivPtr.baseAddress, inPtr.baseAddress, plaintext.count, outPtr.baseAddress, out.count, &moved)
        }}}}
        guard status == kCCSuccess else { throw YunXError.server("AES 加密失败") }; out.removeSubrange(moved..<out.count); return out
    }
    #endif
}

private enum MD5 {
    static let s:[UInt32] = [7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21]
    static let k:[UInt32] = {
        (0..<64).map { UInt32(abs(sin(Double($0 + 1))) * 4294967296.0) }
    }()
    static func leftRotate(_ x:UInt32,_ c:UInt32)->UInt32 { (x << c) | (x >> (32-c)) }
    static func hash(_ data:Data)->String {
        var msg=[UInt8](data); let bitLen=UInt64(msg.count)*8; msg.append(0x80); while msg.count%64 != 56 {msg.append(0)}; for i in 0..<8 {msg.append(UInt8((bitLen >> UInt64(8*i)) & 0xff))}
        var a0:UInt32=0x67452301,b0:UInt32=0xefcdab89,c0:UInt32=0x98badcfe,d0:UInt32=0x10325476
        for chunk in stride(from:0,to:msg.count,by:64){
            var m=[UInt32](repeating:0,count:16); for i in 0..<16 {let j=chunk+i*4;m[i]=UInt32(msg[j])|UInt32(msg[j+1])<<8|UInt32(msg[j+2])<<16|UInt32(msg[j+3])<<24}
            var a=a0,b=b0,c=c0,d=d0
            for i in 0..<64 {var f:UInt32;var g:Int;switch i{case 0..<16:f=(b&c)|((~b)&d);g=i;case 16..<32:f=(d&b)|((~d)&c);g=(5*i+1)%16;case 32..<48:f=b^c^d;g=(3*i+5)%16;default:f=c^(b|(~d));g=(7*i)%16};let temp=d;d=c;c=b;b=b &+ leftRotate(a &+ f &+ k[i] &+ m[g],s[i]);a=temp}
            a0 &+= a;b0 &+= b;c0 &+= c;d0 &+= d
        }
        var out="";for x in [a0,b0,c0,d0]{for i in 0..<4{out += String(format:"%02x",(x >> UInt32(8*i)) & 0xff)}};return out
    }
}
