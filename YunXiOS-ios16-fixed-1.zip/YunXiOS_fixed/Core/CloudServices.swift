import Foundation

public protocol ShareResolver: Sendable {
    func createSession(parsed: ParsedShare, password: String?, credential: String) async throws -> ShareSession
    func listFiles(session: ShareSession, parentID: String, credential: String) async throws -> [ShareFile]
    func getDownloadLink(session: ShareSession, file: ShareFile, credential: String) async throws -> DownloadLink
}

public struct QuarkService: ShareResolver, Sendable {
    private let http: HTTPClient
    public init(http: HTTPClient = .shared) { self.http = http }
    public func createSession(parsed: ParsedShare, password: String?, credential: String) async throws -> ShareSession {
        var r = try HTTPHelpers.request(url: QuarkConstants.tokenURL, method: "POST", cookie: credential, headers: ["User-Agent": QuarkConstants.ua])
        try r.setJSON(["pwd_id": parsed.shareID, "passcode": password ?? parsed.password ?? "", "support_visit_limit_private_share": true])
        let res = try await http.send(r); let root = try JSONValue.object(res.data)
        let data = HTTPHelpers.dict(root["data"])
        guard let token = data["stoken"] as? String, !token.isEmpty else { throw YunXError.server(HTTPHelpers.string(root["message"]).isEmpty ? "未获取到分享凭证" : HTTPHelpers.string(root["message"])) }
        return ShareSession(shareID: parsed.shareID, token: token, title: HTTPHelpers.string(data["title"]), firstFID: HTTPHelpers.string(data["first_fid"]))
    }
    public func listFiles(session: ShareSession, parentID: String, credential: String) async throws -> [ShareFile] {
        var out: [ShareFile] = []; var page = 1
        repeat {
            var c = URLComponents(string: QuarkConstants.detailURL)!; c.queryItems = (c.queryItems ?? []) + [
                URLQueryItem(name: "pwd_id", value: session.shareID), URLQueryItem(name: "stoken", value: session.token),
                URLQueryItem(name: "pdir_fid", value: parentID), URLQueryItem(name: "ver", value: "2"), URLQueryItem(name: "force", value: "0"),
                URLQueryItem(name: "_page", value: "\(page)"), URLQueryItem(name: "_size", value: "100"), URLQueryItem(name: "_fetch_banner", value: "0"),
                URLQueryItem(name: "_fetch_share", value: "0"), URLQueryItem(name: "fetch_relate_conversation", value: "0"),
                URLQueryItem(name: "_fetch_total", value: "1"), URLQueryItem(name: "_sort", value: "file_type:asc,file_name:asc")]
            var r = try HTTPHelpers.request(url: c.url!.absoluteString, cookie: credential, headers: ["User-Agent": QuarkConstants.ua, "Origin":"https://pan.quark.cn", "Referer":"https://pan.quark.cn/"])
            let root = try JSONValue.object((try await http.send(r)).data); let data = HTTPHelpers.dict(root["data"])
            let arr = HTTPHelpers.arr(data["list"]); let batch = arr.map { ShareFile(fid: HTTPHelpers.string($0["fid"]), name: HTTPHelpers.string($0["file_name"]), size: HTTPHelpers.int64($0["size"]), isDirectory: HTTPHelpers.bool($0["dir"]), parentFID: HTTPHelpers.string($0["pdir_fid"]), fidToken: HTTPHelpers.string($0["share_fid_token"]), modified: HTTPHelpers.string($0["updated_at"])) }
            out += batch; page += 1; if batch.count < 100 || page > 100 { break }
        } while true
        return out
    }
    public func getDownloadLink(session: ShareSession, file: ShareFile, credential: String) async throws -> DownloadLink {
        var base = URLComponents(string: QuarkConstants.fileURL)!; base.queryItems = [URLQueryItem(name: "pdir_fid", value: "0"), URLQueryItem(name:"page",value:"1"), URLQueryItem(name:"size",value:"100")]
        var tempReq = try HTTPHelpers.request(url: base.url!.absoluteString, cookie: credential, headers: ["User-Agent": QuarkConstants.ua])
        let root = try JSONValue.object((try await http.send(tempReq)).data); let list = HTTPHelpers.arr(HTTPHelpers.dict(root["data"])["list"])
        let tempName = QuarkConstants.tempName
        let tempFID = HTTPHelpers.string(list.first(where: { HTTPHelpers.bool($0["dir"]) && HTTPHelpers.string($0["file_name"]) == tempName })?["fid"])
        let dirFID: String
        if tempFID.isEmpty {
            var create = try HTTPHelpers.request(url: QuarkConstants.fileURL, method:"POST", cookie: credential, headers:["User-Agent":QuarkConstants.ua]); try create.setJSON(["pdir_fid":"0","file_name":tempName,"dir_path":"","dir_init_lock":false]);
            let d = try JSONValue.object((try await http.send(create)).data); let f = HTTPHelpers.string(HTTPHelpers.dict(d["data"])["fid"]); guard !f.isEmpty else { throw YunXError.server("创建临时目录失败") }; dirFID = f
        } else { dirFID = tempFID }
        var createSub = try HTTPHelpers.request(url: QuarkConstants.fileURL, method:"POST", cookie: credential, headers:["User-Agent":QuarkConstants.ua]); let subName = "tr_\(Int(Date().timeIntervalSince1970*1000))_\(Int.random(in:0...999999))"; try createSub.setJSON(["pdir_fid":dirFID,"file_name":subName,"dir_path":"","dir_init_lock":false]); let subRoot = try JSONValue.object((try await http.send(createSub)).data); let subFID = HTTPHelpers.string(HTTPHelpers.dict(subRoot["data"])["fid"]); guard !subFID.isEmpty else { throw YunXError.server("创建临时转存目录失败") }
        var save = try HTTPHelpers.request(url: QuarkConstants.saveURL, method:"POST", cookie: credential, headers:["User-Agent":QuarkConstants.ua]); try save.setJSON(["pwd_id":session.shareID,"stoken":session.token,"pdir_fid":file.parentFID,"fid":file.fid,"fid_token":file.fidToken,"to_pdir_fid":subFID,"scene":"link"]); let saveRoot = try JSONValue.object((try await http.send(save)).data); let taskID = HTTPHelpers.string(HTTPHelpers.dict(saveRoot["data"])["task_id"]); guard !taskID.isEmpty else { throw YunXError.server("转存失败") }
        var savedFID = ""; for _ in 0..<30 { try await Task.sleep(nanoseconds: 1_000_000_000); var q = try HTTPHelpers.request(url: "\(QuarkConstants.taskURL)&task_id=\(taskID)&retry_index=0", cookie: credential, headers:["User-Agent":QuarkConstants.ua]); let tRoot = try JSONValue.object((try await http.send(q)).data); let d = HTTPHelpers.dict(tRoot["data"]); if let f = d["save_as_top_fids"] as? [Any], let first = f.first as? String { savedFID = first; break } }
        guard !savedFID.isEmpty else { throw YunXError.server("转存超时，请稍后重试") }
        var dl = try HTTPHelpers.request(url: QuarkConstants.downloadURL, method:"POST", cookie: credential, headers:["User-Agent":QuarkConstants.ua,"Referer":"https://pan.quark.cn/"]); try dl.setJSON(["fids":[savedFID]]); let dlRoot = try JSONValue.object((try await http.send(dl)).data); let item = (dlRoot["data"] as? [[String:Any]])?.first ?? [:]; guard let u = URL(string:HTTPHelpers.string(item["download_url"])), !u.absoluteString.isEmpty else { throw YunXError.server("获取下载链接失败") }
        return DownloadLink(fid:file.fid, filename:file.name, url:u, size:file.size, headers:["Referer":"https://pan.quark.cn/"], cleanupDirectoryFID:subFID)
    }
}
