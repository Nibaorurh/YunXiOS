import SwiftUI

struct DownloadListView: View {
    @State private var items:[DownloadTask]=[]
    @State private var refreshTask: Task<Void,Never>?
    var body: some View {
        NavigationStack { List(items) { t in
            VStack(alignment:.leading,spacing:6) {
                HStack { Text(t.filename).lineLimit(1); Spacer(); Text(status(t.status)).font(.caption) }
                ProgressView(value: t.totalSize > 0 ? Double(t.downloadedSize)/Double(t.totalSize) : nil)
                HStack { Text(ByteCountFormatter.string(fromByteCount:t.downloadedSize,countStyle:.file)).font(.caption).foregroundStyle(.secondary); Spacer(); if t.totalSize>0 {Text(ByteCountFormatter.string(fromByteCount:t.totalSize,countStyle:.file)).font(.caption).foregroundStyle(.secondary)} }
                HStack { if t.status == .downloading { Button("暂停"){Task{await DownloadManager.shared.pause(t.id)}} } else if t.status == .paused || t.status == .failed { Button("继续"){Task{await DownloadManager.shared.resume(t.id)}} }; Button("删除",role:.destructive){Task{await DownloadManager.shared.remove(t.id)}} }
            }.padding(.vertical,4)
        }.navigationTitle("下载") .task { await refresh(); refreshTask=Task{ while !Task.isCancelled { try? await Task.sleep(nanoseconds:1_000_000_000); await refresh() } } }.onDisappear{refreshTask?.cancel()} }
    }
    private func refresh() async { let x=await DownloadManager.shared.all(); await MainActor.run{items=x} }
    private func status(_ s:DownloadTask.Status)->String { switch s{case .pending:return "等待中";case .downloading:return "下载中";case .paused:return "已暂停";case .completed:return "已完成";case .failed:return "失败"} }
}
