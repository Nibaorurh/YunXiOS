import SwiftUI
import WebKit

struct WebCookieLoginView: View {
    let platform:SharePlatform; let completion:(String)->Void
    @Environment(\.dismiss) private var dismiss
    @State private var url:URL
    @State private var title = "登录"
    init(platform:SharePlatform,completion:@escaping(String)->Void){self.platform=platform;self.completion=completion; let u:URL; switch platform{case .quark:u=URL(string:"https://pan.quark.cn/?fr=pc&platform=pc")!;case .uc:u=URL(string:"https://drive.uc.cn/")!;case .baidu:u=URL(string:"https://pan.baidu.com/")!;case .c139:u=URL(string:"https://yun.139.com/m/#/login")!;default:u=URL(string:"https://pan.quark.cn/")!}; _url=State(initialValue:u)}
    var body: some View { NavigationStack { WebView(url:url){cookie in completion(cookie)} .ignoresSafeArea(edges:.bottom).toolbar{ToolbarItem(placement:.topBarLeading){Button("关闭"){dismiss()}};ToolbarItem(placement:.topBarTrailing){Button("提取 Cookie"){ NotificationCenter.default.post(name:.captureYunXCookie,object:nil)}}}.navigationTitle(title).navigationBarTitleDisplayMode(.inline) } }
}

extension Notification.Name { static let captureYunXCookie=Notification.Name("captureYunXCookie") }

struct WebView:UIViewRepresentable {
    let url:URL; let completion:(String)->Void
    func makeCoordinator()->Coordinator{Coordinator(completion:completion)}
    func makeUIView(context:Context)->WKWebView { let c=WKWebViewConfiguration();let w=WKWebView(frame:.zero,configuration:c);w.navigationDelegate=context.coordinator;w.load(URLRequest(url:url)); NotificationCenter.default.addObserver(forName:.captureYunXCookie,object:nil,queue:.main){_ in w.configuration.websiteDataStore.httpCookieStore.getAllCookies{cookies in let s=cookies.map{"\($0.name)=\($0.value)"}.joined(separator:"; ");completion(s)}}; return w }
    func updateUIView(_ view:WKWebView,context:Context){}
    final class Coordinator:NSObject,WKNavigationDelegate { let completion:(String)->Void; init(completion:@escaping(String)->Void){self.completion=completion} }
}
