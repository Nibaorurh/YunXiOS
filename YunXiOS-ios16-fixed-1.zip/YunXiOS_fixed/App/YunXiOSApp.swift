import SwiftUI

@main
struct YunXiOSApp: App {
    @StateObject private var model = AppModel()
    var body: some Scene {
        WindowGroup { RootView().environmentObject(model) }
    }
}

@MainActor final class AppModel: ObservableObject {
    @Published var credentials: [String: String] = [:]
    @Published var notice: String?
    let store = CredentialStore()
    init() {
        Task { await reloadCredentials() }
    }
    func reloadCredentials() async {
        var result:[String:String]=[:]
        for p in SharePlatform.allCases { if let v=await store.get(p.rawValue), !v.isEmpty { result[p.rawValue]=v } }
        credentials=result
    }
    func save(platform: SharePlatform, credential: String) {
        credentials[platform.rawValue] = credential
        Task { await store.set(platform.rawValue, credential) }
    }
    func credential(for platform: SharePlatform) -> String { credentials[platform.rawValue] ?? "" }
}
