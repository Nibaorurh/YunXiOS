import SwiftUI
import UIKit

struct ResolveView: View {
    @EnvironmentObject var model: AppModel
    @State private var input = ""
    @State private var parsed: ParsedShare?
    @State private var password = ""
    @State private var session: ShareSession?
    @State private var files:[ShareFile]=[]
    @State private var currentParent = "0"
    @State private var loading = false
    @State private var error: String?
    @State private var path:[String] = []

    var body: some View {
        NavigationStack {
            VStack(spacing:0) {
                Form {
                    Section("分享链接") {
                        TextEditor(text:$input).frame(minHeight:100)
                        HStack {
                            Button { input = UIPasteboard.general.string ?? "" } label: { Label("粘贴", systemImage:"doc.on.clipboard") }
                            if let p = parsed { Spacer(); Text(p.platform.rawValue).font(.caption).foregroundStyle(.secondary) }
                        }
                    }
                    if parsed != nil { Section("提取码") { TextField("可选", text:$password).textInputAutocapitalization(.never).autocorrectionDisabled() } }
                }
                HStack {
                    Button("识别") { detect() }.buttonStyle(.bordered)
                    Button(loading ? "加载中…" : "开始解析") { Task{ await resolve() } }.buttonStyle(.borderedProminent).disabled(loading || parsed == nil)
                }.padding(.horizontal).padding(.bottom,8)
                if let error { Text(error).foregroundStyle(.red).font(.footnote).padding(.horizontal).padding(.bottom,8) }
                if let s=session { Text(s.title.isEmpty ? s.shareID : s.title).font(.headline).padding(.top,4) }
                if !files.isEmpty { List(files) { file in FileRow(file:file) { Task{ await handle(file) } } } }
                Spacer(minLength:0)
            }.navigationTitle("YunX")
        }
    }

    private func detect() {
        error=nil; session=nil; files=[]; path=[]
        guard let p = ShareLinkParser.parse(input) else { error="无法识别分享链接"; return }
        parsed=p; password=p.password ?? ""
    }
    private func resolver(_ p:SharePlatform)->any ShareResolver {
        switch p { case .quark:return QuarkService(); case .uc:return UCService(); case .baidu:return BaiduService(); case .pan123:return Pan123Service(); case .c139:return C139Service(); case .xunlei:return XunleiService() }
    }
    private func resolve() async {
        guard let p=parsed else{return}; await MainActor.run{loading=true;error=nil}
        do { let r=resolver(p.platform); let s=try await r.createSession(parsed:p,password:password.isEmpty ? p.password : password,credential:model.credential(for:p.platform)); let list=try await r.listFiles(session:s,parentID:s.firstFID ?? "0",credential:model.credential(for:p.platform)); await MainActor.run{session=s;files=list;currentParent=s.firstFID ?? "0";loading=false} } catch { await MainActor.run{error=error.localizedDescription;loading=false} }
    }
    private func handle(_ file:ShareFile) async {
        guard let p=parsed, let s=session else{return}; let r=resolver(p.platform)
        if file.isDirectory { do { let f=try await r.listFiles(session:s,parentID:file.fid,credential:model.credential(for:p.platform)); await MainActor.run{files=f;currentParent=file.fid} } catch { await MainActor.run{error=error.localizedDescription} }; return }
        do { let link=try await r.getDownloadLink(session:s,file:file,credential:model.credential(for:p.platform)); _=await DownloadManager.shared.enqueue(link,platform:p.platform); await MainActor.run{error="已加入下载任务：\(file.name)"} } catch { await MainActor.run{error=error.localizedDescription} }
    }
}

struct FileRow: View {
    let file:ShareFile; let action:()->Void
    var body: some View { Button(action:action){ HStack { Image(systemName:file.isDirectory ? "folder.fill":"doc").foregroundStyle(file.isDirectory ? .blue : .secondary); VStack(alignment:.leading){Text(file.name).lineLimit(1); if !file.isDirectory {Text(ByteCountFormatter.string(fromByteCount:file.size,countStyle:.file)).font(.caption).foregroundStyle(.secondary)}}; Spacer(); Image(systemName:"chevron.right").font(.caption).foregroundStyle(.tertiary) } } }
}
