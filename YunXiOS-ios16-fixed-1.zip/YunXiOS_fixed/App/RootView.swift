import SwiftUI

struct RootView: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        TabView {
            ResolveView().tabItem { Label("解析", systemImage: "link") }
            DownloadListView().tabItem { Label("下载", systemImage: "arrow.down.circle") }
            SettingsView().tabItem { Label("设置", systemImage: "gearshape") }
        }
        .tint(.accentColor)
        .alert("提示", isPresented: Binding(get: { model.notice != nil }, set: { if !$0 { model.notice=nil } })) { Button("确定") { model.notice=nil } } message: { Text(model.notice ?? "") }
    }
}

struct AboutView: View {
    var body: some View {
        NavigationStack { Form { Section("YunX iOS") { Text("YunX / 云析 iOS 移植版"); Text("基于原 YunX AGPL-3.0 项目进行移植，功能与接口可能随网盘官方调整而变化。") }; Section("免责声明") { Text("请仅下载你有权使用的内容。网盘接口、Cookie、Token 的有效性由服务端决定。") } }.navigationTitle("关于") }
    }
}
