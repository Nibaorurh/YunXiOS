// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "YunXiOSCore",
    platforms: [
        .iOS(.v16)
    ],
    products: [
        .library(name: "YunXiOSCore", targets: ["YunXiOSCore"])
    ],
    targets: [
        .target(name: "YunXiOSCore", path: "Core"),
        .testTarget(name: "YunXiOSTests", dependencies: ["YunXiOSCore"], path: "Tests")
    ]
)
