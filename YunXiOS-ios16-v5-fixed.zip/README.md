# YunX iOS — 云析 iOS 移植版（iOS 16.2）

这是基于 CYQawa/YunX Android 项目的 iOS 原生移植工程，目标为 **iOS 16.2+**。

## 已包含

- SwiftUI 原生界面：解析 / 下载 / 设置 / 关于
- 分享链接自动识别：夸克、UC、迅雷、百度、139、123 云盘
- 分享目录浏览与文件选择
- 夸克：stoken、分页文件列表、唯一临时转存目录、异步转存、直链、清理目录
- UC：分享 Token、分页列表、转存任务、直链
- 百度：分享校验、文件列表、dlink
- 123 云盘：分享列表和下载接口适配骨架
- 139：分享 AES-CBC 加密接口、目录列表、OBS 预签名直链
- 迅雷：分享列表、文件详情直链；认证字段为 `accessToken|deviceId|captchaToken`
- 下载管理：任务持久化、Range 分片、最多 16 个并发分片、`.part` 断点文件、暂停/继续/删除
- Cookie/JWT 等认证信息持久化
- Web 登录页的 Cookie 提取入口（夸克 / UC / 百度 / 139）

## 打开方式

Mac 上使用 Xcode 15+ 打开：

`YunXiOS.xcodeproj`

目标版本为 iOS 16.2。首次构建需要在 Xcode 的 Signing & Capabilities 中选择你自己的 Team / Bundle Identifier。TrollStore 或越狱安装属于设备侧安装流程，不由源码本身决定。

## 认证说明

设置页可以保存各平台认证信息。

- 夸克 / UC / 百度：优先保存完整 Cookie
- 139：保存原项目使用的认证串（通常需要包含 Authorization）
- 123：保存 Bearer JWT；公共分享浏览可不登录
- 迅雷：保存 `accessToken|deviceId|captchaToken`

## 下载说明

下载器将任务写入 App Support，并使用分片 `.part` 文件实现任务恢复。iOS 的系统后台执行受到系统策略限制；这版优先保证前台高速并发和断点恢复。真正的系统级后台 URLSession 下载代理可以在后续版本继续接入。

## 开源协议

本移植工程包含并基于原 YunX 项目的 **GNU AGPL-3.0** 授权代码/逻辑。请保留许可证与版权声明，并按 AGPL-3.0 要求处理对外分发和修改后的源代码。

原项目：<https://github.com/CYQawa/YunX>

## GitHub Actions 自动构建

仓库已包含 `.github/workflows/build.yml`。构建步骤会：

1. 自动查找仓库中已提交的 `.xcodeproj`，或者查找并解压任意 `.zip` 源码包；
2. 在 macOS GitHub Actions runner 上选择 Xcode；
3. 检查项目、编译 iOS Release App；
4. 将未签名的 `YunXiOS-unsigned.ipa` 上传到 Actions 的 Artifacts。

在 GitHub 手机端操作：进入仓库 → **Actions** → **Build YunXiOS IPA** → **Run workflow**。构建成功后进入本次运行页面，在底部 **Artifacts** 下载 `YunXiOS-unsigned-ipa`。

注意：该 IPA 是无 Apple 开发者签名的构建产物。能否直接被 TrollStore 接受取决于设备、TrollStore 版本以及应用签名/安装要求；GitHub Actions 本身不能保证越狱或 TrollStore 一定安装成功。


This build uses a clean iOS Xcode project with deployment target iOS 16.2 and a shared YunXiOS scheme.


## v3 重要说明

构建工作流会在打包后检查 IPA 是否包含真正的 `CFBundleExecutable` 主程序，防止生成只有目录没有可执行文件的无效 IPA。

## 登录方式说明

网盘登录入口统一改为对应网盘官方网页登录：夸克、UC、迅雷、百度、139、123 云盘均从官方站点打开。登录完成后点击“保存登录状态”，应用会读取 Cookie 并保存到 iOS Keychain；下次打开应用仍保留已保存认证。部分平台的接口还需要从网页登录会话取得 JWT/设备令牌，后续适配器会在同一登录会话基础上处理，不能把普通 Cookie 直接冒充 JWT。


## v5 构建失败排查

如果 Actions 失败，不要只看顶部的 `exit code 65`。进入失败的 `Build iOS app` 步骤，展开日志末尾的所有 `error:` 行；如果工作流已经执行到失败后置步骤，下载 `YunXiOS-compiler-log` Artifact，其中包含完整的 Xcode 编译输出。
