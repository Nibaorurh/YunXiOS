# YunXiOS iOS 16.2 v5 状态说明

## 本次修正

- 增加共享 Xcode Scheme，避免 GitHub Actions 找不到 Scheme。
- 增加 IPA 内部结构校验：检查 `Payload/*.app/Info.plist`、`CFBundleExecutable` 和真实 Mach-O 主程序，避免再次出现 TrollStore 解析错误 303。
- 修正下载器的关键逻辑：只有确认下载地址支持 HTTP Range 时才启用分片；服务器返回 HTTP 200 忽略 Range 时不再把完整文件错误拼接进分片，避免生成损坏文件。
- 修正分片合并时目标文件不存在导致 `FileHandle` 打开失败的问题。
- 保留前台下载、暂停/继续、断点分片文件和 Files App 导出能力。

## 必须如实说明

- 本环境没有 macOS、Xcode 和真实 iPhone，无法在这里完成真机网盘登录及真实分享下载验证。
- 夸克流程是当前主要适配目标；其他网盘接口受官方接口、Cookie、风控和字段变化影响，不能保证永久可用。
- 该版本不是经过真机验收的最终发行版；GitHub Actions 的 Success 只代表构建及结构校验成功，不代表每个网盘都已实测。


## v5 针对构建失败的修正

- 移除 iOS 16.2 不支持的 `ContentUnavailableView`，改为兼容 iOS 16 的自定义空状态视图。
- 显式导入 Combine，避免 `ObservableObject` / `@Published` 在 Xcode 环境下解析不一致。
- GitHub Actions 将保存完整 `xcodebuild` 编译日志；即使构建失败，也会生成 `YunXiOS-compiler-log` Artifact，便于定位真正的 Swift 编译错误。
