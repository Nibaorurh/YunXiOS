import XCTest
@testable import YunXiOSCore

final class YunXiOSTests: XCTestCase {
    func testShareParsing() {
        XCTAssertEqual(ShareLinkParser.parse("夸克 https://pan.quark.cn/s/AbCd?pwd=1234")?.platform, .quark)
        XCTAssertEqual(ShareLinkParser.parse("https://pan.baidu.com/s/1abcXYZ?pwd=abcd")?.shareID, "abcXYZ")
        XCTAssertEqual(ShareLinkParser.parse("https://drive.uc.cn/s/UC123")?.platform, .uc)
        XCTAssertEqual(ShareLinkParser.parse("访问码: 1234 https://pan.xunlei.com/s/XL_1")?.password, "1234")
        XCTAssertEqual(ShareLinkParser.parse("https://www.123pan.com/s/2785Vv-T4Ded")?.platform, .pan123)
    }

    func testMD5() {
        XCTAssertEqual(CryptoSupport.md5("hello"), "5d41402abc4b2a76b9719d911017c592")
    }

    func testCredentialHintsDoNotLeakValues() {
        let task = DownloadTask(url: URL(string: "https://example.com/a.bin")!, filename: "a.bin", headers: ["Authorization": "secret"])
        XCTAssertEqual(task.headers["Authorization"], "secret")
    }
}
