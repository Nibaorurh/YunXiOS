#!/bin/bash
set -euo pipefail
IPA="${1:?usage: verify_ipa.sh file.ipa}"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
unzip -q "$IPA" -d "$TMP"
APP=$(find "$TMP/Payload" -maxdepth 1 -type d -name '*.app' | head -1)
test -n "$APP" || { echo 'ERROR: Payload/*.app not found'; exit 1; }
PLIST="$APP/Info.plist"
test -f "$PLIST" || { echo 'ERROR: Info.plist not found'; exit 1; }
EXEC=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$PLIST")
test -n "$EXEC" || { echo 'ERROR: CFBundleExecutable empty'; exit 1; }
test -f "$APP/$EXEC" || { echo "ERROR: executable missing: $EXEC"; exit 1; }
file "$APP/$EXEC"
echo "OK: $APP contains executable $EXEC"
