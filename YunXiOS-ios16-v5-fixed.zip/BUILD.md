# YunXiOS 自动构建说明

本版本已修复 GitHub Actions 当前出现的编译错误：

- `ResolveView.swift` 中 `catch` 变量遮蔽了 SwiftUI 的 `@State error`，导致 `cannot assign to value: 'error' is immutable` 和 `cannot assign value of type 'String' to type 'any Error'`。
- `SettingsView.swift` 使用了 iOS 17 才能推断到的双参数 `onChange` 写法，已改成兼容 iOS 16 的单参数写法。
- GitHub Actions 删除了会触发 `CONFIGURATION_BUILD_DIR` 清理限制的 `clean`，改为先手动清理目录再执行 `build`。

## 构建

将本项目内容提交到 GitHub 后：

1. 打开仓库的 **Actions**。
2. 选择 **Build YunXiOS IPA**。
3. 点击 **Run workflow**。
4. 构建成功后，进入对应运行记录底部的 **Artifacts**。
5. 下载 `YunXiOS-unsigned-ipa`。

这是未签名 IPA。未签名 IPA 不保证可以直接通过 TrollStore 安装；是否可安装取决于设备、系统版本和后续签名/注入方式。
