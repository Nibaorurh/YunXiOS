import SwiftUI
import UIKit

struct DownloadListView: View {
    @State private var items: [DownloadTask] = []
    @State private var refreshTask: Task<Void,Never>?
    @State private var shareURL: URL?
    @State private var showShare = false

    var body: some View {
        NavigationStack {
            ZStack {
                AppBackground()
                List {
                    if items.isEmpty {
                        EmptyDownloadView()
                            .listRowBackground(Color.clear)
                            .padding(.vertical, 80)
                    }
                    ForEach(items) { task in
                        DownloadCard(task: task,
                                     pause: { Task { await DownloadManager.shared.pause(task.id) } },
                                     resume: { Task { await DownloadManager.shared.resume(task.id) } },
                                     remove: { Task { await DownloadManager.shared.remove(task.id) } },
                                     share: {
                                         Task {
                                             if let url = await DownloadManager.shared.fileURL(task.id) {
                                                 await MainActor.run { shareURL = url; showShare = true }
                                             }
                                         }
                                     })
                            .listRowSeparator(.hidden)
                            .listRowBackground(Color.clear)
                    }
                }
                .listStyle(.plain)
            }
            .navigationTitle("下载")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { Task { await refresh() } } label: { Image(systemName: "arrow.clockwise") }
                }
            }
            .task {
                await refresh()
                refreshTask = Task {
                    while !Task.isCancelled {
                        // 350ms 轮询：进度与实时速率看起来是连续变化的。
                        try? await Task.sleep(nanoseconds: 350_000_000)
                        await refresh()
                    }
                }
            }
            .onDisappear { refreshTask?.cancel() }
        }
            .sheet(isPresented: $showShare) {
            if let shareURL = shareURL { ActivityView(activityItems: [shareURL]) }
        }
    }

    private func refresh() async {
        let values = await DownloadManager.shared.all()
        await MainActor.run { items = values }
    }
}

private struct DownloadCard: View {
    let task: DownloadTask
    let pause: () -> Void
    let resume: () -> Void
    let remove: () -> Void
    let share: () -> Void

    private var progress: Double {
        guard task.totalSize > 0 else { return 0 }
        return min(max(Double(task.downloadedSize) / Double(task.totalSize), 0), 1)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                Image(systemName: icon).font(.system(size: 24)).foregroundStyle(.indigo)
                VStack(alignment: .leading, spacing: 4) {
                    Text(task.filename).font(.headline).lineLimit(2)
                    Text(statusText).font(.caption).foregroundStyle(statusColor)
                }
                Spacer()
                if task.status == .completed { Image(systemName: "checkmark.circle.fill").foregroundStyle(.green) }
            }
            if task.totalSize > 0 { ProgressView(value: progress) }
            HStack {
                Text(ByteCountFormatter.string(fromByteCount: task.downloadedSize, countStyle: .file))
                if task.totalSize > 0 {
                    Text("/ \(ByteCountFormatter.string(fromByteCount: task.totalSize, countStyle: .file))")
                }
                Spacer()
                if task.status == .downloading, task.averageSpeed > 0 {
                    Text("\(ByteCountFormatter.string(fromByteCount: task.averageSpeed, countStyle: .memory))/s")
                        .foregroundStyle(.indigo)
                } else if task.status == .downloading {
                    Text("连接中…")
                }
            }
            .font(.caption)
            .foregroundStyle(.secondary)

            if let error = task.error, !error.isEmpty {
                Text(error).font(.caption2).foregroundStyle(.red).lineLimit(3)
            }

            HStack(spacing: 18) {
                switch task.status {
                case .downloading:
                    Button("暂停", systemImage: "pause.fill", action: pause)
                case .paused, .failed:
                    Button("继续", systemImage: "play.fill", action: resume)
                case .completed:
                    Button("导出", systemImage: "square.and.arrow.up", action: share)
                case .pending:
                    Button("开始", systemImage: "play.fill", action: resume)
                }
                Spacer()
                Button("删除", systemImage: "trash", role: .destructive, action: remove)
            }
            .font(.subheadline.weight(.semibold))
        }
        .padding(16)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private var icon: String {
        if task.filename.lowercased().hasSuffix(".zip") || task.filename.lowercased().hasSuffix(".rar") { return "archivebox.fill" }
        if task.filename.lowercased().hasSuffix(".mp4") { return "film.fill" }
        if task.filename.lowercased().hasSuffix(".jpg") || task.filename.lowercased().hasSuffix(".png") { return "photo.fill" }
        return "doc.fill"
    }

    private var statusText: String {
        switch task.status {
        case .pending: return "等待中"
        case .downloading: return "下载中"
        case .paused: return "已暂停"
        case .completed: return "已完成 · \(task.savePath)"
        case .failed: return "失败"
        }
    }
    private var statusColor: Color { task.status == .completed ? .green : task.status == .failed ? .red : .secondary }
}

struct ActivityView: UIViewControllerRepresentable {
    let activityItems: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: activityItems, applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) { }
}


private struct EmptyDownloadView: View {
    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: "arrow.down.circle")
                .font(.system(size: 38))
                .foregroundStyle(.secondary)
            Text("还没有下载任务").font(.headline)
            Text("解析分享后，点文件右侧的下载按钮即可加入任务")
                .font(.subheadline).foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 80)
    }
}
