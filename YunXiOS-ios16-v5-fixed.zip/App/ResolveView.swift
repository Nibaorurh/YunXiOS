import SwiftUI
import UIKit

struct ResolveView: View {
    @EnvironmentObject var model: AppModel
    @State private var input = ""
    @State private var parsed: ParsedShare?
    @State private var password = ""
    @State private var session: ShareSession?
    @State private var files: [ShareFile] = []
    @State private var currentParent = "0"
    @State private var breadcrumbs: [(String,String)] = []
    @State private var loading = false
    @State private var error: String?
    @State private var showPassword = false
    @FocusState private var focused: Bool

    var body: some View {
        NavigationStack {
            ZStack {
                AppBackground()
                if session == nil {
                    inputView
                } else {
                    detailView
                }
            }
            .navigationTitle(session == nil ? "解析" : (session?.title.isEmpty == false ? session!.title : "分享内容"))
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                if session != nil {
                    ToolbarItem(placement: .topBarLeading) {
                        Button { backToRoot() } label: { Image(systemName: "chevron.left") }
                    }
                }
            }
        }
        .alert("解析失败", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
            Button("确定") { error = nil }
        } message: { Text(error ?? "") }
    }

    private var inputView: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 8) {
                    Label("粘贴分享链接，一键解析内容", systemImage: "link")
                        .font(.headline)
                    Text("支持夸克、UC、迅雷、百度、139、123 云盘链接")
                        .font(.subheadline).foregroundStyle(.secondary)
                }

                VStack(alignment: .leading, spacing: 14) {
                    HStack(spacing: 8) {
                        Image(systemName: "link.circle.fill").foregroundStyle(.indigo)
                        Text("分享链接").font(.headline)
                        Spacer()
                        Button("粘贴") {
                            input = UIPasteboard.general.string ?? ""
                            focused = false
                            detect()
                        }
                        .font(.subheadline.weight(.semibold))
                    }
                    TextEditor(text: $input)
                        .focused($focused)
                        .frame(minHeight: 130)
                        .padding(8)
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.primary.opacity(0.06)))
                        .onChange(of: input) { _ in
                            if ShareLinkParser.parse(input) != nil { detect() }
                        }

                    if let parsed = parsed {
                        HStack(spacing: 8) {
                            PlatformPill(platform: parsed.platform)
                            if let pwd = parsed.password, !pwd.isEmpty {
                                Text("已识别提取码").font(.caption.weight(.semibold)).foregroundStyle(.green)
                            }
                            Spacer()
                        }
                    }

                    if parsed != nil {
                        HStack {
                            Image(systemName: showPassword ? "lock.open" : "lock")
                                .foregroundStyle(.secondary)
                            if showPassword {
                                TextField("提取码（可选）", text: $password)
                            } else {
                                SecureField("提取码（可选）", text: $password)
                            }
                            Button { showPassword.toggle() } label: {
                                Image(systemName: showPassword ? "eye.slash" : "eye")
                            }
                        }
                        .padding(14)
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
                    }
                }
                .padding(18)
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.primary.opacity(0.05)))

                Button {
                    Task { await resolve() }
                } label: {
                    HStack {
                        if loading { ProgressView().tint(.white) }
                        Text(loading ? "正在解析…" : "开始解析")
                            .font(.headline)
                    }
                    .frame(maxWidth: .infinity).padding(.vertical, 16)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(parsed == nil || loading)

                if parsed == nil {
                    Text("提示：也可以直接把链接连同“提取码：xxxx”一起粘贴。")
                        .font(.footnote).foregroundStyle(.secondary)
                        .padding(.horizontal, 4)
                }
            }
            .padding(20)
        }
        .scrollDismissesKeyboard(.interactively)
    }

    private var detailView: some View {
        VStack(spacing: 0) {
            if !breadcrumbs.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        Button("根目录") { jump(to: (session?.firstFID ?? "0"), title: session?.title ?? "") }
                        ForEach(Array(breadcrumbs.enumerated()), id: \.offset) { _, item in
                            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                            Button(item.0) { jump(to: item.1, title: item.0) }
                        }
                    }
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 20).padding(.vertical, 8)
                }
            }
            List {
                ForEach(files) { file in
                    ShareFileCard(file: file) {
                        Task { await handle(file) }
                    }
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
                }
            }
            .listStyle(.plain)
            .overlay {
                if files.isEmpty && !loading {
                    EmptyFilesView()
                }
            }
        }
        .task { if files.isEmpty { await reloadCurrentDirectory() } }
    }

    private func detect() {
        guard let p = ShareLinkParser.parse(input) else { return }
        parsed = p
        password = p.password ?? password
        error = nil
    }

    private func resolver(_ platform: SharePlatform) -> any ShareResolver {
        switch platform {
        case .quark: return QuarkService()
        case .uc: return UCService()
        case .baidu: return BaiduService()
        case .pan123: return Pan123Service()
        case .c139: return C139Service()
        case .xunlei: return XunleiService()
        }
    }

    private func resolve() async {
        guard let p = parsed else { return }
        await MainActor.run { loading = true; error = nil }
        do {
            let service = resolver(p.platform)
            let session = try await service.createSession(parsed: p,
                                                          password: password.isEmpty ? p.password : password,
                                                          credential: model.credential(for: p.platform))
            let first = session.firstFID ?? "0"
            let list = try await service.listFiles(session: session, parentID: first, credential: model.credential(for: p.platform))
            await MainActor.run {
                self.session = session
                self.currentParent = first
                self.files = list
                self.breadcrumbs = []
                self.loading = false
            }
        } catch {
            await MainActor.run { self.error = error.localizedDescription; self.loading = false }
        }
    }

    private func reloadCurrentDirectory() async {
        guard let p = parsed, let s = session else { return }
        await MainActor.run { loading = true }
        do {
            let list = try await resolver(p.platform).listFiles(session: s, parentID: currentParent, credential: model.credential(for: p.platform))
            await MainActor.run { files = list; loading = false }
        } catch {
            await MainActor.run { self.error = error.localizedDescription; loading = false }
        }
    }

    private func handle(_ file: ShareFile) async {
        guard let p = parsed, let s = session else { return }
        if file.isDirectory {
            do {
                let list = try await resolver(p.platform).listFiles(session: s, parentID: file.fid, credential: model.credential(for: p.platform))
                await MainActor.run {
                    breadcrumbs.append((file.name, file.fid))
                    currentParent = file.fid
                    files = list
                }
            } catch {
                await MainActor.run { self.error = error.localizedDescription }
            }
            return
        }
        do {
            await MainActor.run { loading = true }
            let link = try await resolver(p.platform).getDownloadLink(session: s, file: file, credential: model.credential(for: p.platform))
            let id = await DownloadManager.shared.enqueue(link, platform: p.platform)
            await MainActor.run {
                loading = false
                model.notify("已加入下载任务：\(file.name)\n任务 ID：\(id.uuidString.prefix(8))")
            }
        } catch {
            await MainActor.run { self.loading = false; self.error = error.localizedDescription }
        }
    }

    private func jump(to id: String, title: String) {
        guard let p = parsed, let s = session else { return }
        Task {
            do {
                let list = try await resolver(p.platform).listFiles(session: s, parentID: id, credential: model.credential(for: p.platform))
                await MainActor.run {
                    currentParent = id
                    files = list
                    if id == s.firstFID ?? "0" { breadcrumbs.removeAll() }
                    else if let index = breadcrumbs.firstIndex(where: { $0.1 == id }) { breadcrumbs = Array(breadcrumbs.prefix(through: index)) }
                }
            } catch {
                await MainActor.run { self.error = error.localizedDescription }
            }
        }
    }

    private func backToRoot() {
        session = nil
        files = []
        breadcrumbs = []
        currentParent = "0"
    }
}

private struct PlatformPill: View {
    let platform: SharePlatform
    var body: some View {
        Text(platform.rawValue)
            .font(.caption.weight(.bold))
            .padding(.horizontal, 10).padding(.vertical, 6)
            .background(Color.indigo.opacity(0.1), in: Capsule())
            .foregroundStyle(.indigo)
    }
}

private struct ShareFileCard: View {
    let file: ShareFile
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                RoundedRectangle(cornerRadius: 12).fill(file.isDirectory ? Color.orange.opacity(0.13) : Color.indigo.opacity(0.1)).frame(width: 46, height: 46)
                    .overlay(Image(systemName: file.isDirectory ? "folder.fill" : icon).foregroundStyle(file.isDirectory ? Color.orange : Color.indigo))
                VStack(alignment: .leading, spacing: 4) {
                    Text(file.name).font(.headline).lineLimit(2).multilineTextAlignment(.leading)
                    if file.isDirectory {
                        Text("文件夹").font(.caption).foregroundStyle(.secondary)
                    } else {
                        Text(ByteCountFormatter.string(fromByteCount: file.size, countStyle: .file))
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                Spacer()
                Image(systemName: file.isDirectory ? "chevron.right" : "arrow.down.circle.fill")
                    .font(.system(size: 22)).foregroundStyle(file.isDirectory ? Color.secondary : Color.indigo)
            }
            .padding(14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
    private var icon: String {
        if file.name.lowercased().hasSuffix(".apk") || file.name.lowercased().hasSuffix(".ipa") { return "shippingbox.fill" }
        if file.name.lowercased().hasSuffix(".mp4") || file.name.lowercased().hasSuffix(".mkv") { return "film.fill" }
        if file.name.lowercased().hasSuffix(".jpg") || file.name.lowercased().hasSuffix(".png") { return "photo.fill" }
        if file.name.lowercased().hasSuffix(".zip") || file.name.lowercased().hasSuffix(".rar") { return "archivebox.fill" }
        return "doc.fill"
    }
}


private struct EmptyFilesView: View {
    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: "folder")
                .font(.system(size: 38))
                .foregroundStyle(.secondary)
            Text("没有文件")
                .font(.headline)
            Text("当前目录为空")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
