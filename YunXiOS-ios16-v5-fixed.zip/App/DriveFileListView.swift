import SwiftUI

struct DriveFileListView: View {
    let platform: SharePlatform
    @EnvironmentObject var model: AppModel
    @State private var files: [ShareFile] = []
    @State private var currentParent: String
    @State private var breadcrumbs: [(String, String)] = []
    @State private var loading = false
    @State private var error: String?

    init(platform: SharePlatform) {
        self.platform = platform
        _currentParent = State(initialValue: platform == .baidu ? "/" : "0")
    }

    private var rootID: String { platform == .baidu ? "/" : "0" }
    private var rootTitle: String { "\(platform.rawValue)网盘" }

    var body: some View {
        ZStack {
            AppBackground()
            VStack(spacing: 0) {
                if !breadcrumbs.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 6) {
                            Button("根目录") { jump(to: rootID, title: rootTitle) }
                            ForEach(Array(breadcrumbs.enumerated()), id: \.offset) { _, item in
                                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                                Button(item.0) { jump(to: item.1, title: item.0) }
                            }
                        }
                        .font(.subheadline.weight(.semibold))
                        .padding(.horizontal, 20).padding(.vertical, 8)
                    }
                }
                List {
                    ForEach(files) { file in
                        ShareFileCard(file: file) {
                            Task { await handle(file) }
                        }
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                    }
                }
                .listStyle(.plain)
                .overlay {
                    if files.isEmpty && !loading {
                        EmptyFilesView()
                    }
                }
            }
        }
        .navigationTitle(rootTitle)
        .navigationBarTitleDisplayMode(.large)
        .alert("加载失败", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
            Button("确定") { error = nil }
        } message: { Text(error ?? "") }
        .task { if files.isEmpty { await load(currentParent) } }
    }

    private func browser() -> DriveBrowser? {
        switch platform {
        case .quark:
            return QuarkService()
        case .baidu:
            return BaiduService()
        default:
            return nil
        }
    }

    private func load(_ parentID: String) async {
        guard let service = browser() else {
            await MainActor.run { error = "\(platform.rawValue) 暂不支持直接浏览个人网盘，敬请期待后续版本。" }
            return
        }
        await MainActor.run { loading = true; error = nil }
        do {
            let list = try await service.listDriveFiles(parentID: parentID, credential: model.credential(for: platform))
            await MainActor.run { files = list; loading = false }
        } catch {
            await MainActor.run { self.error = error.localizedDescription; loading = false }
        }
    }

    private func handle(_ file: ShareFile) async {
        guard let service = browser() else {
            await MainActor.run { error = "\(platform.rawValue) 暂不支持直接浏览个人网盘。" }
            return
        }
        if file.isDirectory {
            let path = file.path ?? ""
            let nextID: String = platform == .baidu ? (path.isEmpty ? "/\(file.name)" : path) : file.fid
            do {
                let list = try await service.listDriveFiles(parentID: nextID, credential: model.credential(for: platform))
                await MainActor.run {
                    breadcrumbs.append((file.name, nextID))
                    currentParent = nextID
                    files = list
                }
            } catch {
                await MainActor.run { self.error = error.localizedDescription }
            }
            return
        }
        do {
            await MainActor.run { loading = true }
            let link = try await service.getDriveDownloadLink(file: file, credential: model.credential(for: platform))
            let id = await DownloadManager.shared.enqueue(link, platform: platform)
            await MainActor.run {
                loading = false
                model.notify("已加入下载任务：\(file.name)\n任务 ID：\(id.uuidString.prefix(8))")
            }
        } catch {
            await MainActor.run { loading = false; self.error = error.localizedDescription }
        }
    }

    private func jump(to id: String, title: String) {
        guard let service = browser() else { return }
        Task {
            do {
                let list = try await service.listDriveFiles(parentID: id, credential: model.credential(for: platform))
                await MainActor.run {
                    currentParent = id
                    files = list
                    if id == rootID {
                        breadcrumbs.removeAll()
                    } else if let index = breadcrumbs.firstIndex(where: { $0.1 == id }) {
                        breadcrumbs = Array(breadcrumbs.prefix(through: index))
                    }
                }
            } catch {
                await MainActor.run { self.error = error.localizedDescription }
            }
        }
    }
}
