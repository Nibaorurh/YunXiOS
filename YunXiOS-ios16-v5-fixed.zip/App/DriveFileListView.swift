import SwiftUI

struct DriveFileListView: View {
    let platform: SharePlatform
    @EnvironmentObject var model: AppModel
    @State private var files: [ShareFile] = []
    @State private var currentParent: String
    @State private var breadcrumbs: [(String, String)] = []
    @State private var loading = false
    @State private var error: String?
    @State private var loginExpired = false
    @State private var showRelogin = false

    init(platform: SharePlatform) {
        self.platform = platform
        _currentParent = State(initialValue: DriveFileListView.rootIdentifier(for: platform))
    }

    /// 各网盘根目录的标识各不相同：
    /// 百度 `/`，迅雷空串（表示全部目录），139 网盘 `/`，夸克/UC/123 云盘 `0`。
    static func rootIdentifier(for platform: SharePlatform) -> String {
        switch platform {
        case .baidu: return "/"
        case .c139: return C139Constants.rootCatalog
        case .xunlei: return ""
        default: return "0"
        }
    }

    private var rootID: String { Self.rootIdentifier(for: platform) }
    private var rootTitle: String { "\(platform.rawValue)网盘" }

    /// 迅雷文件夹路径：接口用的是 `id`，子目录直接传 `fid` 即可。
    /// 百度需要完整路径（`/a/b`），其余网盘传 `fid`。
    private func childIdentifier(of file: ShareFile) -> String {
        switch platform {
        case .baidu:
            let path = file.path ?? ""
            return path.isEmpty ? "/\(file.name)" : path
        default:
            return file.fid
        }
    }

    var body: some View {
        ZStack {
            AppBackground()
            VStack(spacing: 0) {
                if !breadcrumbs.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 6) {
                            Button("根目录") { jump(to: rootID, title: rootTitle) }
                            ForEach(Array(breadcrumbs.enumerated()), id: \.offset) { _, item in
                                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                                Button(item.0) { jump(to: item.1, title: item.0) }
                            }
                        }
                        .font(.subheadline.weight(.semibold))
                        .padding(.horizontal, 20).padding(.vertical, 8)
                    }
                }
                List {
                    ForEach(files) { file in
                        ShareFileCard(file: file) {
                            Task { await handle(file) }
                        }
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                    }
                }
                .listStyle(.plain)
                .overlay {
                    if files.isEmpty && !loading {
                        if loginExpired {
                            ReloginHintView(platform: platform) { showRelogin = true }
                        } else {
                            EmptyFilesView()
                        }
                    }
                }
            }
        }
        .navigationTitle(rootTitle)
        .navigationBarTitleDisplayMode(.large)
        .alert("加载失败", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
            Button("确定") { error = nil }
        } message: { Text(error ?? "") }
        .sheet(isPresented: $showRelogin) {
            WebCookieLoginView(platform: platform) { cookie in
                guard !cookie.isEmpty else { return }
                model.save(platform: platform, credential: cookie)
                showRelogin = false
                loginExpired = false
                Task { await load(rootID) }
            }
        }
        .task { if files.isEmpty { await load(currentParent) } }
    }

    /// 六家网盘全部支持个人盘浏览，switch 已穷尽所有情况，因此返回非可选类型。
    private func browser() -> DriveBrowser {
        switch platform {
        case .quark: return QuarkService()
        case .uc: return UCService()
        case .xunlei: return XunleiService()
        case .baidu: return BaiduService()
        case .c139: return C139Service()
        case .pan123: return Pan123Service()
        }
    }

    private func load(_ parentID: String) async {
        let service = browser()
        guard !model.credential(for: platform).trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            await MainActor.run {
                loading = false
                error = "尚未配置 \(platform.rawValue) 的登录状态。请到「设置 → 认证」里选择 \(platform.rawValue)，点击「打开网盘官网登录并保存登录状态」，登录后点「保存登录状态」。"
            }
            return
        }
        await MainActor.run { loading = true; error = nil }
        do {
            let credential = model.credential(for: platform)
            let list = try await service.listDriveFiles(parentID: parentID, credential: credential)
            await MainActor.run { files = list; loading = false; loginExpired = false }
        } catch {
            // 登录态失效分两种：一种直接抛 .auth（能识别），另一种是服务端把未登录会话
            // 当成"空目录"静默返回 []。因此对空列表也要做一次会话确认，否则用户只会看到
            // "当前目录为空"，完全不知道为什么——这正是"网盘加载失败/登录失效"的观感来源。
            let expired = Self.looksLikeAuthFailure(error) || await confirmEmptyMeansExpired(service: service)
            await MainActor.run {
                self.error = error.localizedDescription
                loading = false
                self.loginExpired = expired
                if expired, Self.looksLikeAuthFailure(error) == false {
                    self.error = "\(platform.rawValue) 登录状态可能已失效，但服务器只返回了一个空目录。请重新登录确认。"
                }
            }
        }
    }

    /// 空列表的二次确认：只有拿到**明确的失效信号**才判定为登录失效，
    /// 否则宁可显示"没有文件"，也不能把正常的空网盘误报成登录失效。
    ///
    /// 判定依据：换一个肯定不存在的目录再请求一次。
    /// - 抛 `.auth` / `.notLoggedIn` → 明确失效，返回 true；
    /// - 抛「目录不存在」这类业务错误 → 会话其实是好的，返回 false；
    /// - 又是空列表，或网络错误 → 无法判定，返回 false（保守）。
    private func confirmEmptyMeansExpired(service: DriveBrowser) async -> Bool {
        let probeID = "yunx-session-probe-\(UUID().uuidString)"
        do {
            _ = try await service.listDriveFiles(parentID: probeID, credential: model.credential(for: platform))
            return false
        } catch let error as YunXError {
            switch error {
            case .auth, .notLoggedIn:
                return true
            default:
                return false
            }
        } catch {
            return false
        }
    }

    /// 判断是否是「登录态失效」类错误，是的话在空态里给一键重新登录入口。
    private static func looksLikeAuthFailure(_ error: Error) -> Bool {
        if case YunXError.auth = error { return true }
        if case YunXError.notLoggedIn = error { return true }
        let text = error.localizedDescription
        return text.contains("登录") || text.contains("凭证") || text.contains("失效")
    }

    private func handle(_ file: ShareFile) async {
        let service = browser()
        if file.isDirectory {
            let nextID = childIdentifier(of: file)
            do {
                let list = try await service.listDriveFiles(parentID: nextID, credential: model.credential(for: platform))
                await MainActor.run {
                    breadcrumbs.append((file.name, nextID))
                    currentParent = nextID
                    files = list
                    loginExpired = false
                }
            } catch {
                await MainActor.run {
                    self.error = error.localizedDescription
                    self.loginExpired = Self.looksLikeAuthFailure(error)
                }
            }
            return
        }
        do {
            await MainActor.run { loading = true }
            let link = try await service.getDriveDownloadLink(file: file, credential: model.credential(for: platform))
            let id = await DownloadManager.shared.enqueue(link, platform: platform)
            await MainActor.run {
                loading = false
                model.notify("已加入下载任务：\(file.name)\n任务 ID：\(id.uuidString.prefix(8))")
            }
        } catch {
            await MainActor.run { loading = false; self.error = error.localizedDescription }
        }
    }

    private func jump(to id: String, title: String) {
        let service = browser()
        Task {
            do {
                let list = try await service.listDriveFiles(parentID: id, credential: model.credential(for: platform))
                await MainActor.run {
                    currentParent = id
                    files = list
                    if id == rootID {
                        breadcrumbs.removeAll()
                    } else if let index = breadcrumbs.firstIndex(where: { $0.1 == id }) {
                        breadcrumbs = Array(breadcrumbs.prefix(through: index))
                    }
                }
            } catch {
                await MainActor.run { self.error = error.localizedDescription }
            }
        }
    }
}

/// 登录态失效时的空态：给一个直接重新登录的入口，而不是干巴巴的"没有文件"。
struct ReloginHintView: View {
    let platform: SharePlatform
    let action: () -> Void

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "person.crop.circle.badge.exclamationmark")
                .font(.system(size: 38))
                .foregroundStyle(.orange)
            Text("登录状态已失效")
                .font(.headline)
            Text("重新登录 \(platform.rawValue) 后即可浏览网盘文件")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button("重新登录 \(platform.rawValue)", systemImage: "safari", action: action)
                .buttonStyle(.borderedProminent)
                .padding(.top, 4)
        }
        .padding(30)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
