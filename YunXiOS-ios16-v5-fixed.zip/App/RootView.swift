import SwiftUI
import UIKit

struct RootView: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        TabView {
            ResolveView()
                .tabItem { Label("解析", systemImage: "link") }
            DriveView()
                .tabItem { Label("网盘", systemImage: "cloud.fill") }
            DownloadListView()
                .tabItem { Label("下载", systemImage: "arrow.down.circle.fill") }
            SettingsView()
                .tabItem { Label("设置", systemImage: "gearshape.fill") }
        }
        .tint(.indigo)
        .alert("提示", isPresented: Binding(get: { model.notice != nil }, set: { if !$0 { model.notice = nil } })) {
            Button("确定") { model.notice = nil }
        } message: {
            Text(model.notice ?? "")
        }
    }
}

struct DriveView: View {
    @EnvironmentObject var model: AppModel
    @State private var selected: SharePlatform = .quark
    @State private var showLogin = false
    @State private var webCredential = ""
    @State private var browse: SharePlatform? = nil

    private var drivePlatforms: [SharePlatform] { SharePlatform.allCases }

    var body: some View {
        NavigationStack {
            ZStack {
                AppBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("网盘")
                            .font(.system(size: 34, weight: .bold, design: .rounded))
                        Text("登录后可浏览网盘文件并直接下载")
                            .foregroundStyle(.secondary)

                        ForEach(drivePlatforms) { p in
                            DriveCard(platform: p,
                                      credential: model.credential(for: p),
                                      onTap: {
                                if model.credential(for: p).isEmpty {
                                    selected = p
                                    showLogin = true
                                } else {
                                    browse = p
                                }
                            },
                                      onReconfigure: {
                                selected = p
                                showLogin = true
                            },
                                      onClear: { model.clear(platform: p) })
                        }
                    }
                    .padding(20)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .background(
                NavigationLink(isActive: Binding(get: { browse != nil }, set: { if !$0 { browse = nil } })) {
                    if let platform = browse {
                        DriveFileListView(platform: platform)
                    } else {
                        EmptyView()
                    }
                } label: {
                    EmptyView()
                }
                .opacity(0)
            )
        }
        .sheet(isPresented: $showLogin) {
            WebCookieLoginView(platform: selected) { cookie in
                if !cookie.isEmpty {
                    model.save(platform: selected, credential: cookie)
                    showLogin = false
                }
            }
        }
    }
}

struct DriveCard: View {
    let platform: SharePlatform
    let credential: String
    let onTap: () -> Void
    let onReconfigure: () -> Void
    let onClear: () -> Void

    private var icon: String {
        switch platform {
        case .quark: return "Q"
        case .uc: return "UC"
        case .xunlei: return "迅"
        case .baidu: return "度"
        case .c139: return "139"
        case .pan123: return "123"
        }
    }

    private var color: Color {
        switch platform {
        case .quark: return .indigo
        case .uc: return .blue
        case .xunlei: return .orange
        case .baidu: return .teal
        case .c139: return .pink
        case .pan123: return .purple
        }
    }

    var body: some View {
        HStack(spacing: 15) {
            Circle().fill(color.opacity(0.14)).frame(width: 60, height: 60)
                .overlay(Text(icon).font(.system(size: icon.count > 2 ? 14 : 20, weight: .bold)).foregroundStyle(color))
            VStack(alignment: .leading, spacing: 6) {
                Text(platform.rawValue).font(.system(size: 19, weight: .semibold, design: .rounded))
                Text(credential.isEmpty ? "未配置 · 点击配置认证" : "已配置 · 点击浏览文件")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            Spacer()
            if credential.isEmpty {
                Button("配置") { onTap() }.buttonStyle(.borderedProminent)
            } else {
                Menu {
                    Button("重新配置") { onReconfigure() }
                    Button("清除认证", role: .destructive) { onClear() }
                } label: {
                    Image(systemName: "ellipsis.circle.fill").font(.system(size: 23)).foregroundStyle(.secondary)
                }
            }
        }
        .padding(17)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.primary.opacity(0.04)))
        .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .onTapGesture { onTap() }
    }
}

struct AppBackground: View {
    var body: some View {
        LinearGradient(colors: [Color.indigo.opacity(0.045), Color.purple.opacity(0.03), Color(.systemBackground)], startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
    }
}

struct AboutView: View {
    @State private var showTerms = false
    @State private var showPrivacy = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Spacer()
                        VStack(spacing: 12) {
                            Image("AppIcon")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80, height: 80)
                                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                            Text("YunX")
                                .font(.system(size: 22, weight: .bold, design: .rounded))
                            Text("云盘链接识别 · 资源管理 · 下载辅助")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                    }
                    .listRowBackground(Color.clear)
                }

                Section("关于我们") {
                    Text("YunX 是一款专注于云盘链接识别、资源管理、下载辅助的轻量工具。我们希望用更简洁的交互和更高效的流程，帮你更轻松地处理分享链接、管理下载任务，并在不同设备上获得一致、顺手的使用体验。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Section("免责声明") {
                    Text("本软件为第三方修改版本，仅供个人学习交流与技术研究使用，禁止用于任何商业用途或违法用途。本软件未对任何官方服务器进行攻击、入侵或数据篡改。网盘功能均直连各网盘官方接口，本软件不存储、不中转、不收集任何用户数据。使用本软件产生的一切后果由使用者本人承担。如有侵权请及时联系处理。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Section("当前版本") {
                    LabeledContent("系统", value: "iOS 16.2+")
                    LabeledContent("下载", value: "分片 + 断点续传")
                    LabeledContent("文件位置", value: "文件 App / YunX")
                }

                Section("联系我们") {
                    LabeledContent("邮箱", value: "757011143@qq.com")
                    Text("如果你在使用过程中遇到问题、发现异常，或者对功能有新的想法，欢迎通过邮箱与我们反馈。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("法律条款") {
                    Button("用户协议") { showTerms = true }
                    Button("隐私政策") { showPrivacy = true }
                }
            }
            .navigationTitle("关于")
        }
        .sheet(isPresented: $showTerms) { TermsView() }
        .sheet(isPresented: $showPrivacy) { PrivacyView() }
    }
}
