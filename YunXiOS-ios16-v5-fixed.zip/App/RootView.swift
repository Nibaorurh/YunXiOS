import SwiftUI

struct RootView: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        TabView {
            ResolveView()
                .tabItem { Label("解析", systemImage: "link") }
            DriveView()
                .tabItem { Label("网盘", systemImage: "cloud.fill") }
            DownloadListView()
                .tabItem { Label("下载", systemImage: "arrow.down.circle.fill") }
            SettingsView()
                .tabItem { Label("设置", systemImage: "gearshape.fill") }
        }
        .tint(.indigo)
        .alert("提示", isPresented: Binding(get: { model.notice != nil }, set: { if !$0 { model.notice = nil } })) {
            Button("确定") { model.notice = nil }
        } message: {
            Text(model.notice ?? "")
        }
    }
}

struct DriveView: View {
    @EnvironmentObject var model: AppModel
    @State private var selected: SharePlatform = .quark
    @State private var showLogin = false
    @State private var webCredential = ""

    private var drivePlatforms: [SharePlatform] { SharePlatform.allCases }

    var body: some View {
        NavigationStack {
            ZStack {
                AppBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("网盘")
                            .font(.system(size: 34, weight: .bold, design: .rounded))
                        Text("登录后可自动携带认证解析与下载")
                            .foregroundStyle(.secondary)

                        ForEach(drivePlatforms) { p in
                            DriveCard(platform: p,
                                      credential: model.credential(for: p),
                                      onTap: {
                                selected = p
                                showLogin = true
                            },
                                      onClear: { model.clear(platform: p) })
                        }
                    }
                    .padding(20)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
        }
        .sheet(isPresented: $showLogin) {
            WebCookieLoginView(platform: selected) { cookie in
                if !cookie.isEmpty {
                    model.save(platform: selected, credential: cookie)
                    showLogin = false
                }
            }
        }
    }
}

struct DriveCard: View {
    let platform: SharePlatform
    let credential: String
    let onTap: () -> Void
    let onClear: () -> Void

    private var icon: String {
        switch platform {
        case .quark: return "Q"
        case .uc: return "UC"
        case .xunlei: return "迅"
        case .baidu: return "度"
        case .c139: return "139"
        case .pan123: return "123"
        }
    }

    private var color: Color {
        switch platform {
        case .quark: return .indigo
        case .uc: return .blue
        case .xunlei: return .orange
        case .baidu: return .teal
        case .c139: return .pink
        case .pan123: return .purple
        }
    }

    var body: some View {
        HStack(spacing: 15) {
            Circle().fill(color.opacity(0.14)).frame(width: 60, height: 60)
                .overlay(Text(icon).font(.system(size: icon.count > 2 ? 14 : 20, weight: .bold)).foregroundStyle(color))
            VStack(alignment: .leading, spacing: 6) {
                Text(platform.rawValue).font(.system(size: 19, weight: .semibold, design: .rounded))
                Text(credential.isEmpty ? "未配置 · 点击配置认证" : "已配置 · 可用于解析下载")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            Spacer()
            if credential.isEmpty {
                Button("配置") { onTap() }.buttonStyle(.borderedProminent)
            } else {
                Menu {
                    Button("重新配置") { onTap() }
                    Button("清除认证", role: .destructive) { onClear() }
                } label: {
                    Image(systemName: "ellipsis.circle.fill").font(.system(size: 23)).foregroundStyle(.secondary)
                }
            }
        }
        .padding(17)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.primary.opacity(0.04)))
    }
}

struct AppBackground: View {
    var body: some View {
        LinearGradient(colors: [Color.indigo.opacity(0.045), Color.purple.opacity(0.03), Color(.systemBackground)], startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
    }
}

struct AboutView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("YunX iOS") {
                    Text("YunX / 云析 iOS 移植版")
                    Text("基于原 YunX AGPL-3.0 项目进行 iOS 移植。网盘接口可能随官方调整而失效。")
                }
                Section("当前版本") {
                    LabeledContent("系统", value: "iOS 16.2+")
                    LabeledContent("下载", value: "分片 + 断点续传")
                    LabeledContent("文件位置", value: "文件 App / YunX")
                }
            }
            .navigationTitle("关于")
        }
    }
}
