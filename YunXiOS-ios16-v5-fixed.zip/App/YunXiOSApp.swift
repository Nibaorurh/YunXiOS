import SwiftUI
import Combine

@main
struct YunXiOSApp: App {
    @StateObject private var model = AppModel()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(model)
                .preferredColorScheme(model.darkMode ? .dark : .light)
        }
    }
}

@MainActor
final class AppModel: ObservableObject {
    @Published var credentials: [String: String] = [:]
    @Published var notice: String?
    @Published var darkMode = false
    /// 下载线程数（分片数）。默认 32，最高 512，与 DownloadManager.maxSegments 保持一致。
    @Published var segmentCount = DownloadManager.defaultSegments
    @Published var autoRetry = true
    @Published var speedLimit: Int64 = 0

    /// 下载线程数的合法区间，供设置页复用。
    static let minSegments = 1
    static let maxSegments = DownloadManager.maxSegments

    let store = CredentialStore()
    private let settingsURL: URL

    init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        settingsURL = base.appendingPathComponent("yunx-settings.json")
        loadSettings()
        Task { await reloadCredentials() }
    }

    func reloadCredentials() async {
        var result: [String:String] = [:]
        for p in SharePlatform.allCases {
            if let v = await store.get(p.rawValue), !v.isEmpty { result[p.rawValue] = v }
        }
        credentials = result
    }

    func save(platform: SharePlatform, credential: String) {
        credentials[platform.rawValue] = credential
        Task { await store.set(platform.rawValue, credential) }
    }

    func clear(platform: SharePlatform) {
        credentials.removeValue(forKey: platform.rawValue)
        Task { await store.remove(platform.rawValue) }
    }

    func credential(for platform: SharePlatform) -> String { credentials[platform.rawValue] ?? "" }

    func loadSettings() {
        guard let data = try? Data(contentsOf: settingsURL),
              let values = try? JSONDecoder().decode(LocalSettings.self, from: data) else {
            publishSegmentCount()
            return
        }
        darkMode = values.darkMode
        segmentCount = min(max(values.segmentCount, Self.minSegments), Self.maxSegments)
        autoRetry = values.autoRetry
        speedLimit = max(0, values.speedLimit)
        publishSegmentCount()
    }

    func persistSettings() {
        segmentCount = min(max(segmentCount, Self.minSegments), Self.maxSegments)
        let values = LocalSettings(darkMode: darkMode, segmentCount: segmentCount, autoRetry: autoRetry, speedLimit: speedLimit)
        if let data = try? JSONEncoder().encode(values) { try? data.write(to: settingsURL, options: .atomic) }
        publishSegmentCount()
    }

    /// 把线程数写进 UserDefaults，DownloadManager 在下载时直接读取，避免跨 actor 传递设置。
    private func publishSegmentCount() {
        UserDefaults.standard.set(segmentCount, forKey: DownloadManager.segmentCountKey)
    }

    func notify(_ message: String) { notice = message }

    private struct LocalSettings: Codable {
        let darkMode: Bool
        let segmentCount: Int
        let autoRetry: Bool
        let speedLimit: Int64
    }
}
