import SwiftUI
import Combine

@main
struct YunXiOSApp: App {
    @StateObject private var model = AppModel()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(model)
                .preferredColorScheme(model.darkMode ? .dark : .light)
        }
    }
}

@MainActor
final class AppModel: ObservableObject {
    @Published var credentials: [String: String] = [:]
    @Published var notice: String?
    @Published var darkMode = false
    @Published var segmentCount = 8
    @Published var autoRetry = true
    @Published var speedLimit: Int64 = 0

    let store = CredentialStore()
    private let settingsURL: URL

    init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        settingsURL = base.appendingPathComponent("yunx-settings.json")
        loadSettings()
        Task { await reloadCredentials() }
    }

    func reloadCredentials() async {
        var result: [String:String] = [:]
        for p in SharePlatform.allCases {
            if let v = await store.get(p.rawValue), !v.isEmpty { result[p.rawValue] = v }
        }
        credentials = result
    }

    func save(platform: SharePlatform, credential: String) {
        credentials[platform.rawValue] = credential
        Task { await store.set(platform.rawValue, credential) }
    }

    func clear(platform: SharePlatform) {
        credentials.removeValue(forKey: platform.rawValue)
        Task { await store.remove(platform.rawValue) }
    }

    func credential(for platform: SharePlatform) -> String { credentials[platform.rawValue] ?? "" }

    func loadSettings() {
        guard let data = try? Data(contentsOf: settingsURL),
              let values = try? JSONDecoder().decode(LocalSettings.self, from: data) else { return }
        darkMode = values.darkMode
        segmentCount = min(max(values.segmentCount, 1), 16)
        autoRetry = values.autoRetry
        speedLimit = max(0, values.speedLimit)
    }

    func persistSettings() {
        let values = LocalSettings(darkMode: darkMode, segmentCount: segmentCount, autoRetry: autoRetry, speedLimit: speedLimit)
        if let data = try? JSONEncoder().encode(values) { try? data.write(to: settingsURL, options: .atomic) }
    }

    func notify(_ message: String) { notice = message }

    private struct LocalSettings: Codable {
        let darkMode: Bool
        let segmentCount: Int
        let autoRetry: Bool
        let speedLimit: Int64
    }
}
