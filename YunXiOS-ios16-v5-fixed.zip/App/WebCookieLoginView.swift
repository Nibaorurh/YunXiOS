import SwiftUI
import WebKit

/// 网盘官方网页登录。WKWebView 使用系统持久化 WebsiteDataStore，登录 Cookie 会保留；
/// 点击“保存登录状态”后同时把 Cookie 保存到 App Keychain，供解析接口使用。
struct WebCookieLoginView: View {
    let platform: SharePlatform
    let completion: (String) -> Void
    @Environment(\.dismiss) private var dismiss

    init(platform: SharePlatform, completion: @escaping (String) -> Void) {
        self.platform = platform
        self.completion = completion
    }

    private var url: URL {
        switch platform {
        case .quark: return URL(string: "https://pan.quark.cn/")!
        // 直接进桌面版「我的网盘」，这样保留下来的 Cookie / 登录态才包含个人盘接口
        // 所需的字段（只停在首页时往往拿不到）。
        case .uc: return URL(string: "https://drive.uc.cn/")!
        case .xunlei: return URL(string: "https://pan.xunlei.com/?path=%2F")!
        case .baidu: return URL(string: "https://pan.baidu.com/disk/main")!
        case .c139: return URL(string: "https://yun.139.com/w/#/index")!
        case .pan123: return URL(string: "https://yun.123pan.cn/")!
        }
    }

    var body: some View {
        NavigationStack {
            LoginWebView(url: url) { cookie in
                guard !cookie.isEmpty else { return }
                completion(cookie)
                dismiss()
            }
            .navigationTitle("登录 \(platform.rawValue)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("关闭") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("保存登录状态") {
                        NotificationCenter.default.post(name: .captureYunXCookie, object: nil)
                    }
                }
            }
        }
    }
}

extension Notification.Name {
    static let captureYunXCookie = Notification.Name("captureYunXCookie")
}

struct LoginWebView: UIViewRepresentable {
    let url: URL
    let completion: (String) -> Void

    /// 桌面版 Safari User-Agent。夸克 / UC 的登录页在手机版下无法在 WebView 内完成登录，
    /// 必须伪装成电脑浏览器，才能进入可用的桌面登录流程。
    private static let desktopUserAgent =
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"

    func makeCoordinator() -> Coordinator { Coordinator(completion: completion) }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        // default() 是持久化数据仓库：退出 App 后 Cookie 仍然保留。
        configuration.websiteDataStore = .default()
        configuration.defaultWebpagePreferences.preferredContentMode = .desktop

        let web = WKWebView(frame: .zero, configuration: configuration)
        // 关键：以桌面浏览器身份访问，避免被重定向到手机版登录页。
        web.customUserAgent = Self.desktopUserAgent
        web.allowsBackForwardNavigationGestures = true
        web.navigationDelegate = context.coordinator
        context.coordinator.webView = web
        context.coordinator.observer = NotificationCenter.default.addObserver(
            forName: .captureYunXCookie, object: nil, queue: .main
        ) { _ in
            context.coordinator.captureCookies()
        }
        web.load(URLRequest(url: url))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    static func dismantleUIView(_ uiView: WKWebView, coordinator: Coordinator) {
        if let observer = coordinator.observer {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        let completion: (String) -> Void
        weak var webView: WKWebView?
        var observer: NSObjectProtocol?

        init(completion: @escaping (String) -> Void) {
            self.completion = completion
        }

        func captureCookies() {
            guard let webView = webView else { return }
            // 部分站点把 access_token 放在 localStorage 而不是 Cookie 里（迅雷即如此），
            // 因此除了 Cookie，还要从页面存储中把 deviceid / credentials 一并捞出来。
            let readStorage = """
            (function () {
              var out = {};
              try {
                for (var i = 0; i < localStorage.length; i++) {
                  var k = localStorage.key(i);
                  var v = localStorage.getItem(k) || '';
                  out[k] = v;
                }
              } catch (e) {}
              return JSON.stringify(out);
            })();
            """
            webView.evaluateJavaScript(readStorage) { [weak self] storage, _ in
                guard let self = self else { return }
                let storagePairs = Coordinator.storagePairs(from: storage)
                webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { cookies in
                    let valid = cookies.filter { !$0.value.isEmpty }
                    var parts = valid.map { "\($0.name)=\($0.value)" }
                    parts.append(contentsOf: storagePairs)
                    let cookie = parts.joined(separator: "; ")
                    DispatchQueue.main.async {
                        self.completion(cookie)
                    }
                }
            }
        }

        /// 把 localStorage 里对鉴权有用的字段摊平成 `key=value` 形式，交给凭据解析层识别。
        static func storagePairs(from value: Any?) -> [String] {
            guard let json = value as? String,
                  let data = json.data(using: .utf8),
                  let dict = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { return [] }
            var pairs: [String] = []
            for (key, raw) in dict {
                let text = raw as? String ?? ""
                guard !text.isEmpty else { continue }
                let lowered = key.lowercased()
                if lowered.hasSuffix("credentials") || lowered.hasSuffix("captcha") {
                    // 形如 key = {"token_info":{"access_token":"..."},"device_id":"..."}
                    if let nested = text.data(using: .utf8),
                       let object = (try? JSONSerialization.jsonObject(with: nested)) as? [String: Any] {
                        pairs.append(contentsOf: flatten(object))
                    }
                } else if lowered.contains("device") || lowered.contains("token") || lowered.contains("auth") {
                    pairs.append("\(key)=\(text)")
                }
            }
            return pairs
        }

        private static func flatten(_ object: [String: Any], prefix: String = "") -> [String] {
            var pairs: [String] = []
            for (key, value) in object {
                if let nested = value as? [String: Any] {
                    pairs.append(contentsOf: flatten(nested, prefix: ""))
                } else if let text = value as? String, !text.isEmpty {
                    let name = prefix.isEmpty ? key : "\(prefix).\(key)"
                    pairs.append("\(name)=\(text)")
                }
            }
            return pairs
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            // 页面跳转完成后刷新 Cookie 仓库，但不自动关闭页面，避免用户尚未登录时保存空状态。
            webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { _ in }
        }

        deinit {
            if let observer = observer {
                NotificationCenter.default.removeObserver(observer)
            }
        }

        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     preferences: WKWebpagePreferences,
                     decisionHandler: @escaping (WKNavigationActionPolicy, WKWebpagePreferences) -> Void) {
            // 每次导航都强制桌面内容模式，防止站点把页面降级成移动版。
            preferences.preferredContentMode = .desktop
            decisionHandler(.allow, preferences)
        }
    }
}
