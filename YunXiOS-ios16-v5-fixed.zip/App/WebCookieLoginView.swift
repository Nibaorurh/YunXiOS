import SwiftUI
import WebKit

/// 网盘官方网页登录。WKWebView 使用系统持久化 WebsiteDataStore，登录 Cookie 会保留；
/// 点击“保存登录状态”后同时把 Cookie 保存到 App Keychain，供解析接口使用。
struct WebCookieLoginView: View {
    let platform: SharePlatform
    let completion: (String) -> Void
    @Environment(\.dismiss) private var dismiss

    init(platform: SharePlatform, completion: @escaping (String) -> Void) {
        self.platform = platform
        self.completion = completion
    }

    private var url: URL {
        switch platform {
        case .quark: return URL(string: "https://pan.quark.cn/")!
        case .uc: return URL(string: "https://fast.uc.cn/")!
        case .xunlei: return URL(string: "https://pan.xunlei.com/")!
        case .baidu: return URL(string: "https://pan.baidu.com/")!
        case .c139: return URL(string: "https://yun.139.com/")!
        case .pan123: return URL(string: "https://user.123pan.cn/centerlogin?redirect_url=https%3A%2F%2Fyun.123pan.cn&source_page=website")!
        }
    }

    var body: some View {
        NavigationStack {
            LoginWebView(url: url) { cookie in
                guard !cookie.isEmpty else { return }
                completion(cookie)
                dismiss()
            }
            .navigationTitle("登录 \(platform.rawValue)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("关闭") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("保存登录状态") {
                        NotificationCenter.default.post(name: .captureYunXCookie, object: nil)
                    }
                }
            }
        }
    }
}

extension Notification.Name {
    static let captureYunXCookie = Notification.Name("captureYunXCookie")
}

struct LoginWebView: UIViewRepresentable {
    let url: URL
    let completion: (String) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(completion: completion) }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        // default() 是持久化数据仓库：退出 App 后 Cookie 仍然保留。
        configuration.websiteDataStore = .default()
        let web = WKWebView(frame: .zero, configuration: configuration)
        web.allowsBackForwardNavigationGestures = true
        web.navigationDelegate = context.coordinator
        context.coordinator.webView = web
        context.coordinator.observer = NotificationCenter.default.addObserver(
            forName: .captureYunXCookie, object: nil, queue: .main
        ) { _ in
            context.coordinator.captureCookies()
        }
        web.load(URLRequest(url: url))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    static func dismantleUIView(_ uiView: WKWebView, coordinator: Coordinator) {
        if let observer = coordinator.observer {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        let completion: (String) -> Void
        weak var webView: WKWebView?
        var observer: NSObjectProtocol?

        init(completion: @escaping (String) -> Void) {
            self.completion = completion
        }

        func captureCookies() {
            guard let webView = webView else { return }
            webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { cookies in
                let valid = cookies.filter { !$0.value.isEmpty }
                let cookie = valid
                    .map { "\($0.name)=\($0.value)" }
                    .joined(separator: "; ")
                DispatchQueue.main.async {
                    self.completion(cookie)
                }
            }
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            // 页面跳转完成后刷新 Cookie 仓库，但不自动关闭页面，避免用户尚未登录时保存空状态。
            webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { _ in }
        }
    }
}
