import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var model: AppModel
    @State private var selected = SharePlatform.quark
    @State private var credential = ""
    @State private var showWebLogin = false
    @State private var showAbout = false

    var body: some View {
        NavigationStack {
            ZStack {
                AppBackground()
                List {
                    Section("下载") {
                        settingRow(icon: "slider.horizontal.3", title: "下载线程数", detail: "每个大文件默认 \(model.segmentCount) 个分片") {
                            Stepper("\(model.segmentCount)", value: $model.segmentCount, in: 1...16)
                                .onChange(of: model.segmentCount) { _ in model.persistSettings() }
                        }
                        Toggle(isOn: $model.autoRetry) {
                            SettingLabel(icon: "arrow.clockwise", title: "失败自动重试", detail: "失败后自动重试 3 次")
                        }.onChange(of: model.autoRetry) { _ in model.persistSettings() }
                    }

                    Section("认证") {
                        Picker("网盘", selection: $selected) {
                            ForEach(SharePlatform.allCases) { Text($0.rawValue).tag($0) }
                        }
                        HStack {
                            SecureField("网页登录后自动保存；也支持手动粘贴 Cookie/JWT", text: $credential)
                            Button("保存") {
                                model.save(platform: selected, credential: credential.trimmingCharacters(in: .whitespacesAndNewlines))
                                credential = ""
                            }
                            .buttonStyle(.borderedProminent)
                        }
                        if true {
                            Button("打开网盘官网登录并保存登录状态", systemImage: "safari") { showWebLogin = true }
                        }
                        HStack {
                            Text("当前状态")
                            Spacer()
                            Text(model.credential(for: selected).isEmpty ? "未配置" : "已配置")
                                .foregroundStyle(model.credential(for: selected).isEmpty ? .secondary : .green)
                        }
                        .font(.subheadline)
                    }

                    Section("已保存账号") {
                        ForEach(SharePlatform.allCases) { p in
                            HStack {
                                Text(p.rawValue)
                                Spacer()
                                Text(model.credential(for: p).isEmpty ? "未配置" : "已配置")
                                    .font(.caption).foregroundStyle(.secondary)
                                if !model.credential(for: p).isEmpty {
                                    Button(role: .destructive) { model.clear(platform: p) } label: { Image(systemName: "trash") }
                                }
                            }
                        }
                    }

                    Section("通用") {
                        Toggle(isOn: $model.darkMode) {
                            SettingLabel(icon: "moon.fill", title: "深色模式", detail: "跟随 App 设置")
                        }.onChange(of: model.darkMode) { _ in model.persistSettings() }
                        Button("导出日志", systemImage: "doc.text") { model.notify("日志导出入口已预留；真实网络请求不会包含认证 Cookie。") }
                        Button("关于") { showAbout = true }
                    }
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("设置")
        }
        .sheet(isPresented: $showWebLogin) {
            WebCookieLoginView(platform: selected) { cookie in
                if !cookie.isEmpty {
                    model.save(platform: selected, credential: cookie)
                    showWebLogin = false
                }
            }
        }
        .sheet(isPresented: $showAbout) { AboutView() }
        .onAppear { credential = model.credential(for: selected) }
        .onChange(of: selected) { v in credential = model.credential(for: v) }
    }

    @ViewBuilder
    private func settingRow<Content: View>(icon: String, title: String, detail: String, @ViewBuilder content: () -> Content) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).frame(width: 28).foregroundStyle(.indigo)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.headline)
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            content()
        }
    }
}

private struct SettingLabel: View {
    let icon: String
    let title: String
    let detail: String
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon).frame(width: 28).foregroundStyle(.indigo)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.headline)
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
        }
    }
}
