import SwiftUI
import UIKit

struct SettingsView: View {
    @EnvironmentObject var model: AppModel
    @State private var selected = SharePlatform.quark
    @State private var credential = ""
    @State private var showWebLogin = false
    @State private var showAbout = false
    /// 线程数输入框的文本缓冲。用户直接键盘输入时用它，失焦/回车才提交，
    /// 避免输入过程中被 `Int` 解析失败打断。
    @State private var segmentText = ""

    var body: some View {
        NavigationStack {
            ZStack {
                AppBackground()
                List {
                    Section("下载") {
                        VStack(alignment: .leading, spacing: 10) {
                            SettingLabel(icon: "slider.horizontal.3",
                                         title: "下载线程数",
                                         detail: "默认 32，最高 512。大文件会按此数量并发分片下载")
                            SegmentCountField(text: $segmentText,
                                              commit: commitSegmentText,
                                              step: stepSegmentCount)
                        }
                        .padding(.vertical, 4)
                        Toggle(isOn: $model.autoRetry) {
                            SettingLabel(icon: "arrow.clockwise", title: "失败自动重试", detail: "失败后自动重试 3 次")
                        }.onChange(of: model.autoRetry) { _ in model.persistSettings() }
                    }

                    Section("认证") {
                        Picker("网盘", selection: $selected) {
                            ForEach(SharePlatform.allCases) { Text($0.rawValue).tag($0) }
                        }
                        HStack {
                            SecureField("网页登录后自动保存；也支持手动粘贴 Cookie/JWT", text: $credential)
                            Button("保存") {
                                model.save(platform: selected, credential: credential.trimmingCharacters(in: .whitespacesAndNewlines))
                                credential = ""
                            }
                            .buttonStyle(.borderedProminent)
                        }
                        Button("打开网盘官网登录并保存登录状态", systemImage: "safari") { showWebLogin = true }
                        HStack {
                            Text("当前状态")
                            Spacer()
                            Text(model.credential(for: selected).isEmpty ? "未配置" : "已配置")
                                .foregroundStyle(model.credential(for: selected).isEmpty ? Color.secondary : Color.green)
                        }
                        .font(.subheadline)
                    }

                    Section("已保存账号") {
                        ForEach(SharePlatform.allCases) { p in
                            HStack {
                                Text(p.rawValue)
                                Spacer()
                                Text(model.credential(for: p).isEmpty ? "未配置" : "已配置")
                                    .font(.caption).foregroundStyle(.secondary)
                                if !model.credential(for: p).isEmpty {
                                    Button(role: .destructive) { model.clear(platform: p) } label: { Image(systemName: "trash") }
                                }
                            }
                        }
                    }

                    Section("通用") {
                        Toggle(isOn: $model.darkMode) {
                            SettingLabel(icon: "moon.fill", title: "深色模式", detail: "跟随 App 设置")
                        }.onChange(of: model.darkMode) { _ in model.persistSettings() }
                        Button("导出日志", systemImage: "doc.text") { model.notify("日志导出入口已预留；真实网络请求不会包含认证 Cookie。") }
                        Button("关于") { showAbout = true }
                    }
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("设置")
        }
        .sheet(isPresented: $showWebLogin) {
            WebCookieLoginView(platform: selected) { cookie in
                if !cookie.isEmpty {
                    model.save(platform: selected, credential: cookie)
                    showWebLogin = false
                }
            }
        }
        .sheet(isPresented: $showAbout) { AboutView() }
        .onAppear {
            credential = model.credential(for: selected)
            segmentText = "\(model.segmentCount)"
        }
        .onChange(of: selected) { v in credential = model.credential(for: v) }
        .onChange(of: model.segmentCount) { value in
            // 外部（如步进按钮）改动后同步输入框文本。
            if Int(segmentText) != value { segmentText = "\(value)" }
        }
    }

    /// 提交输入框内容：非法或超范围时回退并夹紧到 1...512。
    private func commitSegmentText(_ raw: String) {
        let value = Int(raw.trimmingCharacters(in: .whitespacesAndNewlines)) ?? model.segmentCount
        let clamped = min(max(value, AppModel.minSegments), AppModel.maxSegments)
        model.segmentCount = clamped
        model.persistSettings()
        segmentText = "\(clamped)"
    }

    /// 步进按钮：按 1 递增/递减（长按可快速调整），边界处保持不变。
    private func stepSegmentCount(_ delta: Int) {
        let next = min(max(model.segmentCount + delta, AppModel.minSegments), AppModel.maxSegments)
        guard next != model.segmentCount else { return }
        model.segmentCount = next
        model.persistSettings()
        segmentText = "\(next)"
    }
}

/// 线程数输入控件：中间可键盘直接输入，两侧提供 +/- 步进，右侧显示范围提示。
/// 参考的是常见的「输入框 + 加减按钮」样式，而不是只能用 Stepper 点加减。
private struct SegmentCountField: View {
    @Binding var text: String
    let commit: (String) -> Void
    let step: (Int) -> Void

    @FocusState private var focused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                stepperButton(systemName: "minus", delta: -1)

                TextField("32", text: $text)
                    .keyboardType(.numberPad)
                    .multilineTextAlignment(.center)
                    .font(.system(.body, design: .rounded).weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 9)
                    .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .focused($focused)
                    .onSubmit { commit(text) }
                    .onChange(of: focused) { isFocused in
                        if !isFocused { commit(text) }
                    }

                stepperButton(systemName: "plus", delta: 1)
            }
            Text("可取值范围 1–512，直接点击数字即可键盘输入")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }

    private func stepperButton(systemName: String, delta: Int) -> some View {
        Button { step(delta) } label: {
            Image(systemName: systemName)
                .font(.system(size: 15, weight: .bold))
                .frame(width: 40, height: 40)
                .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .buttonStyle(.plain)
        .foregroundStyle(.indigo)
    }
}

private struct SettingLabel: View {
    let icon: String
    let title: String
    let detail: String
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon).frame(width: 28).foregroundStyle(.indigo)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.headline)
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
        }
    }
}
