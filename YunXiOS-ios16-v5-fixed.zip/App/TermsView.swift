import SwiftUI

struct TermsView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Group {
                        Text("1. 接受条款")
                            .font(.headline)
                        Text("欢迎使用 YunX。当你下载、安装或使用本软件时，即表示你已阅读并同意本用户协议的全部内容。如果你不同意，请停止使用本软件。")

                        Text("2. 软件性质")
                            .font(.headline)
                        Text("本软件为第三方修改版本，仅提供云盘链接识别、资源管理与下载辅助功能。本软件不存储、不中转、不收集任何用户数据，所有网盘功能均直连各网盘官方接口。")

                        Text("3. 使用限制")
                            .font(.headline)
                        Text("本软件仅供个人学习交流与技术研究使用，禁止用于任何商业用途或违法用途。用户应遵守各网盘平台的用户协议与相关法律法规。")

                        Text("4. 知识产权")
                            .font(.headline)
                        Text("本软件界面、代码及品牌标识归开发者所有。第三方网盘名称、商标及相关权益归其各自权利人所有。")

                        Text("5. 免责声明")
                            .font(.headline)
                        Text("本软件不保证各网盘接口永久可用，亦不保证功能结果的正确性、完整性或安全性。使用本软件产生的一切后果由使用者本人承担。")

                        Text("6. 协议修改")
                            .font(.headline)
                        Text("开发者有权根据实际需要对用户协议进行修改，修改后的协议将在软件更新或相关页面公布。")
                    }
                }
                .padding()
            }
            .navigationTitle("用户协议")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
