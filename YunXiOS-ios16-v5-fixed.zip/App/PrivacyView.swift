import SwiftUI

struct PrivacyView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Group {
                        Text("1. 信息收集")
                            .font(.headline)
                        Text("YunX 高度重视用户隐私。本软件在运行过程中不会主动收集、上传或存储你的个人隐私信息。你在设置中输入的网盘 Cookie / Token 等认证信息仅保存在本机 Keychain 中，不会上传到任何第三方服务器。")

                        Text("2. 数据使用")
                            .font(.headline)
                        Text("本软件所有网络请求均直接发往各网盘官方接口，用于实现链接解析、文件列表获取与下载功能。我们不会中转、分析或保存你的文件内容、分享链接及下载记录。")

                        Text("3. 本地存储")
                            .font(.headline)
                        Text("为提供下载任务管理与断点续传能力，本软件会在设备本地保存下载任务状态、分片文件及临时数据。你可以随时在下载列表中删除这些文件。")

                        Text("4. 第三方服务")
                            .font(.headline)
                        Text("本软件使用各网盘官方公开接口。第三方服务的隐私政策由各平台自行制定，请在使用前仔细阅读对应平台的隐私条款。")

                        Text("5. 信息安全")
                            .font(.headline)
                        Text("我们采取合理的技术措施保护本机存储的认证信息，但互联网传输无法做到绝对安全。请妥善保管你的账号信息，避免泄露。")

                        Text("6. 联系我们")
                            .font(.headline)
                        Text("如对本隐私政策有任何疑问，可通过“关于我们”中的联系方式与我们联系。")
                    }
                }
                .padding()
            }
            .navigationTitle("隐私政策")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
