import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

public struct HTTPResponse: Sendable {
    public let data: Data
    public let response: HTTPURLResponse
    public let setCookies: [String]
}

public actor HTTPClient {
    public static let shared = HTTPClient()
    private let session: URLSession
    public init() {
        let config = URLSessionConfiguration.default
        config.httpAdditionalHeaders = ["Accept": "application/json, text/plain, */*"]
        self.session = URLSession(configuration: config)
    }
    public func send(_ request: URLRequest) async throws -> HTTPResponse {
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw YunXError.invalidResponse }
        let cookies = HTTPCookie.cookies(withResponseHeaderFields: http.allHeaderFields.reduce(into: [:]) { result, pair in
            result[String(describing: pair.key)] = String(describing: pair.value)
        }, for: http.url ?? request.url!).map { "\($0.name)=\($0.value)" }
        guard (200..<600).contains(http.statusCode) else { throw YunXError.server("HTTP \(http.statusCode)") }
        return HTTPResponse(data: data, response: http, setCookies: cookies)
    }
}

public enum JSONValue {
    public static func object(_ data: Data) throws -> [String: Any] {
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw YunXError.invalidResponse }
        return obj
    }
    public static func array(_ data: Data) throws -> [Any] {
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [Any] else { throw YunXError.invalidResponse }
        return obj
    }
}

public extension URLRequest {
    mutating func setJSON(_ object: Any) throws {
        httpBody = try JSONSerialization.data(withJSONObject: object, options: [])
        setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
    }
    mutating func setForm(_ values: [String: String]) {
        let body = values.map { "\($0.key.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? $0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? $0.value)" }.joined(separator: "&")
        httpBody = Data(body.utf8); setValue("application/x-www-form-urlencoded; charset=UTF-8", forHTTPHeaderField: "Content-Type")
    }
}

public enum HTTPHelpers {
    public static func request(url: String, method: String = "GET", cookie: String? = nil, headers: [String:String] = [:]) throws -> URLRequest {
        guard let u = URL(string: url) else { throw YunXError.invalidURL }
        var r = URLRequest(url: u); r.httpMethod = method
        if let cookie = cookie { r.setValue(cookie, forHTTPHeaderField: "Cookie") }
        headers.forEach { r.setValue($0.value, forHTTPHeaderField: $0.key) }
        return r
    }
    public static func string(_ value: Any?) -> String { value as? String ?? "" }
    public static func int64(_ value: Any?) -> Int64 {
        if let n = value as? NSNumber { return n.int64Value }
        if let s = value as? String { return Int64(s) ?? 0 }
        return 0
    }
    public static func bool(_ value: Any?) -> Bool {
        if let b = value as? Bool { return b }; if let n = value as? NSNumber { return n.boolValue }; return false
    }
    public static func dict(_ v: Any?) -> [String:Any] { v as? [String:Any] ?? [:] }
    public static func arr(_ v: Any?) -> [[String:Any]] { v as? [[String:Any]] ?? [] }
}
