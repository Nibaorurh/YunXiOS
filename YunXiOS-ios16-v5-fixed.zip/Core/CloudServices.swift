import Foundation

public protocol ShareResolver: Sendable {
    func createSession(parsed: ParsedShare, password: String?, credential: String) async throws -> ShareSession
    func listFiles(session: ShareSession, parentID: String, credential: String) async throws -> [ShareFile]
    func getDownloadLink(session: ShareSession, file: ShareFile, credential: String) async throws -> DownloadLink
}

private enum QuarkAPI {
    static let base = "https://drive-pc.quark.cn/1/clouddrive"
    static func url(_ path: String, _ extra: [URLQueryItem] = []) -> URL {
        var c = URLComponents(string: base + path)!
        var items = [
            URLQueryItem(name: "pr", value: "ucpro"),
            URLQueryItem(name: "fr", value: "pc"),
            URLQueryItem(name: "uc_param_str", value: ""),
            URLQueryItem(name: "__t", value: String(Int(Date().timeIntervalSince1970 * 1000))),
            URLQueryItem(name: "__dt", value: "1000")
        ]
        items.append(contentsOf: extra)
        c.queryItems = items
        return c.url!
    }
}

private enum QuarkCookie {
    static func withoutPuus(_ cookie: String) -> String {
        cookie.split(separator: ";").map(String.init).map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.hasPrefix("__puus=") }
            .joined(separator: "; ")
    }

    static func merge(_ original: String, _ setCookies: [String]) -> String {
        var map: [String:String] = [:]
        for pair in original.split(separator: ";") {
            let p = pair.trimmingCharacters(in: .whitespaces)
            if let i = p.firstIndex(of: "=") { map[String(p[..<i])] = String(p[p.index(after: i)...]) }
        }
        for cookie in setCookies {
            let p = cookie.split(separator: ";", maxSplits: 1, omittingEmptySubsequences: true).first.map(String.init) ?? ""
            if let i = p.firstIndex(of: "=") {
                let name = String(p[..<i])
                if name == "__puus" || name == "__pus" { map[name] = String(p[p.index(after: i)...]) }
            }
        }
        return map.map { "\($0.key)=\($0.value)" }.joined(separator: "; ")
    }
}

public struct QuarkService: ShareResolver, Sendable {
    private let http: HTTPClient
    public init(http: HTTPClient = .shared) { self.http = http }

    public func createSession(parsed: ParsedShare, password: String?, credential: String) async throws -> ShareSession {
        guard !credential.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw YunXError.auth("夸克需要 Cookie。请在设置里登录夸克并提取 Cookie。")
        }
        var request = try HTTPHelpers.request(
            url: QuarkAPI.url("/share/sharepage/token").absoluteString,
            method: "POST",
            cookie: credential,
            headers: headers(referer: "https://pan.quark.cn/")
        )
        try request.setJSON([
            "pwd_id": parsed.shareID,
            "passcode": password ?? parsed.password ?? "",
            "support_visit_limit_private_share": true
        ])

        let response = try await http.send(request)
        let root = try JSONValue.object(response.data)
        let data = HTTPHelpers.dict(root["data"])
        let token = HTTPHelpers.string(data["stoken"])
        guard !token.isEmpty else {
            let message = HTTPHelpers.string(root["message"]).isEmpty ? "获取夸克分享凭证失败" : HTTPHelpers.string(root["message"])
            throw YunXError.server(message)
        }
        return ShareSession(shareID: parsed.shareID,
                            token: token,
                            title: HTTPHelpers.string(data["title"]),
                            firstFID: HTTPHelpers.string(data["first_fid"]).isEmpty ? "0" : HTTPHelpers.string(data["first_fid"]))
    }

    public func listFiles(session: ShareSession, parentID: String, credential: String) async throws -> [ShareFile] {
        var result: [ShareFile] = []
        var page = 1
        while page <= 100 {
            let url = QuarkAPI.url("/share/sharepage/detail", [
                .init(name: "pwd_id", value: session.shareID),
                .init(name: "stoken", value: session.token),
                .init(name: "pdir_fid", value: parentID),
                .init(name: "ver", value: "2"),
                .init(name: "force", value: "0"),
                .init(name: "_page", value: String(page)),
                .init(name: "_size", value: "100"),
                .init(name: "_fetch_total", value: "1"),
                .init(name: "_fetch_banner", value: "0"),
                .init(name: "_fetch_share", value: "0"),
                .init(name: "_sort", value: "file_type:asc,file_name:asc")
            ])
            let request = try HTTPHelpers.request(url: url.absoluteString,
                                                   cookie: credential,
                                                   headers: headers(referer: "https://pan.quark.cn/"))
            let response = try await http.send(request)
            let root = try JSONValue.object(response.data)
            if let code = root["code"] as? NSNumber, code.intValue != 0 {
                throw YunXError.server(HTTPHelpers.string(root["message"]).isEmpty ? "夸克解析失败（code \(code)）" : HTTPHelpers.string(root["message"]))
            }
            let data = HTTPHelpers.dict(root["data"])
            let array = HTTPHelpers.arr(data["list"])
            let batch = array.map {
                ShareFile(
                    fid: HTTPHelpers.string($0["fid"]),
                    name: HTTPHelpers.string($0["file_name"]),
                    size: HTTPHelpers.int64($0["size"]),
                    isDirectory: HTTPHelpers.bool($0["dir"]) || HTTPHelpers.int64($0["isdir"]) == 1,
                    parentFID: HTTPHelpers.string($0["pdir_fid"]),
                    fidToken: HTTPHelpers.string($0["share_fid_token"]),
                    modified: HTTPHelpers.string($0["updated_at"])
                )
            }
            result.append(contentsOf: batch)
            if batch.count < 100 { break }
            page += 1
        }
        guard !result.isEmpty || parentID == (session.firstFID ?? "0") else { return [] }
        return result
    }

    public func getDownloadLink(session: ShareSession, file: ShareFile, credential: String) async throws -> DownloadLink {
        // Quark 的分享文件不能直接用分享 fid 下载；先临时转存到个人盘，再取得下载 URL。
        let tempRoot = try await findOrCreateFolder(name: "YunX临时转存", parent: "0", cookie: credential)
        let taskFolder = try await createFolder(name: "tr_\(Int(Date().timeIntervalSince1970 * 1000))_\(Int.random(in: 10000...999999))",
                                                parent: tempRoot,
                                                cookie: credential)

        let saveRequestBody: [String:Any] = [
            "fid_list": [file.fid],
            "fid_token_list": [file.fidToken],
            "to_pdir_fid": taskFolder,
            "pwd_id": session.shareID,
            "stoken": session.token,
            "pdir_fid": file.parentFID,
            "scene": "link"
        ]
        var saveRequest = try HTTPHelpers.request(url: QuarkAPI.url("/share/sharepage/save").absoluteString,
                                                   method: "POST",
                                                   cookie: credential,
                                                   headers: headers(referer: "https://pan.quark.cn/"))
        try saveRequest.setJSON(saveRequestBody)
        let saveResponse = try await http.send(saveRequest)
        let saveRoot = try JSONValue.object(saveResponse.data)
        let taskID = HTTPHelpers.string(HTTPHelpers.dict(saveRoot["data"])["task_id"])
        guard !taskID.isEmpty else { throw YunXError.server(HTTPHelpers.string(saveRoot["message"]).isEmpty ? "夸克转存失败" : HTTPHelpers.string(saveRoot["message"])) }

        var savedFID = ""
        for _ in 0..<15 {
            try await Task.sleep(nanoseconds: 700_000_000)
            let url = QuarkAPI.url("/task", [
                .init(name: "task_id", value: taskID),
                .init(name: "retry_index", value: "0")
            ])
            let request = try HTTPHelpers.request(url: url.absoluteString, cookie: credential, headers: headers(referer: "https://pan.quark.cn/"))
            let root = try JSONValue.object((try await http.send(request)).data)
            let data = HTTPHelpers.dict(root["data"])
            let saveAs = HTTPHelpers.dict(data["save_as"])
            if let ids = saveAs["save_as_top_fids"] as? [Any], let id = ids.first as? String, !id.isEmpty {
                savedFID = id
                break
            }
            if HTTPHelpers.int64(data["status"]) == 3 || HTTPHelpers.int64(data["task_status"]) == 3 {
                throw YunXError.server("夸克转存失败")
            }
        }
        guard !savedFID.isEmpty else { throw YunXError.server("夸克转存超时，请重试") }

        // 某些会话的 __puus 过期后 /file/download 会返回权限错误；先尝试刷新。
        let refreshedCookie = await refreshCookie(credential) ?? credential

        var downloadRequest = try HTTPHelpers.request(url: QuarkAPI.url("/file/download", [
            .init(name: "sys", value: "win32"),
            .init(name: "ve", value: "3.23.2")
        ]).absoluteString,
                                                            method: "POST",
                                                            cookie: refreshedCookie,
                                                            headers: headers(referer: "https://pan.quark.cn/"))
        try downloadRequest.setJSON(["fids": [savedFID]])
        let downloadResponse = try await http.send(downloadRequest)
        let downloadRoot = try JSONValue.object(downloadResponse.data)
        if let code = downloadRoot["code"] as? NSNumber, code.intValue != 0 {
            throw YunXError.server(HTTPHelpers.string(downloadRoot["message"]).isEmpty ? "夸克获取下载链接失败" : HTTPHelpers.string(downloadRoot["message"]))
        }
        guard let item = (downloadRoot["data"] as? [[String:Any]])?.first else {
            throw YunXError.server("夸克没有返回下载链接")
        }
        let rawURL = HTTPHelpers.string(item["download_url"])
        guard let url = URL(string: rawURL), !rawURL.isEmpty else { throw YunXError.server("夸克下载链接无效") }

        return DownloadLink(fid: file.fid,
                            filename: HTTPHelpers.string(item["file_name"]).isEmpty ? file.name : HTTPHelpers.string(item["file_name"]),
                            url: url,
                            size: HTTPHelpers.int64(item["size"]) > 0 ? HTTPHelpers.int64(item["size"]) : file.size,
                            headers: ["Referer": "https://pan.quark.cn/"],
                            cleanupDirectoryFID: taskFolder)
    }

    private func findOrCreateFolder(name: String, parent: String, cookie: String) async throws -> String {
        let listURL = QuarkAPI.url("/file", [
            .init(name: "pdir_fid", value: parent),
            .init(name: "page", value: "1"),
            .init(name: "size", value: "100")
        ])
        let listRequest = try HTTPHelpers.request(url: listURL.absoluteString, cookie: cookie, headers: headers(referer: "https://pan.quark.cn/"))
        let root = try JSONValue.object((try await http.send(listRequest)).data)
        let items = HTTPHelpers.arr(HTTPHelpers.dict(root["data"])["list"])
        if let item = items.first(where: { HTTPHelpers.bool($0["dir"]) && HTTPHelpers.string($0["file_name"]) == name }) {
            let fid = HTTPHelpers.string(item["fid"])
            if !fid.isEmpty { return fid }
        }
        return try await createFolder(name: name, parent: parent, cookie: cookie)
    }

    private func createFolder(name: String, parent: String, cookie: String) async throws -> String {
        var request = try HTTPHelpers.request(url: QuarkAPI.url("/file").absoluteString, method: "POST", cookie: cookie, headers: headers(referer: "https://pan.quark.cn/"))
        try request.setJSON(["pdir_fid": parent, "file_name": name, "dir_path": "", "dir_init_lock": false])
        let root = try JSONValue.object((try await http.send(request)).data)
        let fid = HTTPHelpers.string(HTTPHelpers.dict(root["data"])["fid"])
        guard !fid.isEmpty else { throw YunXError.server("创建夸克临时目录失败") }
        return fid
    }

    private func refreshCookie(_ cookie: String) async -> String? {
        let requestURL = QuarkAPI.url("/config")
        guard let request = try? HTTPHelpers.request(url: requestURL.absoluteString,
                                                     cookie: QuarkCookie.withoutPuus(cookie),
                                                     headers: headers(referer: "https://pan.quark.cn/")),
              let response = try? await http.send(request) else { return nil }
        let merged = QuarkCookie.merge(cookie, response.setCookies)
        return merged == cookie ? nil : merged
    }

    private func headers(referer: String) -> [String:String] {
        [
            "User-Agent": QuarkConstants.ua,
            "Origin": "https://pan.quark.cn",
            "Referer": referer,
            "Accept": "application/json, text/plain, */*"
        ]
    }
}
