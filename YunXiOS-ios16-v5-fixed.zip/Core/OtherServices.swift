import Foundation

public struct UCService: ShareResolver, Sendable {
    private let http: HTTPClient; public init(http: HTTPClient = .shared){self.http=http}
    public func createSession(parsed: ParsedShare, password: String?, credential: String) async throws -> ShareSession {
        var r = try HTTPHelpers.request(url: UCConstants.tokenURL, method:"POST", cookie:credential, headers:["User-Agent":UCConstants.ua]); try r.setJSON(["pwd_id":parsed.shareID,"passcode":password ?? parsed.password ?? ""]); let root=try JSONValue.object((try await http.send(r)).data); let d=HTTPHelpers.dict(root["data"]); guard let st=d["stoken"] as? String, !st.isEmpty else{throw YunXError.server("UC 分享凭证获取失败")}; return ShareSession(shareID:parsed.shareID, token:st, title:HTTPHelpers.string(d["title"]), firstFID:HTTPHelpers.string(d["first_fid"]))
    }
    public func listFiles(session: ShareSession, parentID: String, credential: String) async throws -> [ShareFile] {
        var all:[ShareFile]=[]; var page=1; repeat { var c=URLComponents(string:UCConstants.detailURL)!; c.queryItems=[URLQueryItem(name:"pwd_id",value:session.shareID),URLQueryItem(name:"stoken",value:session.token),URLQueryItem(name:"pdir_fid",value:parentID),URLQueryItem(name:"page",value:"\(page)"),URLQueryItem(name:"size",value:"100"),URLQueryItem(name:"fetch_total",value:"1")]; let r=try HTTPHelpers.request(url:c.url!.absoluteString,cookie:credential,headers:["User-Agent":UCConstants.ua,"Origin":UCConstants.origin,"Referer":UCConstants.origin+"/"]); let root=try JSONValue.object((try await http.send(r)).data); let d=HTTPHelpers.dict(root["data"]); let arr=HTTPHelpers.arr(HTTPHelpers.dict(d["detail_info"])["list"]); let batch=arr.map{ShareFile(fid:HTTPHelpers.string($0["fid"]),name:HTTPHelpers.string($0["file_name"]),size:HTTPHelpers.int64($0["size"]),isDirectory:HTTPHelpers.bool($0["dir"]),parentFID:HTTPHelpers.string($0["pdir_fid"]),fidToken:HTTPHelpers.string($0["share_fid_token"]),modified:HTTPHelpers.string($0["updated_at"]))}; all += batch; page += 1; if batch.count<100 || page>100{break} } while true; return all
    }
    public func getDownloadLink(session: ShareSession, file: ShareFile, credential: String) async throws -> DownloadLink {
        var save=try HTTPHelpers.request(url:UCConstants.saveURL,method:"POST",cookie:credential,headers:["User-Agent":UCConstants.ua]); try save.setJSON(["pwd_id":session.shareID,"stoken":session.token,"pdir_fid":file.parentFID,"to_pdir_fid":"0","fid_list":[file.fid],"fid_token_list":[file.fidToken],"scene":"link"]); let sr=try JSONValue.object((try await http.send(save)).data); let taskID=HTTPHelpers.string(HTTPHelpers.dict(sr["data"])["task_id"]); guard !taskID.isEmpty else {throw YunXError.server("UC 转存失败")}; for _ in 0..<30 { try await Task.sleep(nanoseconds:1_000_000_000); var q=try HTTPHelpers.request(url:"\(UCConstants.taskURL)&task_id=\(taskID)&retry_index=0",cookie:credential,headers:["User-Agent":UCConstants.ua]); let tr=try JSONValue.object((try await http.send(q)).data); let d=HTTPHelpers.dict(tr["data"]); if let f=(d["save_as"] as? [String:Any])?["save_as_top_fids"] as? [Any], let fid=f.first as? String, !fid.isEmpty { var dl=try HTTPHelpers.request(url:UCConstants.downloadURL,method:"POST",cookie:credential,headers:["User-Agent":UCConstants.ua,"Referer":UCConstants.origin+"/"]); try dl.setJSON(["fids":[fid],"pwd_id":session.shareID,"stoken":session.token,"fids_token":[file.fidToken]]); let root=try JSONValue.object((try await http.send(dl)).data); if let item=(root["data"] as? [[String:Any]])?.first, let u=URL(string:HTTPHelpers.string(item["download_url"])) { return DownloadLink(fid:file.fid,filename:file.name,url:u,size:file.size,headers:["Referer":UCConstants.origin+"/"]) } } }; throw YunXError.server("UC 获取下载链接超时")
    }
}

extension UCService: DriveBrowser {
    /// UC 个人盘的查询串。`origin` 必须带上，否则会被判为非法来源。
    private func driveURL(_ path: String, _ extra: [URLQueryItem] = []) -> URL {
        var c = URLComponents(string: UCConstants.apiBase + path)!
        var items = [
            URLQueryItem(name: "pr", value: "UCBrowser"),
            URLQueryItem(name: "fr", value: "pc"),
            URLQueryItem(name: "uc_param_str", value: ""),
            URLQueryItem(name: "__t", value: String(Int(Date().timeIntervalSince1970 * 1000))),
            URLQueryItem(name: "__dt", value: "1000")
        ]
        items.append(contentsOf: extra)
        c.queryItems = items
        return c.url!
    }

    private func driveHeaders(referer: String) -> [String: String] {
        ["User-Agent": UCConstants.ua,
         "Origin": UCConstants.origin,
         "Referer": referer,
         "Accept": "application/json, text/plain, */*"]
    }

    public func listDriveFiles(parentID: String, credential: String) async throws -> [ShareFile] {
        guard !credential.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw YunXError.auth("UC 网盘需要 Cookie。请在设置里登录 UC 网盘并提取 Cookie。")
        }
        var result: [ShareFile] = []
        var page = 1
        while page <= 100 {
            let url = driveURL("/1/clouddrive/file", [
                URLQueryItem(name: "pdir_fid", value: parentID.isEmpty ? "0" : parentID),
                URLQueryItem(name: "page", value: String(page)),
                URLQueryItem(name: "size", value: "100"),
                URLQueryItem(name: "sort", value: "file_type:asc,file_name:asc"),
                URLQueryItem(name: "fetch_total", value: "1"),
                URLQueryItem(name: "force", value: "0")
            ])
            let request = try HTTPHelpers.request(url: url.absoluteString,
                                                 cookie: credential,
                                                 headers: driveHeaders(referer: "\(UCConstants.origin)/"))
            let root = try JSONValue.object((try await http.send(request)).data)
            if let code = root["code"] as? NSNumber, code.intValue != 0 {
                let message = HTTPHelpers.string(root["message"]).isEmpty ? "UC 网盘读取失败（code \(code)）" : HTTPHelpers.string(root["message"])
                if result.isEmpty { throw YunXError.server(message) } else { break }
            }
            let batch = HTTPHelpers.arr(HTTPHelpers.dict(root["data"])["list"]).map { item in
                ShareFile(
                    fid: HTTPHelpers.string(item["fid"]),
                    name: HTTPHelpers.string(item["file_name"]),
                    size: HTTPHelpers.int64(item["size"]),
                    isDirectory: HTTPHelpers.bool(item["dir"]) || HTTPHelpers.int64(item["isdir"]) == 1,
                    parentFID: HTTPHelpers.string(item["pdir_fid"]),
                    modified: HTTPHelpers.string(item["updated_at"])
                )
            }
            result.append(contentsOf: batch)
            if batch.count < 100 { break }
            page += 1
        }
        return result
    }

    public func getDriveDownloadLink(file: ShareFile, credential: String) async throws -> DownloadLink {
        var request = try HTTPHelpers.request(url: driveURL("/1/clouddrive/file/download", [
            URLQueryItem(name: "entry", value: "ft")
        ]).absoluteString,
                                              method: "POST",
                                              cookie: credential,
                                              headers: driveHeaders(referer: "\(UCConstants.origin)/"))
        try request.setJSON(["fids": [file.fid]])
        let root = try JSONValue.object((try await http.send(request)).data)
        if let code = root["code"] as? NSNumber, code.intValue != 0 {
            throw YunXError.server(HTTPHelpers.string(root["message"]).isEmpty ? "UC 获取下载链接失败" : HTTPHelpers.string(root["message"]))
        }
        guard let item = (root["data"] as? [[String:Any]])?.first,
              let url = URL(string: HTTPHelpers.string(item["download_url"])),
              !HTTPHelpers.string(item["download_url"]).isEmpty else {
            throw YunXError.server("UC 没有返回下载链接")
        }
        return DownloadLink(fid: file.fid,
                            filename: HTTPHelpers.string(item["file_name"]).isEmpty ? file.name : HTTPHelpers.string(item["file_name"]),
                            url: url,
                            size: HTTPHelpers.int64(item["size"]) > 0 ? HTTPHelpers.int64(item["size"]) : file.size,
                            headers: ["Referer": "\(UCConstants.origin)/",
                                      "User-Agent": UCConstants.ua])
    }
}

public struct BaiduService: ShareResolver, Sendable {    private let http: HTTPClient; public init(http:HTTPClient = .shared){self.http=http}
    public func createSession(parsed: ParsedShare, password: String?, credential: String) async throws -> ShareSession {
        let surl=parsed.shareID; let pwd=password ?? parsed.password ?? ""; var r=try HTTPHelpers.request(url:"https://pan.baidu.com/share/verify?4",method:"POST",cookie:credential,headers:["User-Agent":BaiduConstants.uaWeb,"Referer":"https://pan.baidu.com/s/\(surl)"]); r.setForm(["pwd":pwd,"vcode_str":"","vcode":""]); let root=try JSONValue.object((try await http.send(r)).data); if HTTPHelpers.int64(root["errno"]) != 0 { throw YunXError.server(HTTPHelpers.string(root["show_msg"]).isEmpty ? "百度提取码错误" : HTTPHelpers.string(root["show_msg"])) }; return ShareSession(shareID:surl,token:HTTPHelpers.string(root["randsk"]),title:"百度分享")
    }
    public func listFiles(session: ShareSession, parentID: String, credential: String) async throws -> [ShareFile] {
        var c=URLComponents(string:"https://pan.baidu.com/rest/2.0/xpan/share?method=list")!; c.queryItems=[URLQueryItem(name:"shorturl",value:session.shareID),URLQueryItem(name:"randsk",value:session.token),URLQueryItem(name:"page",value:"1"),URLQueryItem(name:"num",value:"100"),URLQueryItem(name:"dir",value:parentID)]; var r=try HTTPHelpers.request(url:c.url!.absoluteString,cookie:credential,headers:["User-Agent":BaiduConstants.uaWeb,"Referer":"https://pan.baidu.com/s/\(session.shareID)"]); let root=try JSONValue.object((try await http.send(r)).data); if HTTPHelpers.int64(root["errno"]) != 0 {throw YunXError.server(HTTPHelpers.string(root["errmsg"]).isEmpty ? "百度文件列表失败" : HTTPHelpers.string(root["errmsg"]))}; return HTTPHelpers.arr(root["list"]).map{ShareFile(fid:HTTPHelpers.string($0["fs_id"]),name:HTTPHelpers.string($0["server_filename"]),size:HTTPHelpers.int64($0["size"]),isDirectory:HTTPHelpers.int64($0["isdir"])==1,parentFID:parentID,path:HTTPHelpers.string($0["path"]))}
    }
    public func getDownloadLink(session: ShareSession, file: ShareFile, credential: String) async throws -> DownloadLink {
        var meta=try HTTPHelpers.request(url:"https://pan.baidu.com/api/filemetas?dlink=1&fsids=\(file.fid)&bdstoken=",cookie:credential,headers:["User-Agent":BaiduConstants.uaWeb]); let root=try JSONValue.object((try await http.send(meta)).data); let d=(root["info"] as? [[String:Any]])?.first; guard let u=URL(string:HTTPHelpers.string(d?["dlink"])),!u.absoluteString.isEmpty else{throw YunXError.server("百度获取直链失败")}; return DownloadLink(fid:file.fid,filename:file.name,url:u,size:file.size,headers:["Referer":"https://pan.baidu.com/"])
    }
}

extension BaiduService: DriveBrowser {
    public func listDriveFiles(parentID: String, credential: String) async throws -> [ShareFile] {
        let cookie = credential.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cookie.isEmpty else {
            throw YunXError.auth("百度需要 Cookie（BDUSS）。请在设置里登录百度网盘并提取 Cookie。")
        }
        let directory = parentID.isEmpty ? "/" : parentID

        // 优先走 xpan 接口；凭据不完整时回退到 Web 端 /api/list。
        do {
            return try await listViaXPan(directory: directory, cookie: cookie)
        } catch let error as YunXError {
            // 只有“鉴权/令牌”类错误才值得回退，其它错误（如目录不存在）直接透出。
            guard case .auth = error else { throw error }
            return try await listViaWeb(directory: directory, cookie: cookie)
        }
    }

    /// `user-agent: netdisk` 的 xpan 接口，需要 BDUSS + bdstoken。
    private func listViaXPan(directory: String, cookie: String) async throws -> [ShareFile] {
        let bdstoken = try await fetchBaiduBDSToken(cookie)
        guard !bdstoken.isEmpty else {
            throw YunXError.auth("百度登录状态里没有 bdstoken，无法读取网盘。请重新登录百度网盘。")
        }
        var result: [ShareFile] = []
        var page = 1
        while page <= 100 {
            var c = URLComponents(string: "https://pan.baidu.com/rest/2.0/xpan/file?method=list")!
            c.queryItems = [
                URLQueryItem(name: "dir", value: directory),
                URLQueryItem(name: "order", value: "name"),
                URLQueryItem(name: "desc", value: "0"),
                URLQueryItem(name: "page", value: String(page)),
                URLQueryItem(name: "num", value: "100"),
                URLQueryItem(name: "web", value: "1"),
                URLQueryItem(name: "bdstoken", value: bdstoken),
                URLQueryItem(name: "channel", value: "chunlei"),
                URLQueryItem(name: "clienttype", value: "0")
            ]
            let r = try HTTPHelpers.request(url: c.url!.absoluteString,
                                          cookie: cookie,
                                          headers: ["User-Agent": BaiduConstants.uaWeb, "Referer": "https://pan.baidu.com/disk/home"])
            let root = try JSONValue.object((try await http.send(r)).data)
            let errno = HTTPHelpers.int64(root["errno"])
            if errno != 0 {
                let msg = HTTPHelpers.string(root["errmsg"]).isEmpty ? "百度文件列表失败（errno \(errno)）" : "\(HTTPHelpers.string(root["errmsg"]))（errno \(errno)）"
                // -6 是百度典型的“身份校验失败/凭据不足”，转成 auth 触发 Web 回退。
                if errno == -6 || errno == -7 || errno == 2 { throw YunXError.auth(msg) }
                throw YunXError.server(msg)
            }
            let batch = HTTPHelpers.arr(root["list"]).map { item in
                ShareFile(
                    fid: HTTPHelpers.string(item["fs_id"]),
                    name: HTTPHelpers.string(item["server_filename"]),
                    size: HTTPHelpers.int64(item["size"]),
                    isDirectory: HTTPHelpers.int64(item["isdir"]) == 1,
                    parentFID: directory,
                    path: HTTPHelpers.string(item["path"])
                )
            }
            result.append(contentsOf: batch)
            if batch.count < 100 { break }
            page += 1
        }
        return result
    }

    /// Web 端 `/api/list`，与浏览器「我的网盘」页面同源，凭据要求更低。
    private func listViaWeb(directory: String, cookie: String) async throws -> [ShareFile] {
        var result: [ShareFile] = []
        var page = 1
        while page <= 100 {
            var c = URLComponents(string: "https://pan.baidu.com/api/list")!
            c.queryItems = [
                URLQueryItem(name: "dir", value: directory),
                URLQueryItem(name: "order", value: "name"),
                URLQueryItem(name: "desc", value: "0"),
                URLQueryItem(name: "page", value: String(page)),
                URLQueryItem(name: "num", value: "100"),
                URLQueryItem(name: "channel", value: "chunlei"),
                URLQueryItem(name: "web", value: "1"),
                URLQueryItem(name: "app_id", value: BaiduConstants.appID),
                URLQueryItem(name: "clienttype", value: "0"),
                URLQueryItem(name: "bdstoken", value: (try? await fetchBaiduBDSToken(cookie)) ?? "")
            ]
            let r = try HTTPHelpers.request(url: c.url!.absoluteString,
                                          cookie: cookie,
                                          headers: ["User-Agent": BaiduConstants.uaWeb, "Referer": "https://pan.baidu.com/disk/home"])
            let root = try JSONValue.object((try await http.send(r)).data)
            let errno = HTTPHelpers.int64(root["errno"])
            if errno != 0 {
                let raw = HTTPHelpers.string(root["errmsg"])
                let msg = raw.isEmpty ? "百度文件列表失败（errno \(errno)）" : "\(raw)（errno \(errno)）"
                // 首次请求就失败必须抛出，不能静默返回空数组——否则界面会误显示“当前目录为空”。
                if result.isEmpty { throw YunXError.auth(msg) } else { break }
            }
            let batch = HTTPHelpers.arr(root["list"]).map { item in
                ShareFile(
                    fid: HTTPHelpers.string(item["fs_id"]),
                    name: HTTPHelpers.string(item["server_filename"]),
                    size: HTTPHelpers.int64(item["size"]),
                    isDirectory: HTTPHelpers.int64(item["isdir"]) == 1,
                    parentFID: directory,
                    path: HTTPHelpers.string(item["path"])
                )
            }
            result.append(contentsOf: batch)
            if batch.count < 100 { break }
            page += 1
        }
        return result
    }

    public func getDriveDownloadLink(file: ShareFile, credential: String) async throws -> DownloadLink {
        let cookie = credential.trimmingCharacters(in: .whitespacesAndNewlines)
        let bdstoken = (try? await fetchBaiduBDSToken(cookie)) ?? ""
        var meta = try HTTPHelpers.request(url: "https://pan.baidu.com/api/filemetas?dlink=1&fsids=[\(file.fid)]&bdstoken=\(bdstoken)",
                                          cookie: cookie,
                                          headers: ["User-Agent": BaiduConstants.uaWeb, "Referer": "https://pan.baidu.com/disk/home"])
        let root = try JSONValue.object((try await http.send(meta)).data)
        if HTTPHelpers.int64(root["errno"]) != 0 {
            throw YunXError.server(HTTPHelpers.string(root["errmsg"]).isEmpty ? "百度获取直链失败" : HTTPHelpers.string(root["errmsg"]))
        }
        let d = (root["info"] as? [[String:Any]])?.first
        var raw = HTTPHelpers.string(d?["dlink"])
        guard !raw.isEmpty else { throw YunXError.server("百度获取直链失败") }
        // filemetas 返回的 dlink 需要带上 access_token 才能下载。
        if !raw.contains("access_token="), let token = d?["access_token"] as? String, !token.isEmpty {
            raw += raw.contains("?") ? "&access_token=\(token)" : "?access_token=\(token)"
        }
        guard let u = URL(string: raw) else { throw YunXError.server("百度下载链接无效") }
        return DownloadLink(fid: file.fid, filename: file.name, url: u, size: file.size, headers: ["Referer": "https://pan.baidu.com/"])
    }

    private func fetchBaiduBDSToken(_ credential: String) async throws -> String {
        let r = try HTTPHelpers.request(url: "https://pan.baidu.com/api/getinfo?bdstoken=&channel=chunlei&clienttype=0&web=1",
                                       cookie: credential,
                                       headers: ["User-Agent": BaiduConstants.uaWeb, "Referer": "https://pan.baidu.com/disk/home"])
        let root = try JSONValue.object((try await http.send(r)).data)
        guard HTTPHelpers.int64(root["errno"]) == 0 else { return "" }
        return HTTPHelpers.string(root["bdstoken"])
    }
}

public struct Pan123Service: ShareResolver, Sendable {
    private let http: HTTPClient; public init(http:HTTPClient = .shared){self.http=http}
    public func createSession(parsed: ParsedShare,password:String?,credential:String) async throws -> ShareSession { return ShareSession(shareID:parsed.shareID,token:password ?? parsed.password ?? "",title:"123云盘分享") }
    public func listFiles(session: ShareSession,parentID:String,credential:String) async throws -> [ShareFile] { var c=URLComponents(string:Pan123Constants.shareURL)!; c.queryItems=[URLQueryItem(name:"limit",value:"100"),URLQueryItem(name:"next",value:"0"),URLQueryItem(name:"orderBy",value:"file_name"),URLQueryItem(name:"orderDirection",value:"asc"),URLQueryItem(name:"shareKey",value:session.shareID),URLQueryItem(name:"ParentFileId",value:parentID),URLQueryItem(name:"Page",value:"1")]; if !session.token.isEmpty { c.queryItems?.append(URLQueryItem(name:"SharePwd",value:session.token)) }; let r=try HTTPHelpers.request(url:c.url!.absoluteString,headers:["User-Agent":"Dart/3.12 (dart:io)"]); let root=try JSONValue.object((try await http.send(r)).data); let d=HTTPHelpers.dict(root["data"]); return HTTPHelpers.arr(d["InfoList"]).map{ShareFile(fid:HTTPHelpers.string($0["FileId"]),name:HTTPHelpers.string($0["FileName"]),size:HTTPHelpers.int64($0["Size"]),isDirectory:HTTPHelpers.int64($0["Type"])==1,parentFID:parentID,fidToken:HTTPHelpers.string($0["S3KeyFlag"])) }
    }
    public func getDownloadLink(session:ShareSession,file:ShareFile,credential:String) async throws -> DownloadLink { var c=URLComponents(string:Pan123Constants.shareDownloadInfoURL)!; c.queryItems=[URLQueryItem(name:"ShareKey",value:session.shareID),URLQueryItem(name:"FileID",value:file.fid)]; let r=try HTTPHelpers.request(url:c.url!.absoluteString,headers:["User-Agent":"Dart/3.12 (dart:io)"]); let root=try JSONValue.object((try await http.send(r)).data); let d=HTTPHelpers.dict(root["data"]); let uStr=HTTPHelpers.string(d["DownloadURL"]).isEmpty ? HTTPHelpers.string(d["DownloadUrl"]) : HTTPHelpers.string(d["DownloadURL"]); guard let u=URL(string:uStr),!uStr.isEmpty else{throw YunXError.server("123云盘获取直链失败")}; return DownloadLink(fid:file.fid,filename:file.name,url:u,size:file.size,headers:["Referer":"https://yun.123pan.cn/"]) }
}

extension Pan123Service: DriveBrowser {
    /// 123 云盘的 Web 端鉴权：登录后浏览器里存的是 `authorization`（JWT）。
    /// 用户可能粘贴完整的 Cookie 串，也可能只粘 JWT，这里统一抽出来。
    private func authToken(_ credential: String) -> String {
        let trimmed = credential.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.contains("=") {
            for pair in trimmed.split(separator: ";") {
                let item = pair.trimmingCharacters(in: .whitespaces)
                guard let index = item.firstIndex(of: "=") else { continue }
                let name = String(item[..<index]).lowercased()
                if name == "authorization" || name == "token" || name == "access_token" || name == "pan_token" {
                    return String(item[item.index(after: index)...])
                        .replacingOccurrences(of: "Bearer ", with: "")
                        .trimmingCharacters(in: .whitespaces)
                }
            }
            return ""
        }
        return trimmed.replacingOccurrences(of: "Bearer ", with: "")
    }

    private func driveHeaders(token: String) -> [String: String] {
        ["User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36",
         "Authorization": "Bearer \(token)",
         "Origin": "https://yun.123pan.cn",
         "Referer": "https://yun.123pan.cn/",
         "Accept": "application/json, text/plain, */*"]
    }

    public func listDriveFiles(parentID: String, credential: String) async throws -> [ShareFile] {
        let token = authToken(credential)
        guard !token.isEmpty else {
            throw YunXError.auth("123 云盘需要登录态（Authorization）。请在设置里登录 123 云盘并保存登录状态。")
        }
        var result: [ShareFile] = []
        var page = 1
        while page <= 100 {
            var c = URLComponents(string: Pan123Constants.fileListURL)!
            c.queryItems = [
                URLQueryItem(name: "driveId", value: "0"),
                URLQueryItem(name: "limit", value: "100"),
                URLQueryItem(name: "next", value: "0"),
                URLQueryItem(name: "orderBy", value: "file_name"),
                URLQueryItem(name: "orderDirection", value: "asc"),
                URLQueryItem(name: "parentFileId", value: parentID.isEmpty ? "0" : parentID),
                URLQueryItem(name: "trashed", value: "false"),
                URLQueryItem(name: "SearchData", value: ""),
                URLQueryItem(name: "Page", value: String(page)),
                URLQueryItem(name: "OnlyLookAbnormalFile", value: "0"),
                URLQueryItem(name: "event", value: "homeListFile"),
                URLQueryItem(name: "operateType", value: "1"),
                URLQueryItem(name: "inDirectSpace", value: "false")
            ]
            let r = try HTTPHelpers.request(url: c.url!.absoluteString, headers: driveHeaders(token: token))
            let root = try JSONValue.object((try await http.send(r)).data)
            if let code = root["code"] as? NSNumber, code.intValue != 0 {
                let message = HTTPHelpers.string(root["message"]).isEmpty ? "123 云盘读取失败（code \(code)）" : HTTPHelpers.string(root["message"])
                if result.isEmpty { throw YunXError.server(message) } else { break }
            }
            let data = HTTPHelpers.dict(root["data"])
            let batch = HTTPHelpers.arr(data["InfoList"]).map { item in
                ShareFile(
                    fid: HTTPHelpers.string(item["FileId"]),
                    name: HTTPHelpers.string(item["FileName"]),
                    size: HTTPHelpers.int64(item["Size"]),
                    isDirectory: HTTPHelpers.int64(item["Type"]) == 1,
                    parentFID: parentID,
                    fidToken: HTTPHelpers.string(item["S3KeyFlag"])
                )
            }
            result.append(contentsOf: batch)
            let total = HTTPHelpers.int64(data["Total"])
            if batch.count < 100 || Int64(result.count) >= total { break }
            page += 1
        }
        return result
    }

    public func getDriveDownloadLink(file: ShareFile, credential: String) async throws -> DownloadLink {
        let token = authToken(credential)
        guard !token.isEmpty else {
            throw YunXError.auth("123 云盘需要登录态（Authorization），请重新登录。")
        }
        var r = try HTTPHelpers.request(url: Pan123Constants.fileDownloadInfoURL,
                                        method: "POST",
                                        headers: driveHeaders(token: token))
        try r.setJSON(["fileId": HTTPHelpers.int64(file.fid)])
        let root = try JSONValue.object((try await http.send(r)).data)
        if let code = root["code"] as? NSNumber, code.intValue != 0 {
            throw YunXError.server(HTTPHelpers.string(root["message"]).isEmpty ? "123 云盘获取直链失败" : HTTPHelpers.string(root["message"]))
        }
        let d = HTTPHelpers.dict(root["data"])
        let raw = HTTPHelpers.string(d["DownloadUrl"]).isEmpty ? HTTPHelpers.string(d["DownloadURL"]) : HTTPHelpers.string(d["DownloadUrl"])
        guard let url = URL(string: raw), !raw.isEmpty else {
            throw YunXError.server("123 云盘没有返回下载链接（该文件可能超出免费流量或需会员）。")
        }
        return DownloadLink(fid: file.fid,
                            filename: file.name,
                            url: url,
                            size: HTTPHelpers.int64(d["Size"]) > 0 ? HTTPHelpers.int64(d["Size"]) : file.size,
                            headers: ["Referer": "https://yun.123pan.cn/"])
    }
}
