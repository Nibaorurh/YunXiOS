import Foundation

public struct UCService: ShareResolver, Sendable {
    private let http: HTTPClient; public init(http: HTTPClient = .shared){self.http=http}
    public func createSession(parsed: ParsedShare, password: String?, credential: String) async throws -> ShareSession {
        var r = try HTTPHelpers.request(url: UCConstants.tokenURL, method:"POST", cookie:credential, headers:["User-Agent":UCConstants.ua]); try r.setJSON(["pwd_id":parsed.shareID,"passcode":password ?? parsed.password ?? ""]); let root=try JSONValue.object((try await http.send(r)).data); let d=HTTPHelpers.dict(root["data"]); guard let st=d["stoken"] as? String, !st.isEmpty else{throw YunXError.server("UC 分享凭证获取失败")}; return ShareSession(shareID:parsed.shareID, token:st, title:HTTPHelpers.string(d["title"]), firstFID:HTTPHelpers.string(d["first_fid"]))
    }
    public func listFiles(session: ShareSession, parentID: String, credential: String) async throws -> [ShareFile] {
        var all:[ShareFile]=[]; var page=1; repeat { var c=URLComponents(string:UCConstants.detailURL)!; c.queryItems=[URLQueryItem(name:"pwd_id",value:session.shareID),URLQueryItem(name:"stoken",value:session.token),URLQueryItem(name:"pdir_fid",value:parentID),URLQueryItem(name:"page",value:"\(page)"),URLQueryItem(name:"size",value:"100"),URLQueryItem(name:"fetch_total",value:"1")]; let r=try HTTPHelpers.request(url:c.url!.absoluteString,cookie:credential,headers:["User-Agent":UCConstants.ua,"Origin":UCConstants.origin,"Referer":UCConstants.origin+"/"]); let root=try JSONValue.object((try await http.send(r)).data); let d=HTTPHelpers.dict(root["data"]); let arr=HTTPHelpers.arr(HTTPHelpers.dict(d["detail_info"])["list"]); let batch=arr.map{ShareFile(fid:HTTPHelpers.string($0["fid"]),name:HTTPHelpers.string($0["file_name"]),size:HTTPHelpers.int64($0["size"]),isDirectory:HTTPHelpers.bool($0["dir"]),parentFID:HTTPHelpers.string($0["pdir_fid"]),fidToken:HTTPHelpers.string($0["share_fid_token"]),modified:HTTPHelpers.string($0["updated_at"]))}; all += batch; page += 1; if batch.count<100 || page>100{break} } while true; return all
    }
    public func getDownloadLink(session: ShareSession, file: ShareFile, credential: String) async throws -> DownloadLink {
        var save=try HTTPHelpers.request(url:UCConstants.saveURL,method:"POST",cookie:credential,headers:["User-Agent":UCConstants.ua]); try save.setJSON(["pwd_id":session.shareID,"stoken":session.token,"pdir_fid":file.parentFID,"to_pdir_fid":"0","fid_list":[file.fid],"fid_token_list":[file.fidToken],"scene":"link"]); let sr=try JSONValue.object((try await http.send(save)).data); let taskID=HTTPHelpers.string(HTTPHelpers.dict(sr["data"])["task_id"]); guard !taskID.isEmpty else {throw YunXError.server("UC 转存失败")}; for _ in 0..<30 { try await Task.sleep(nanoseconds:1_000_000_000); var q=try HTTPHelpers.request(url:"\(UCConstants.taskURL)&task_id=\(taskID)&retry_index=0",cookie:credential,headers:["User-Agent":UCConstants.ua]); let tr=try JSONValue.object((try await http.send(q)).data); let d=HTTPHelpers.dict(tr["data"]); if let f=(d["save_as"] as? [String:Any])?["save_as_top_fids"] as? [Any], let fid=f.first as? String, !fid.isEmpty { var dl=try HTTPHelpers.request(url:UCConstants.downloadURL,method:"POST",cookie:credential,headers:["User-Agent":UCConstants.ua,"Referer":UCConstants.origin+"/"]); try dl.setJSON(["fids":[fid],"pwd_id":session.shareID,"stoken":session.token,"fids_token":[file.fidToken]]); let root=try JSONValue.object((try await http.send(dl)).data); if let item=(root["data"] as? [[String:Any]])?.first, let u=URL(string:HTTPHelpers.string(item["download_url"])) { return DownloadLink(fid:file.fid,filename:file.name,url:u,size:file.size,headers:["Referer":UCConstants.origin+"/"]) } } }; throw YunXError.server("UC 获取下载链接超时")
    }
}

public struct BaiduService: ShareResolver, Sendable {
    private let http: HTTPClient; public init(http:HTTPClient = .shared){self.http=http}
    public func createSession(parsed: ParsedShare, password: String?, credential: String) async throws -> ShareSession {
        let surl=parsed.shareID; let pwd=password ?? parsed.password ?? ""; var r=try HTTPHelpers.request(url:"https://pan.baidu.com/share/verify?4",method:"POST",cookie:credential,headers:["User-Agent":BaiduConstants.uaWeb,"Referer":"https://pan.baidu.com/s/\(surl)"]); r.setForm(["pwd":pwd,"vcode_str":"","vcode":""]); let root=try JSONValue.object((try await http.send(r)).data); if HTTPHelpers.int64(root["errno"]) != 0 { throw YunXError.server(HTTPHelpers.string(root["show_msg"]).isEmpty ? "百度提取码错误" : HTTPHelpers.string(root["show_msg"])) }; return ShareSession(shareID:surl,token:HTTPHelpers.string(root["randsk"]),title:"百度分享")
    }
    public func listFiles(session: ShareSession, parentID: String, credential: String) async throws -> [ShareFile] {
        var c=URLComponents(string:"https://pan.baidu.com/rest/2.0/xpan/share?method=list")!; c.queryItems=[URLQueryItem(name:"shorturl",value:session.shareID),URLQueryItem(name:"randsk",value:session.token),URLQueryItem(name:"page",value:"1"),URLQueryItem(name:"num",value:"100"),URLQueryItem(name:"dir",value:parentID)]; var r=try HTTPHelpers.request(url:c.url!.absoluteString,cookie:credential,headers:["User-Agent":BaiduConstants.uaWeb,"Referer":"https://pan.baidu.com/s/\(session.shareID)"]); let root=try JSONValue.object((try await http.send(r)).data); if HTTPHelpers.int64(root["errno"]) != 0 {throw YunXError.server(HTTPHelpers.string(root["errmsg"]).isEmpty ? "百度文件列表失败" : HTTPHelpers.string(root["errmsg"]))}; return HTTPHelpers.arr(root["list"]).map{ShareFile(fid:HTTPHelpers.string($0["fs_id"]),name:HTTPHelpers.string($0["server_filename"]),size:HTTPHelpers.int64($0["size"]),isDirectory:HTTPHelpers.int64($0["isdir"])==1,parentFID:parentID,path:HTTPHelpers.string($0["path"]))}
    }
    public func getDownloadLink(session: ShareSession, file: ShareFile, credential: String) async throws -> DownloadLink {
        var meta=try HTTPHelpers.request(url:"https://pan.baidu.com/api/filemetas?dlink=1&fsids=\(file.fid)&bdstoken=",cookie:credential,headers:["User-Agent":BaiduConstants.uaWeb]); let root=try JSONValue.object((try await http.send(meta)).data); let d=(root["info"] as? [[String:Any]])?.first; guard let u=URL(string:HTTPHelpers.string(d?["dlink"])),!u.absoluteString.isEmpty else{throw YunXError.server("百度获取直链失败")}; return DownloadLink(fid:file.fid,filename:file.name,url:u,size:file.size,headers:["Referer":"https://pan.baidu.com/"])
    }
}

extension BaiduService: DriveBrowser {
    public func listDriveFiles(parentID: String, credential: String) async throws -> [ShareFile] {
        guard !credential.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw YunXError.auth("百度需要 Cookie（BDUSS）。请在设置里登录百度网盘并提取 Cookie。")
        }
        let bdstoken = (try? await fetchBaiduBDSToken(credential)) ?? ""
        var result: [ShareFile] = []
        var page = 1
        while page <= 100 {
            var c = URLComponents(string: "https://pan.baidu.com/rest/2.0/xpan/file?method=list")!
            c.queryItems = [
                URLQueryItem(name: "dir", value: parentID.isEmpty ? "/" : parentID),
                URLQueryItem(name: "order", value: "name"),
                URLQueryItem(name: "desc", value: "0"),
                URLQueryItem(name: "page", value: String(page)),
                URLQueryItem(name: "num", value: "100"),
                URLQueryItem(name: "web", value: "1"),
                URLQueryItem(name: "bdstoken", value: bdstoken),
                URLQueryItem(name: "channel", value: "chunlei"),
                URLQueryItem(name: "clienttype", value: "0")
            ]
            let r = try HTTPHelpers.request(url: c.url!.absoluteString,
                                          cookie: credential,
                                          headers: ["User-Agent": BaiduConstants.uaWeb, "Referer": "https://pan.baidu.com/disk/home"])
            let root = try JSONValue.object((try await http.send(r)).data)
            if HTTPHelpers.int64(root["errno"]) != 0 {
                let msg = HTTPHelpers.string(root["errmsg"]).isEmpty ? "百度文件列表失败" : HTTPHelpers.string(root["errmsg"])
                if result.isEmpty { throw YunXError.server(msg) } else { break }
            }
            let batch = HTTPHelpers.arr(root["list"]).map { item in
                ShareFile(
                    fid: HTTPHelpers.string(item["fs_id"]),
                    name: HTTPHelpers.string(item["server_filename"]),
                    size: HTTPHelpers.int64(item["size"]),
                    isDirectory: HTTPHelpers.int64(item["isdir"]) == 1,
                    parentFID: parentID,
                    path: HTTPHelpers.string(item["path"])
                )
            }
            result.append(contentsOf: batch)
            if batch.count < 100 { break }
            page += 1
        }
        return result
    }

    public func getDriveDownloadLink(file: ShareFile, credential: String) async throws -> DownloadLink {
        var meta = try HTTPHelpers.request(url: "https://pan.baidu.com/api/filemetas?dlink=1&fsids=[\(file.fid)]&bdstoken=",
                                          cookie: credential,
                                          headers: ["User-Agent": BaiduConstants.uaWeb, "Referer": "https://pan.baidu.com/disk/home"])
        let root = try JSONValue.object((try await http.send(meta)).data)
        if HTTPHelpers.int64(root["errno"]) != 0 {
            throw YunXError.server(HTTPHelpers.string(root["errmsg"]).isEmpty ? "百度获取直链失败" : HTTPHelpers.string(root["errmsg"]))
        }
        let d = (root["info"] as? [[String:Any]])?.first
        guard let u = URL(string: HTTPHelpers.string(d?["dlink"])), !u.absoluteString.isEmpty else { throw YunXError.server("百度获取直链失败") }
        return DownloadLink(fid: file.fid, filename: file.name, url: u, size: file.size, headers: ["Referer": "https://pan.baidu.com/"])
    }

    private func fetchBaiduBDSToken(_ credential: String) async throws -> String {
        let r = try HTTPHelpers.request(url: "https://pan.baidu.com/api/getinfo?bdstoken=&channel=chunlei&clienttype=0&web=1",
                                       cookie: credential,
                                       headers: ["User-Agent": BaiduConstants.uaWeb, "Referer": "https://pan.baidu.com/disk/home"])
        let root = try JSONValue.object((try await http.send(r)).data)
        return HTTPHelpers.string(root["bdstoken"])
    }
}

public struct Pan123Service: ShareResolver, Sendable {
    private let http: HTTPClient; public init(http:HTTPClient = .shared){self.http=http}
    public func createSession(parsed: ParsedShare,password:String?,credential:String) async throws -> ShareSession { return ShareSession(shareID:parsed.shareID,token:password ?? parsed.password ?? "",title:"123云盘分享") }
    public func listFiles(session: ShareSession,parentID:String,credential:String) async throws -> [ShareFile] { var c=URLComponents(string:Pan123Constants.shareURL)!; c.queryItems=[URLQueryItem(name:"limit",value:"100"),URLQueryItem(name:"next",value:"0"),URLQueryItem(name:"orderBy",value:"file_name"),URLQueryItem(name:"orderDirection",value:"asc"),URLQueryItem(name:"shareKey",value:session.shareID),URLQueryItem(name:"ParentFileId",value:parentID),URLQueryItem(name:"Page",value:"1")]; if !session.token.isEmpty { c.queryItems?.append(URLQueryItem(name:"SharePwd",value:session.token)) }; let r=try HTTPHelpers.request(url:c.url!.absoluteString,headers:["User-Agent":"Dart/3.12 (dart:io)"]); let root=try JSONValue.object((try await http.send(r)).data); let d=HTTPHelpers.dict(root["data"]); return HTTPHelpers.arr(d["InfoList"]).map{ShareFile(fid:HTTPHelpers.string($0["FileId"]),name:HTTPHelpers.string($0["FileName"]),size:HTTPHelpers.int64($0["Size"]),isDirectory:HTTPHelpers.int64($0["Type"])==1,parentFID:parentID,fidToken:HTTPHelpers.string($0["S3KeyFlag"])) }
    }
    public func getDownloadLink(session:ShareSession,file:ShareFile,credential:String) async throws -> DownloadLink { var c=URLComponents(string:Pan123Constants.shareDownloadInfoURL)!; c.queryItems=[URLQueryItem(name:"ShareKey",value:session.shareID),URLQueryItem(name:"FileID",value:file.fid)]; let r=try HTTPHelpers.request(url:c.url!.absoluteString,headers:["User-Agent":"Dart/3.12 (dart:io)"]); let root=try JSONValue.object((try await http.send(r)).data); let d=HTTPHelpers.dict(root["data"]); let uStr=HTTPHelpers.string(d["DownloadURL"]).isEmpty ? HTTPHelpers.string(d["DownloadUrl"]) : HTTPHelpers.string(d["DownloadURL"]); guard let u=URL(string:uStr),!uStr.isEmpty else{throw YunXError.server("123云盘获取直链失败")}; return DownloadLink(fid:file.fid,filename:file.name,url:u,size:file.size,headers:["Referer":"https://yun.123pan.cn/"]) }
}
