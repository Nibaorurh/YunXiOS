import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

public actor DownloadManager {
    public static let shared = DownloadManager()

    private var tasks: [UUID: DownloadTask] = [:]
    private var workers: [UUID: Task<Void, Never>] = [:]
    private let storeURL: URL
    private let maxChunks = 8
    private let chunkSize: Int64 = 8 * 1024 * 1024

    public init() {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        storeURL = dir.appendingPathComponent("yunx-downloads.json")
        tasks = Self.readTasks(from: storeURL)
    }

    public func all() -> [DownloadTask] {
        tasks.values.sorted { $0.createdAt < $1.createdAt }
    }

    public func fileURL(_ id: UUID) -> URL? {
        guard let task = tasks[id] else { return nil }
        let url = URL(fileURLWithPath: task.savePath)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    public func enqueue(_ link: DownloadLink, platform: SharePlatform? = nil) -> UUID {
        let save = destination(for: link.filename)
        let task = DownloadTask(url: link.url,
                                filename: link.filename,
                                totalSize: link.size,
                                savePath: save.path,
                                headers: link.headers,
                                cleanupFID: link.cleanupDirectoryFID,
                                platform: platform)
        tasks[task.id] = task
        persist()
        start(task.id)
        return task.id
    }

    public func pause(_ id: UUID) {
        workers[id]?.cancel()
        workers[id] = nil
        update(id) { $0.status = .paused }
    }

    public func remove(_ id: UUID) {
        workers[id]?.cancel()
        workers[id] = nil
        if let task = tasks.removeValue(forKey: id) {
            let file = URL(fileURLWithPath: task.savePath)
            let partDir = chunkDirectory(for: id, saveURL: file)
            try? FileManager.default.removeItem(at: file)
            try? FileManager.default.removeItem(at: partDir)
        }
        persist()
    }

    public func resume(_ id: UUID) {
        guard workers[id] == nil, tasks[id] != nil else { return }
        start(id)
    }

    public func retry(_ id: UUID) { resume(id) }

    private func start(_ id: UUID) {
        workers[id] = Task { [weak self] in
            await self?.run(id)
        }
    }

    private func run(_ id: UUID) async {
        guard let initial = tasks[id] else { return }
        update(id) { $0.status = .downloading; $0.error = nil }
        do {
            let probeResult = try await probe(url: initial.url, headers: initial.headers)
            update(id) { task in if probeResult.size > 0 { task.totalSize = probeResult.size } }
            try await download(id, rangeSupported: probeResult.rangeSupported)
            update(id) { task in
                task.status = .completed
                if task.totalSize > 0 { task.downloadedSize = task.totalSize }
                task.averageSpeed = 0
            }
        } catch is CancellationError {
            // Pause/cancel is intentional; partial data is retained.
        } catch {
            update(id) { task in
                task.status = .failed
                task.error = error.localizedDescription
            }
        }
        persist()
    }

    private struct ProbeResult {
        let size: Int64
        let rangeSupported: Bool
    }

    private func probe(url: URL, headers: [String:String]) async throws -> ProbeResult {
        var range = URLRequest(url: url)
        range.httpMethod = "GET"
        range.setValue("bytes=0-0", forHTTPHeaderField: "Range")
        headers.forEach { range.setValue($0.value, forHTTPHeaderField: $0.key) }
        let (data, response) = try await URLSession.shared.data(for: range)
        guard let http = response as? HTTPURLResponse else { throw YunXError.invalidResponse }
        if http.statusCode == 206,
           let contentRange = http.value(forHTTPHeaderField: "Content-Range"),
           let slash = contentRange.lastIndex(of: "/"),
           let total = Int64(contentRange[contentRange.index(after: slash)...]),
           total > 0 {
            return ProbeResult(size: total, rangeSupported: true)
        }
        if http.statusCode == 200 {
            let length = http.expectedContentLength > 0 ? http.expectedContentLength : Int64(data.count)
            return ProbeResult(size: length, rangeSupported: false)
        }
        throw YunXError.server("无法获取下载文件信息（HTTP \(http.statusCode)）")
    }

    private func download(_ id: UUID, rangeSupported: Bool) async throws {
        guard let task = tasks[id] else { return }
        let saveURL = URL(fileURLWithPath: task.savePath)
        try FileManager.default.createDirectory(at: saveURL.deletingLastPathComponent(), withIntermediateDirectories: true)

        let total = task.totalSize
        // 未确认服务器支持 Range 时，必须走单流下载；否则多个分片收到 HTTP 200
        // 会把完整文件重复拼接，导致下载文件损坏。
        if total <= 0 || !rangeSupported {
            try await downloadWhole(id, saveURL: saveURL)
            return
        }

        let chunkCount = min(maxChunks, max(1, Int((total + chunkSize - 1) / chunkSize)))
        let partDir = chunkDirectory(for: id, saveURL: saveURL)
        try FileManager.default.createDirectory(at: partDir, withIntermediateDirectories: true)

        try await withThrowingTaskGroup(of: Void.self) { group in
            for index in 0..<chunkCount {
                let start = Int64(index) * ((total + Int64(chunkCount) - 1) / Int64(chunkCount))
                let end = min(total - 1, Int64(index + 1) * ((total + Int64(chunkCount) - 1) / Int64(chunkCount)) - 1)
                group.addTask { [weak self] in
                    guard let self = self else { return }
                    try await self.downloadChunk(id, start: start, end: end, partURL: partDir.appendingPathComponent("\(index).part"))
                }
            }
            try await group.waitForAll()
        }

        if !FileManager.default.fileExists(atPath: saveURL.path) {
            _ = FileManager.default.createFile(atPath: saveURL.path, contents: nil)
        }
        let handle = try FileHandle(forWritingTo: saveURL)
        try handle.truncate(atOffset: 0)
        for i in 0..<chunkCount {
            let part = partDir.appendingPathComponent("\(i).part")
            let data = try Data(contentsOf: part)
            try handle.seekToEnd()
            try handle.write(contentsOf: data)
        }
        try handle.close()
        try FileManager.default.removeItem(at: partDir)
    }

    private func downloadChunk(_ id: UUID, start: Int64, end: Int64, partURL: URL) async throws {
        guard let task = tasks[id] else { return }
        let expected = end - start + 1
        let existing = (try? FileManager.default.attributesOfItem(atPath: partURL.path)[.size] as? NSNumber)?.int64Value ?? 0
        if existing >= expected { return }

        var request = URLRequest(url: task.url)
        request.httpMethod = "GET"
        request.setValue("bytes=\(start + existing)-\(end)", forHTTPHeaderField: "Range")
        task.headers.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }

        for attempt in 0..<3 {
            do {
                let (data, response) = try await URLSession.shared.data(for: request)
                guard let http = response as? HTTPURLResponse else { throw YunXError.invalidResponse }
                if http.statusCode == 206 {
                    let handle: FileHandle
                    if FileManager.default.fileExists(atPath: partURL.path) {
                        handle = try FileHandle(forWritingTo: partURL)
                        try handle.seekToEnd()
                    } else {
                        _ = FileManager.default.createFile(atPath: partURL.path, contents: nil)
                        handle = try FileHandle(forWritingTo: partURL)
                    }
                    try handle.write(contentsOf: data)
                    try handle.close()
                    let current = (try FileManager.default.attributesOfItem(atPath: partURL.path)[.size] as? NSNumber)?.int64Value ?? 0
                    let downloaded = await currentDownloadedSize(for: id)
                    update(id) { $0.downloadedSize = min($0.totalSize, max($0.downloadedSize, downloaded)) }
                    if current >= expected { return }
                    throw YunXError.server("分片下载长度不足")
                }
                // Range 模式下 HTTP 200 代表服务器忽略了 Range，不能把完整文件
                // 当成当前分片写入，否则最终拼接一定损坏。让上层失败并提示回退。
                if http.statusCode == 200 {
                    throw YunXError.server("服务器忽略 Range 请求，已停止分片下载")
                }
                throw YunXError.server("服务器不支持断点 Range（HTTP \(http.statusCode)）")
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                if attempt == 2 { throw error }
                try await Task.sleep(nanoseconds: UInt64(400_000_000 * UInt64(attempt + 1)))
            }
        }
    }

    private func downloadWhole(_ id: UUID, saveURL: URL) async throws {
        guard let task = tasks[id] else { return }
        var request = URLRequest(url: task.url)
        request.httpMethod = "GET"
        task.headers.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw YunXError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw YunXError.server("下载失败 HTTP \(http.statusCode)") }
        if http.value(forHTTPHeaderField: "Content-Type")?.contains("text/html") == true {
            throw YunXError.server("下载链接已失效或被防盗链拦截")
        }
        try data.write(to: saveURL, options: .atomic)
        update(id) { $0.downloadedSize = Int64(data.count); if $0.totalSize <= 0 { $0.totalSize = Int64(data.count) } }
    }

    private func currentDownloadedSize(for id: UUID) -> Int64 {
        guard let task = tasks[id] else { return 0 }
        let saveURL = URL(fileURLWithPath: task.savePath)
        let partDir = chunkDirectory(for: id, saveURL: saveURL)
        guard let urls = try? FileManager.default.contentsOfDirectory(at: partDir, includingPropertiesForKeys: [.fileSizeKey]) else { return task.downloadedSize }
        return urls.reduce(Int64(0)) { partial, url in
            partial + ((try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0)
        }
    }

    private func chunkDirectory(for id: UUID, saveURL: URL) -> URL {
        saveURL.deletingLastPathComponent().appendingPathComponent(".yunx-\(id.uuidString)", isDirectory: true)
    }

    private func destination(for name: String) -> (url: URL, path: String) {
        let base = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Downloads", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        let safe = name.replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "\0", with: "")
        let url = base.appendingPathComponent(safe)
        return (url, url.path)
    }

    private func update(_ id: UUID, _ change: (inout DownloadTask) -> Void) {
        guard var task = tasks[id] else { return }
        change(&task)
        tasks[id] = task
        persist()
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(tasks) { try? data.write(to: storeURL, options: .atomic) }
    }

    private static func readTasks(from url: URL) -> [UUID: DownloadTask] {
        guard let data = try? Data(contentsOf: url), let decoded = try? JSONDecoder().decode([UUID: DownloadTask].self, from: data) else { return [:] }
        return decoded
    }
}
