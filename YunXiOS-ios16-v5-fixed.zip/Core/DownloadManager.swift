import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// 下载管理器。
///
/// 关键设计（第十一次修正）：
/// 1. **真正的断点续传**：分片文件持久化在 `<saveURL>/.yunx-<id>/<index>.part`，
///    暂停/继续时按已存在的分片长度续传，而不是从头重新下载。
/// 2. **并发分片**：`chunkCount` 取用户设置（默认 32，最高 512），并保证每片不小于 1MB，
///    避免为小文件切出几百个无意义的请求。
/// 3. **实时速度**：下载期间每 0.7 秒采样一次已下载字节总数，指数平滑后写入 `averageSpeed`。
/// 4. **流式拼接**：完成时按 1MB 分块把 `.part` 依次写入目标文件，512 分片也不会爆内存。
public actor DownloadManager {
    public static let shared = DownloadManager()

    private var tasks: [UUID: DownloadTask] = [:]
    private var workers: [UUID: Task<Void, Never>] = [:]
    /// 每个任务的实时速率采样状态。
    private var speedSamples: [UUID: SpeedSample] = [:]
    private let storeURL: URL

    /// 单个分片的最小粒度。分片数不会超过「文件大小 / minChunkSize」，
    /// 避免为 100KB 小文件切出 512 个请求。
    private let minChunkSize: Int64 = 1 * 1024 * 1024
    /// 用户可配置的线程数上限，与设置页保持一致。
    public static let maxSegments = 512
    public static let defaultSegments = 32
    /// 同时进行的网络请求上限。分片数可以设得很高（上限 512），但真正并发的连接数
    /// 需要收敛，否则会互相抢占连接池、并在内存里堆积大量响应体。
    public static let maxConcurrentRequests = 16

    /// 下载专用会话：放宽单主机连接数上限，否则默认会串行化，多线程形同虚设。
    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.httpMaximumConnectionsPerHost = DownloadManager.maxConcurrentRequests * 2
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 60 * 60
        config.waitsForConnectivity = true
        return URLSession(configuration: config)
    }()

    private struct SpeedSample {
        var lastBytes: Int64
        var lastDate: Date
        var smoothed: Double
    }

    public init() {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        storeURL = dir.appendingPathComponent("yunx-downloads.json")
        tasks = Self.readTasks(from: storeURL)
        // 上次退出时中断的任务恢复为“已暂停”，让用户手动继续，符合断点续传语义。
        for (id, task) in tasks where task.status == .downloading || task.status == .pending {
            tasks[id]?.status = .paused
        }
    }

    public func all() -> [DownloadTask] {
        tasks.values.sorted { $0.createdAt < $1.createdAt }
    }

    public func fileURL(_ id: UUID) -> URL? {
        guard let task = tasks[id] else { return nil }
        let url = URL(fileURLWithPath: task.savePath)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    // MARK: - 用户配置

    /// 读取用户在设置页选择的线程数（分片数），限制在合法区间内。
    private func segmentCount() -> Int {
        let raw = UserDefaults.standard.integer(forKey: Self.segmentCountKey)
        guard raw > 0 else { return Self.defaultSegments }
        return min(max(raw, 1), Self.maxSegments)
    }

    public static let segmentCountKey = "yunx.segmentCount"

    // MARK: - 任务控制

    public func enqueue(_ link: DownloadLink, platform: SharePlatform? = nil) -> UUID {
        let save = destination(for: link.filename)
        var task = DownloadTask(url: link.url,
                                filename: link.filename,
                                totalSize: link.size,
                                savePath: save.path,
                                headers: link.headers,
                                cleanupFID: link.cleanupDirectoryFID,
                                platform: platform)
        task.status = .pending
        tasks[task.id] = task
        persist()
        start(task.id)
        return task.id
    }

    public func pause(_ id: UUID) {
        workers[id]?.cancel()
        workers[id] = nil
        speedSamples[id] = nil
        // 已下载分片的实际大小回写到任务，暂停后进度条不会“跳回 0”。
        let downloaded = currentDownloadedSize(for: id)
        update(id) { task in
            task.status = .paused
            if downloaded > 0 { task.downloadedSize = min(max(task.downloadedSize, downloaded), max(task.totalSize, downloaded)) }
            task.averageSpeed = 0
        }
    }

    public func remove(_ id: UUID) {
        workers[id]?.cancel()
        workers[id] = nil
        speedSamples[id] = nil
        if let task = tasks.removeValue(forKey: id) {
            let file = URL(fileURLWithPath: task.savePath)
            let partDir = chunkDirectory(for: id, saveURL: file)
            try? FileManager.default.removeItem(at: file)
            try? FileManager.default.removeItem(at: partDir)
        }
        persist()
    }

    public func resume(_ id: UUID) {
        guard workers[id] == nil, tasks[id] != nil else { return }
        update(id) { $0.error = nil }
        start(id)
    }

    public func retry(_ id: UUID) { resume(id) }

    private func start(_ id: UUID) {
        workers[id] = Task { [weak self] in
            await self?.run(id)
        }
    }

    // MARK: - 主流程

    private func run(_ id: UUID) async {
        guard let initial = tasks[id] else { return }
        // 已经完整下载过的文件不重复下载。
        if let done = tasks[id], done.status == .completed,
           FileManager.default.fileExists(atPath: done.savePath) {
            return
        }
        update(id) { $0.status = .downloading; $0.error = nil }
        beginSpeedSampling(id)
        do {
            let probeResult: ProbeResult
            if initial.totalSize > 0 {
                // 已知道大小，只需确认是否支持 Range，避免多一次整包探测。
                probeResult = try await probe(url: initial.url, headers: initial.headers, knownSize: true)
            } else {
                probeResult = try await probe(url: initial.url, headers: initial.headers, knownSize: false)
            }
            update(id) { task in
                if probeResult.size > 0 { task.totalSize = probeResult.size }
                if probeResult.rangeSupported, probeResult.size > 0, task.downloadedSize > probeResult.size {
                    task.downloadedSize = 0
                }
            }
            try await download(id, rangeSupported: probeResult.rangeSupported)
            stopSpeedSampling(id)
            update(id) { task in
                task.status = .completed
                if task.totalSize > 0 { task.downloadedSize = task.totalSize }
                task.averageSpeed = 0
                task.error = nil
            }
        } catch is CancellationError {
            // 暂停是主动取消，分片文件已落盘，进度保留。
            stopSpeedSampling(id, keepSpeed: false)
        } catch {
            stopSpeedSampling(id, keepSpeed: false)
            update(id) { task in
                task.status = .failed
                task.error = error.localizedDescription
            }
        }
        persist()
    }

    private struct ProbeResult {
        let size: Int64
        let rangeSupported: Bool
    }

    /// 探测文件大小与是否支持 Range。
    /// - Parameter knownSize: 已知大小（来自列表接口）时，探测失败也允许尝试分片下载，
    ///   因为部分 CDN 会拦截 `bytes=0-0` 探测请求，但正常 Range 请求是放行的。
    private func probe(url: URL, headers: [String: String], knownSize: Bool) async throws -> ProbeResult {
        var range = URLRequest(url: url)
        range.httpMethod = "GET"
        range.setValue("bytes=0-0", forHTTPHeaderField: "Range")
        headers.forEach { range.setValue($0.value, forHTTPHeaderField: $0.key) }
        do {
            let (data, response) = try await session.data(for: range)
            guard let http = response as? HTTPURLResponse else { throw YunXError.invalidResponse }
            if http.statusCode == 206 {
                var total: Int64 = 0
                if let contentRange = http.value(forHTTPHeaderField: "Content-Range"),
                   let slash = contentRange.lastIndex(of: "/"),
                   let parsed = Int64(contentRange[contentRange.index(after: slash)...]),
                   parsed > 0 {
                    total = parsed
                }
                return ProbeResult(size: total, rangeSupported: true)
            }
            if http.statusCode == 200 {
                let length = http.expectedContentLength > 0 ? http.expectedContentLength : Int64(data.count)
                return ProbeResult(size: length, rangeSupported: false)
            }
            throw YunXError.server("无法获取下载文件信息（HTTP \(http.statusCode)）")
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            if error is YunXError, knownSize,
               let known = tasks.values.first(where: { $0.url == url })?.totalSize, known > 0 {
                return ProbeResult(size: known, rangeSupported: true)
            }
            throw error
        }
    }

    private func download(_ id: UUID, rangeSupported: Bool) async throws {
        guard let task = tasks[id] else { return }
        let saveURL = URL(fileURLWithPath: task.savePath)
        try FileManager.default.createDirectory(at: saveURL.deletingLastPathComponent(), withIntermediateDirectories: true)

        let total = task.totalSize
        // 未确认服务器支持 Range 时只能走单流下载，否则多个分片会各自收到完整文件导致拼接损坏。
        if total <= 0 || !rangeSupported {
            try await downloadWhole(id, saveURL: saveURL)
            return
        }

        let partDir = chunkDirectory(for: id, saveURL: saveURL)
        try FileManager.default.createDirectory(at: partDir, withIntermediateDirectories: true)

        // 分片数自适应：
        // - `wanted` 是用户设置的线程数（默认 32，最高 512），作为并发上限；
        // - 同时保证每片至少 1MB，避免为小文件切出成百上千个无意义请求；
        // - 最终分片数 = min(用户设置, 按 1MB 粒度能切出的片数)。
        let wanted = segmentCount()
        let byMinSize = Int((total + minChunkSize - 1) / minChunkSize)
        let chunkCount = max(1, min(wanted, max(byMinSize, 1)))
        let per = (total + Int64(chunkCount) - 1) / Int64(chunkCount)

        // 校验既有分片是否与当前切分方案一致，不一致说明历史残留，清掉重来。
        reconcileParts(partDir: partDir, chunkCount: chunkCount, per: per, total: total)

        // 速度采样器：与下载并发运行，每 0.7 秒刷新一次实时速率。
        let sampler = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 700_000_000)
                await self?.sampleSpeed(id)
            }
        }
        defer { sampler.cancel() }

        // 并发闸门：分片数按用户设置切分，但同时发起的连接数受 URLSession 连接池限制。
        // 直接一次性放 512 个请求会互相抢占连接、反而变慢，这里限制峰值并发。
        let gate = ConcurrencyGate(limit: min(chunkCount, Self.maxConcurrentRequests))
        try await withThrowingTaskGroup(of: Void.self) { group in
            for index in 0..<chunkCount {
                let start = Int64(index) * per
                let end = min(total - 1, Int64(index + 1) * per - 1)
                if start > end { continue }
                let partURL = partDir.appendingPathComponent("\(index).part")
                group.addTask { [weak self] in
                    guard let self = self else { return }
                    let acquired = await gate.acquire()
                    guard acquired else { throw CancellationError() }
                    defer { Task { await gate.release() } }
                    try await self.downloadChunk(id, start: start, end: end, partURL: partURL)
                }
            }
            try await group.waitForAll()
        }

        // 流式拼接：按 1MB 读取，512 分片 / 大文件也不会把整个文件读进内存。
        try stitch(partDir: partDir, chunkCount: chunkCount, saveURL: saveURL)
        try? FileManager.default.removeItem(at: partDir)
        update(id) { $0.downloadedSize = $0.totalSize }
    }

    /// 分片校验：如果 `.part` 的数量或大小与当前切分方案不匹配（例如用户中途改了线程数），
    /// 直接清空分片目录，从头开始，避免拼出损坏文件。
    private func reconcileParts(partDir: URL, chunkCount: Int, per: Int64, total: Int64) {
        guard let urls = try? FileManager.default.contentsOfDirectory(at: partDir, includingPropertiesForKeys: [.fileSizeKey]) else { return }
        if urls.count != chunkCount {
            try? FileManager.default.removeItem(at: partDir)
            try? FileManager.default.createDirectory(at: partDir, withIntermediateDirectories: true)
            return
        }
        for index in 0..<chunkCount {
            let part = partDir.appendingPathComponent("\(index).part")
            let size = ((try? part.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
            let expected = Int(min(total - Int64(index) * per, per))
            if size > expected {
                try? FileManager.default.removeItem(at: partDir)
                try? FileManager.default.createDirectory(at: partDir, withIntermediateDirectories: true)
                return
            }
        }
    }

    private func downloadChunk(_ id: UUID, start: Int64, end: Int64, partURL: URL) async throws {
        guard let task = tasks[id] else { return }
        let expected = end - start + 1
        let existing = (try? FileManager.default.attributesOfItem(atPath: partURL.path)[.size] as? NSNumber)?.int64Value ?? 0
        if existing >= expected { return }

        var request = URLRequest(url: task.url)
        request.httpMethod = "GET"
        request.setValue("bytes=\(start + existing)-\(end)", forHTTPHeaderField: "Range")
        task.headers.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }

        for attempt in 0..<3 {
            do {
                try Task.checkCancellation()
                let (data, response) = try await session.data(for: request)
                guard let http = response as? HTTPURLResponse else { throw YunXError.invalidResponse }
                if http.statusCode == 206 {
                    let handle: FileHandle
                    if FileManager.default.fileExists(atPath: partURL.path) {
                        handle = try FileHandle(forWritingTo: partURL)
                        try handle.seekToEnd()
                    } else {
                        _ = FileManager.default.createFile(atPath: partURL.path, contents: nil)
                        handle = try FileHandle(forWritingTo: partURL)
                    }
                    try handle.write(contentsOf: data)
                    try handle.close()
                    let current = (try FileManager.default.attributesOfItem(atPath: partURL.path)[.size] as? NSNumber)?.int64Value ?? 0
                    if current >= expected { return }
                    throw YunXError.server("分片下载长度不足")
                }
                // Range 模式下 HTTP 200 代表服务器忽略了 Range，不能把完整文件当成当前分片写入。
                if http.statusCode == 200 {
                    throw YunXError.server("服务器忽略 Range 请求，已停止分片下载")
                }
                if http.statusCode == 403 || http.statusCode == 404 {
                    throw YunXError.server("下载链接已失效（HTTP \(http.statusCode)），请重新解析后下载")
                }
                throw YunXError.server("服务器不支持断点 Range（HTTP \(http.statusCode)）")
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                if attempt == 2 { throw error }
                try await Task.sleep(nanoseconds: UInt64(400_000_000 * UInt64(attempt + 1)))
            }
        }
    }

    private func downloadWhole(_ id: UUID, saveURL: URL) async throws {
        guard let task = tasks[id] else { return }
        var request = URLRequest(url: task.url)
        request.httpMethod = "GET"
        task.headers.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw YunXError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw YunXError.server("下载失败 HTTP \(http.statusCode)") }
        if http.value(forHTTPHeaderField: "Content-Type")?.contains("text/html") == true {
            throw YunXError.server("下载链接已失效或被防盗链拦截")
        }
        try data.write(to: saveURL, options: .atomic)
        update(id) { $0.downloadedSize = Int64(data.count); if $0.totalSize <= 0 { $0.totalSize = Int64(data.count) } }
    }

    /// 按 1MB 分块把分片顺序写入目标文件，避免 `Data(contentsOf:)` 一次性读入整个分片。
    private func stitch(partDir: URL, chunkCount: Int, saveURL: URL) throws {
        if !FileManager.default.fileExists(atPath: saveURL.path) {
            _ = FileManager.default.createFile(atPath: saveURL.path, contents: nil)
        }
        let out = try FileHandle(forWritingTo: saveURL)
        defer { try? out.close() }
        try out.truncate(atOffset: 0)
        let bufferSize = 1 * 1024 * 1024
        for index in 0..<chunkCount {
            let part = partDir.appendingPathComponent("\(index).part")
            guard let input = try? FileHandle(forReadingFrom: part) else { continue }
            defer { try? input.close() }
            while true {
                let block = try input.read(upToCount: bufferSize) ?? Data()
                if block.isEmpty { break }
                try out.write(contentsOf: block)
            }
        }
    }

    // MARK: - 速度统计

    private func beginSpeedSampling(_ id: UUID) {
        speedSamples[id] = SpeedSample(lastBytes: currentDownloadedSize(for: id), lastDate: Date(), smoothed: 0)
    }

    private func stopSpeedSampling(_ id: UUID, keepSpeed: Bool = false) {
        guard let sample = speedSamples[id] else { return }
        speedSamples[id] = nil
        if !keepSpeed {
            let speed = Int64(sample.smoothed)
            update(id) { $0.averageSpeed = speed }
        }
    }

    /// 由采样器定期调用，刷新实时速率。使用指数平滑避免数字剧烈跳动。
    private func sampleSpeed(_ id: UUID) {
        guard var sample = speedSamples[id], let task = tasks[id], task.status == .downloading else { return }
        let now = Date()
        let elapsed = now.timeIntervalSince(sample.lastDate)
        guard elapsed >= 0.2 else { return }
        let bytes = currentDownloadedSize(for: id)
        let delta = Double(max(0, bytes - sample.lastBytes))
        let instant = delta / elapsed
        sample.smoothed = sample.smoothed <= 0 ? instant : sample.smoothed * 0.6 + instant * 0.4
        sample.lastBytes = bytes
        sample.lastDate = now
        let speed = Int64(max(0, sample.smoothed))
        speedSamples[id] = sample
        // 高频进度更新不落盘：只要 UI 能读到最新值即可，减少 0.7s 一次的 JSON 写入。
        update(id, persist: false) { item in
            item.averageSpeed = speed
            let clamped = item.totalSize > 0 ? min(bytes, item.totalSize) : bytes
            item.downloadedSize = max(item.downloadedSize, clamped)
        }
    }

    private func currentDownloadedSize(for id: UUID) -> Int64 {
        guard let task = tasks[id] else { return 0 }
        let saveURL = URL(fileURLWithPath: task.savePath)
        let partDir = chunkDirectory(for: id, saveURL: saveURL)
        guard let urls = try? FileManager.default.contentsOfDirectory(at: partDir, includingPropertiesForKeys: [.fileSizeKey]) else { return task.downloadedSize }
        return urls.reduce(Int64(0)) { partial, url in
            partial + ((try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0)
        }
    }

    private func chunkDirectory(for id: UUID, saveURL: URL) -> URL {
        saveURL.deletingLastPathComponent().appendingPathComponent(".yunx-\(id.uuidString)", isDirectory: true)
    }

    private func destination(for name: String) -> (url: URL, path: String) {
        let base = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Downloads", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        let safe = name.replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "\0", with: "")
        let url = base.appendingPathComponent(safe)
        return (url, url.path)
    }

    private func update(_ id: UUID, persist shouldPersist: Bool = true, _ change: (inout DownloadTask) -> Void) {
        guard var task = tasks[id] else { return }
        change(&task)
        tasks[id] = task
        if shouldPersist { persist() }
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(tasks) { try? data.write(to: storeURL, options: .atomic) }
    }

    private static func readTasks(from url: URL) -> [UUID: DownloadTask] {
        guard let data = try? Data(contentsOf: url), let decoded = try? JSONDecoder().decode([UUID: DownloadTask].self, from: data) else { return [:] }
        return decoded
    }
}

/// 简易并发闸门：限制同时进行的分片请求数量，避免一次性打出几百个连接。
/// `acquire()` 返回是否真正拿到了名额——被取消而退出的调用方不应调用 `release()`，
/// 否则会把不属于自己的名额转交出去，导致并发数失控。
private actor ConcurrencyGate {
    private let limit: Int
    private var running = 0
    /// 已挂起的等待者。key 是令牌，用于取消时精确定位。
    private var waiters: [UUID: CheckedContinuation<Bool, Never>] = [:]
    /// 已被取消、但 continuation 还没注册进来的令牌。
    /// 用于解决「取消先于注册」的竞态：否则 continuation 会永远挂起。
    private var cancelledBeforeWait: Set<UUID> = []

    init(limit: Int) {
        self.limit = max(1, limit)
    }

    func acquire() async -> Bool {
        if running < limit {
            running += 1
            return true
        }
        if Task.isCancelled { return false }
        let token = UUID()
        let acquired: Bool = await withTaskCancellationHandler {
            await withCheckedContinuation { continuation in
                Task { await self.registerWaiter(token: token, continuation: continuation) }
            }
        } onCancel: {
            Task { await self.cancelWaiter(token) }
        }
        return acquired
    }

    private func registerWaiter(token: UUID, continuation: CheckedContinuation<Bool, Never>) {
        // 若在注册前就被 cancelWaiter 标记过（取消先于注册），立刻以 false 唤醒，
        // 否则这个 continuation 会永远挂起。
        if cancelledBeforeWait.remove(token) != nil {
            continuation.resume(returning: false)
            return
        }
        waiters[token] = continuation
    }

    /// 名额转交：优先给排队最久的等待者，没有等待者才真正释放。
    func release() {
        if let token = waiters.keys.first, let next = waiters.removeValue(forKey: token) {
            // 名额直接转交，running 保持不变。
            next.resume(returning: true)
        } else {
            running = max(0, running - 1)
        }
    }

    private func cancelWaiter(_ token: UUID) {
        if let continuation = waiters.removeValue(forKey: token) {
            // 还在排队，从未占用名额 → 返回 false。
            continuation.resume(returning: false)
        } else {
            // continuation 尚未注册，打标记让 registerWaiter 直接放行。
            cancelledBeforeWait.insert(token)
        }
    }
}
