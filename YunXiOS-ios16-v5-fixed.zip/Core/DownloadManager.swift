import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// 下载管理器。
///
/// 关键设计（第十二次修正：完整移植安卓原版 YunX 的分片调度架构）：
///
/// **为什么以前的"加速"没效果？**
/// 老实现的分片数 ≈ 线程数（1 线程 1 片，无盈余）。每个线程必须等自己那片下完才能
/// 领新活，一旦某片所在 CDN 节点慢下来，其它线程干完活就空转 → 尾部被最慢那片拖死。
///
/// **原版做法（本文件已对齐）**：
/// 1. **任务池盈余**：`chunkCountFor` 让每线程平均领 8 片（`max(bySize, threads * 8)`），
///    单片下限 256KB。慢片只拖住 1/8 的时间，工作窃取自然摊平。
/// 2. **主池 70% + 弹性区 30%**：前 70% 等分固定片（保证连接复用与顺序读），
///    后 30% 由 `ElasticAllocator` 按字节顺序动态发块，块大小随实测速度自适应。
/// 3. **尾部收缩**：剩余字节不足 `workers * 块` 时，把块压到 `remaining / workers`
///    （下限 64KB），让全部连接并行冲完最后一段，消除"最后一个线程慢慢爬"。
/// 4. **片内不做指数退避**：退避期间占着并发名额会让所有分片周期性集体停顿
///    （就是原版注释里说的"900KB 忽快忽慢"根源）。Range 被忽略时立即归还名额。
/// 5. **错峰建连**：第 i 片首发前延迟 `min(i, 8) * 25ms`，平摊 TCP/TLS 突发。
/// 6. **迅雷单独封顶 8 并发**：其 CDN 对单文件并发 Range 有阈值，超过会把多余请求
///    降级成 200 整文件，触发整任务回退单流，速度反而暴跌。
/// 7. **分片计划签名**：`plan.txt` 记录 `chunks/total/main`，与磁盘不一致时清空重下，
///    防止跨会话改线程数后续传错位 → 文件膨胀/损坏。
public actor DownloadManager {
    public static let shared = DownloadManager()

    private var tasks: [UUID: DownloadTask] = [:]
    private var workers: [UUID: Task<Void, Never>] = [:]
    /// 每个任务的实时速率采样状态。
    private var speedSamples: [UUID: SpeedSample] = [:]
    private let storeURL: URL

    /// 单片下限 256KB。原版注释：1MB 会把小文件（如 33.7MB）的分片数夹到 ≈ 线程数，
    /// 失去盈余；低单连接速率下每个 1MB 重片耗时极长，尾部极易空转。
    private static let minChunkSize: Int64 = 256 * 1024
    /// 分片总数硬上限，与设置页线程数上限一致。
    public static let maxSegments = 512
    public static let defaultSegments = 32

    /// 常规状态下的并发连接数上限。分片数可以切到 512，但真正同时在飞的连接需要收敛：
    /// iOS 上同时维持几百条 TLS 连接会互相抢带宽、并在内存里堆积响应体。
    public static let maxConcurrentRequests = 64

    /// 迅雷并发安全上限：CDN 对单文件并发 Range 有阈值（约 8），超过会降级 200。
    private static let rangeWorkersCap = 8
    /// 错峰建连：第 i 片首发前延迟 `min(i, staggerCap) * staggerMs`。
    private static let staggerCap = 8
    private static let staggerMs: UInt64 = 25
    /// 偶发「服务器忽略 Range」的容忍次数，超过才整任务回退单流。
    private static let rangeIgnoredTolerance = 3

    /// 下载专用会话：放宽单主机连接数上限，否则默认（6）会把并发直接串行化。
    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.httpMaximumConnectionsPerHost = DownloadManager.maxConcurrentRequests
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 60 * 60
        config.waitsForConnectivity = true
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        return URLSession(configuration: config)
    }()

    private struct SpeedSample {
        var lastBytes: Int64
        var lastDate: Date
        var smoothed: Double
    }

    public init() {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        storeURL = dir.appendingPathComponent("yunx-downloads.json")
        tasks = Self.readTasks(from: storeURL)
        // 上次退出时中断的任务恢复为“已暂停”，让用户手动继续，符合断点续传语义。
        for (id, task) in tasks where task.status == .downloading || task.status == .pending {
            tasks[id]?.status = .paused
        }
    }

    public func all() -> [DownloadTask] {
        tasks.values.sorted { $0.createdAt < $1.createdAt }
    }

    public func fileURL(_ id: UUID) -> URL? {
        guard let task = tasks[id] else { return nil }
        let url = URL(fileURLWithPath: task.savePath)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    // MARK: - 用户配置

    /// 读取用户在设置页选择的线程数，限制在合法区间内。
    private func segmentCount() -> Int {
        let raw = UserDefaults.standard.integer(forKey: Self.segmentCountKey)
        guard raw > 0 else { return Self.defaultSegments }
        return min(max(raw, 1), Self.maxSegments)
    }

    public static let segmentCountKey = "yunx.segmentCount"

    // MARK: - 任务控制

    public func enqueue(_ link: DownloadLink, platform: SharePlatform? = nil) -> UUID {
        let save = destination(for: link.filename)
        var task = DownloadTask(url: link.url,
                                filename: link.filename,
                                totalSize: link.size,
                                savePath: save.path,
                                headers: link.headers,
                                cleanupFID: link.cleanupDirectoryFID,
                                platform: platform)
        task.status = .pending
        tasks[task.id] = task
        persist()
        start(task.id)
        return task.id
    }

    public func pause(_ id: UUID) {
        workers[id]?.cancel()
        workers[id] = nil
        speedSamples[id] = nil
        // 已下载分片的实际大小回写到任务，暂停后进度条不会“跳回 0”。
        let downloaded = currentDownloadedSize(for: id)
        update(id) { task in
            task.status = .paused
            if downloaded > 0 {
                let upper = task.totalSize > 0 ? max(task.totalSize, downloaded) : downloaded
                task.downloadedSize = min(max(task.downloadedSize, downloaded), upper)
            }
            task.averageSpeed = 0
        }
    }

    public func remove(_ id: UUID) {
        workers[id]?.cancel()
        workers[id] = nil
        speedSamples[id] = nil
        if let task = tasks.removeValue(forKey: id) {
            let file = URL(fileURLWithPath: task.savePath)
            let partDir = chunkDirectory(for: id, saveURL: file)
            try? FileManager.default.removeItem(at: file)
            try? FileManager.default.removeItem(at: partDir)
        }
        persist()
    }

    public func resume(_ id: UUID) {
        guard workers[id] == nil, tasks[id] != nil else { return }
        update(id) { $0.error = nil }
        start(id)
    }

    public func retry(_ id: UUID) { resume(id) }

    private func start(_ id: UUID) {
        workers[id] = Task { [weak self] in
            await self?.run(id)
        }
    }

    // MARK: - 分片规划（对齐原版 chunkCountFor）

    /// 计算分片总数。
    ///
    /// - `bySize`：按文件大小给一个基础值，避免小文件被切得过碎；
    /// - `want = max(bySize, threads * 8)`：**核心**——每线程平均领 8 片，天然抗慢片拖尾；
    /// - 再受「256KB 粒度」和 512 上限约束。
    private static func chunkCountFor(total: Int64, threads: Int) -> Int {
        if total <= 0 { return 1 }
        let bySize: Int
        if total < 5 * 1024 * 1024 { bySize = 1 }
        else if total < 50 * 1024 * 1024 { bySize = 8 }
        else if total < 500 * 1024 * 1024 { bySize = 32 }
        else { bySize = 64 }

        let want = max(bySize, max(threads, 1) * 8)
        let byGranularity = Int(max(1, total / DownloadManager.minChunkSize))
        return max(1, min(want, min(byGranularity, DownloadManager.maxSegments)))
    }

    /// 有效并发：迅雷单独封顶，其它平台用满用户设置的线程数。
    private static func effectiveWorkers(threads: Int, isXunlei: Bool) -> Int {
        let safe = max(threads, 1)
        return isXunlei ? max(1, min(safe, DownloadManager.rangeWorkersCap)) : safe
    }

    private static func isXunleiTask(_ task: DownloadTask) -> Bool {
        if let platform = task.platform, platform == .xunlei { return true }
        if let ua = task.headers.first(where: { $0.key.lowercased() == "user-agent" })?.value.lowercased(),
           ua.contains("xunlei") { return true }
        return task.url.absoluteString.lowercased().contains("xunlei")
    }

    // MARK: - 主流程

    private func run(_ id: UUID) async {
        guard let initial = tasks[id] else { return }
        // 已经完整下载过的文件不重复下载。
        if let done = tasks[id], done.status == .completed,
           FileManager.default.fileExists(atPath: done.savePath) {
            return
        }
        update(id) { $0.status = .downloading; $0.error = nil }
        beginSpeedSampling(id)
        do {
            let probeResult = try await probe(url: initial.url,
                                              headers: initial.headers,
                                              knownSize: initial.totalSize > 0)
            update(id) { task in
                if probeResult.size > 0 { task.totalSize = probeResult.size }
            }
            try await download(id, rangeSupported: probeResult.rangeSupported)
            stopSpeedSampling(id)
            update(id) { task in
                task.status = .completed
                if task.totalSize > 0 { task.downloadedSize = task.totalSize }
                task.averageSpeed = 0
                task.error = nil
            }
        } catch is CancellationError {
            // 暂停是主动取消，分片文件已落盘，进度保留。
            stopSpeedSampling(id, keepSpeed: false)
        } catch let error as YunXError {
            stopSpeedSampling(id, keepSpeed: false)
            // Range 被服务器忽略时回退单流；其余错误直接标记失败。
            if case .server(let message) = error, message.contains("忽略 Range") {
                do {
                    let saveURL = URL(fileURLWithPath: initial.savePath)
                    try await downloadWhole(id, saveURL: saveURL)
                    update(id) { task in
                        task.status = .completed
                        if task.totalSize > 0 { task.downloadedSize = task.totalSize }
                        task.averageSpeed = 0
                        task.error = nil
                    }
                    persist()
                    return
                } catch is CancellationError {
                    persist()
                    return
                } catch {
                    // 继续走下面的失败分支
                }
            }
            update(id) { task in
                task.status = .failed
                task.error = error.localizedDescription
            }
        } catch {
            stopSpeedSampling(id, keepSpeed: false)
            update(id) { task in
                task.status = .failed
                task.error = error.localizedDescription
            }
        }
        persist()
    }

    private struct ProbeResult {
        let size: Int64
        let rangeSupported: Bool
    }

    /// 探测文件大小与是否支持 Range。
    /// - Parameter knownSize: 已知大小（来自列表接口）时，探测失败也允许尝试分片下载，
    ///   因为部分 CDN 会拦截 `bytes=0-0` 探测请求，但正常 Range 请求是放行的。
    private func probe(url: URL, headers: [String: String], knownSize: Bool) async throws -> ProbeResult {
        var range = URLRequest(url: url)
        range.httpMethod = "GET"
        range.setValue("bytes=0-0", forHTTPHeaderField: "Range")
        headers.forEach { range.setValue($0.value, forHTTPHeaderField: $0.key) }
        do {
            let (data, response) = try await session.data(for: range)
            guard let http = response as? HTTPURLResponse else { throw YunXError.invalidResponse }
            if http.statusCode == 206 {
                var total: Int64 = 0
                if let contentRange = http.value(forHTTPHeaderField: "Content-Range"),
                   let slash = contentRange.lastIndex(of: "/"),
                   let parsed = Int64(contentRange[contentRange.index(after: slash)...]),
                   parsed > 0 {
                    total = parsed
                }
                return ProbeResult(size: total, rangeSupported: true)
            }
            if http.statusCode == 200 {
                let length = http.expectedContentLength > 0 ? http.expectedContentLength : Int64(data.count)
                return ProbeResult(size: length, rangeSupported: false)
            }
            throw YunXError.server("无法获取下载文件信息（HTTP \(http.statusCode)）")
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            if error is YunXError, knownSize,
               let known = tasks.values.first(where: { $0.url == url })?.totalSize, known > 0 {
                return ProbeResult(size: known, rangeSupported: true)
            }
            throw error
        }
    }

    // MARK: - 分片下载（主池 70% + 弹性区 30%）

    private func download(_ id: UUID, rangeSupported: Bool) async throws {
        guard let task = tasks[id] else { return }
        let saveURL = URL(fileURLWithPath: task.savePath)
        try FileManager.default.createDirectory(at: saveURL.deletingLastPathComponent(), withIntermediateDirectories: true)

        let total = task.totalSize
        // 未确认服务器支持 Range 时只能走单流下载，否则多个分片会各自收到完整文件导致拼接损坏。
        if total <= 0 || !rangeSupported {
            try await downloadWhole(id, saveURL: saveURL)
            return
        }

        let partDir = chunkDirectory(for: id, saveURL: saveURL)
        try FileManager.default.createDirectory(at: partDir, withIntermediateDirectories: true)

        let threads = segmentCount()
        let chunkCount = Self.chunkCountFor(total: total, threads: threads)
        let chunkSize = (total + Int64(chunkCount) - 1) / Int64(chunkCount)
        // ★ 主池 70%（等分固定片，保证连接复用与顺序读） + 弹性区 30%（动态发块，工作窃取）
        let mainPoolCount = min(chunkCount, max(1, Int(Double(chunkCount) * 0.7)))
        let elasticStart = Int64(mainPoolCount) * chunkSize
        let plan = "chunks=\(chunkCount) total=\(total) main=\(mainPoolCount)"

        // ★ 分片计划签名：part_i / seg_start_end 的区间由 chunkCount 与 total 推导，
        //   跨会话改了线程数或服务器探测大小变化 → 旧分片区间错位 → 续传膨胀/损坏。
        let planFile = partDir.appendingPathComponent("plan.txt")
        let existingPlan = (try? String(contentsOf: planFile, encoding: .utf8))?.trimmingCharacters(in: .whitespacesAndNewlines)
        if let existingPlan = existingPlan, !existingPlan.isEmpty, existingPlan != plan {
            try? FileManager.default.removeItem(at: partDir)
            try? FileManager.default.createDirectory(at: partDir, withIntermediateDirectories: true)
        }
        try? plan.write(to: partFile(partDir, "plan.txt"), atomically: true, encoding: .utf8)

        let isXunlei = Self.isXunleiTask(task)
        let effectiveWorkers = Self.effectiveWorkers(threads: threads, isXunlei: isXunlei)

        // 速度采样器：与下载并发运行，每 0.7 秒刷新一次实时速率。
        let sampler = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 700_000_000)
                await self?.sampleSpeed(id)
            }
        }
        defer { sampler.cancel() }

        // 断点续传起点：主池按 part 真实长度，弹性区按 seg 文件名携带的区间推进前缀。
        var downloaded = restartSize(partDir: partDir, mainPoolCount: mainPoolCount, elasticStart: elasticStart, total: total)
        update(id) { item in
            item.downloadedSize = max(item.downloadedSize, min(downloaded, total))
        }

        let allocator = ElasticAllocator(total: total, elasticStart: elasticStart, workers: effectiveWorkers, chunkSize: chunkSize)
        seedAllocator(allocator, partDir: partDir, elasticStart: elasticStart)

        let gate = ConcurrencyGate(limit: effectiveWorkers)
        let counter = ByteCounter(value: downloaded)

        try await withThrowingTaskGroup(of: ChunkOutcome.self) { group in
            // 主池领取游标：所有 worker 共享，谁空闲谁领下一片（工作窃取的入口）。
            let mainCursor = IndexCursor()
            for _ in 0..<max(1, effectiveWorkers) {
                group.addTask { [weak self] in
                    guard let self = self else { return .ok }
                    // 阶段 1：主池循环领取固定片
                    while true {
                        try Task.checkCancellation()
                        let index = await mainCursor.next()
                        if index >= mainPoolCount { break }
                        // 错峰建连：首请求前按序号微延迟，平摊 TCP/TLS 突发（仅影响首请求）。
                        if index > 0 {
                            let stagger = min(index, Self.staggerCap)
                            try? await Task.sleep(nanoseconds: UInt64(stagger) * Self.staggerMs * 1_000_000)
                        }
                        let start = Int64(index) * chunkSize
                        let end = min(start + chunkSize - 1, total - 1)
                        let target = partFile(partDir, "part_\(index)")
                        let outcome = try await self.runChunk(id, gate: gate, start: start, end: end,
                                                              target: target, counter: counter, allocator: allocator)
                        if outcome != .ok { return outcome }
                    }
                    // 阶段 2：主池取空 → 弹性区按字节顺序动态领块（空闲线程逐个平滑转入）
                    while true {
                        try Task.checkCancellation()
                        guard let block = await allocator.take() else { return .ok }
                        let target = partFile(partDir, "seg_\(block.start)_\(block.end).part")
                        let outcome = try await self.runChunk(id, gate: gate, start: block.start, end: block.end,
                                                              target: target, counter: counter, allocator: allocator)
                        if outcome != .ok { return outcome }
                    }
                }
            }
            var ignored = 0
            var failure: ChunkOutcome = .ok
            for try await outcome in group {
                switch outcome {
                case .ok: break
                case .rangeIgnored:
                    // 偶发 200（CDN 限流中间态）不立即回退，容忍若干次。
                    ignored += 1
                    if ignored >= Self.rangeIgnoredTolerance { failure = .rangeIgnored }
                case .failed:
                    if failure == .ok { failure = .failed }
                }
            }
            if failure == .rangeIgnored {
                group.cancelAll()
                throw YunXError.server("服务器忽略 Range 请求，已停止分片下载")
            }
            if failure == .failed {
                group.cancelAll()
                throw YunXError.server("分片下载失败，请检查网络后重试")
            }
        }

        // 失败区间并行重试：主池缺失片 + 弹性区未完成区间，复用并发池补齐。
        try await retryMissing(id: id, gate: gate, partDir: partDir, mainPoolCount: mainPoolCount,
                               chunkSize: chunkSize, total: total, counter: counter, workers: effectiveWorkers)

        // 流式拼接：按 1MB 读取，512 分片 / 大文件也不会把整个文件读进内存。
        try stitch(partDir: partDir, mainPoolCount: mainPoolCount, saveURL: saveURL, total: total)
        try? FileManager.default.removeItem(at: partDir)
        update(id) { $0.downloadedSize = $0.totalSize }
    }

    private func partFile(_ dir: URL, _ name: String) -> URL {
        dir.appendingPathComponent(name)
    }

    private enum ChunkOutcome: Equatable { case ok, rangeIgnored, failed }

    /// 单个分片（主池固定片或弹性块）的完整生命周期：占名额 → 下载 → 归还名额。
    ///
    /// 取消（暂停）必须向上抛 `CancellationError`，绝不能被吞成 `.failed`——
    /// 否则用户点暂停后会被当成"下载失败"，正是"暂停变取消"的成因之一。
    private func runChunk(_ id: UUID,
                          gate: ConcurrencyGate,
                          start: Int64,
                          end: Int64,
                          target: URL,
                          counter: ByteCounter,
                          allocator: ElasticAllocator) async throws -> ChunkOutcome {
        let acquired = await gate.acquire()
        guard acquired else { throw CancellationError() }
        do {
            let outcome = try await downloadChunk(id, start: start, end: end, partURL: target,
                                                  counter: counter, allocator: allocator)
            await gate.release()
            return outcome
        } catch {
            await gate.release()
            throw error
        }
    }

    private func retryMissing(id: UUID,
                              gate: ConcurrencyGate,
                              partDir: URL,
                              mainPoolCount: Int,
                              chunkSize: Int64,
                              total: Int64,
                              counter: ByteCounter,
                              workers: Int) async throws {
        struct Pending { let start: Int64; let end: Int64; let url: URL }
        var pending: [Pending] = []
        for index in 0..<mainPoolCount {
            let start = Int64(index) * chunkSize
            let end = min(start + chunkSize - 1, total - 1)
            let url = partFile(partDir, "part_\(index)")
            if fileSize(url) < end - start + 1 { pending.append(Pending(start: start, end: end, url: url)) }
        }
        if let segs = try? FileManager.default.contentsOfDirectory(at: partDir, includingPropertiesForKeys: [.fileSizeKey]) {
            for url in segs where url.lastPathComponent.hasPrefix("seg_") {
                guard let range = Self.segmentRange(url.lastPathComponent) else { continue }
                if fileSize(url) < range.end - range.start + 1 {
                    pending.append(Pending(start: range.start, end: range.end, url: url))
                }
            }
        }
        guard !pending.isEmpty else { return }

        // 并发领取游标：用 actor 而非 inout —— inout 参数不允许跨 await 传递。
        let cursor = IndexCursor()
        try await withThrowingTaskGroup(of: Void.self) { group in
            for _ in 0..<max(1, min(workers, pending.count)) {
                group.addTask { [weak self] in
                    guard let self = self else { return }
                    while true {
                        try Task.checkCancellation()
                        let index = await cursor.next()
                        if index >= pending.count { return }
                        let item = pending[index]
                        let acquired = await gate.acquire()
                        if acquired {
                            _ = try? await self.downloadChunk(id, start: item.start, end: item.end,
                                                              partURL: item.url, counter: counter, allocator: nil)
                            await gate.release()
                        }
                    }
                }
            }
            try await group.waitForAll()
        }
    }

    /// 从 `seg_<start>_<end>.part` 文件名解析区间。
    static func segmentRange(_ name: String) -> (start: Int64, end: Int64)? {
        guard name.hasPrefix("seg_") else { return nil }
        let body = name.dropFirst(4).replacingOccurrences(of: ".part", with: "")
        let parts = body.split(separator: "_")
        guard parts.count == 2, let start = Int64(parts[0]), let end = Int64(parts[1]) else { return nil }
        return (start, end)
    }

    private func fileSize(_ url: URL) -> Int64 {
        ((try? FileManager.default.attributesOfItem(atPath: url.path)[.size]) as? NSNumber)?.int64Value ?? 0
    }

    /// 断点续传起点：主池 part 按磁盘真实长度累加；弹性区按已完成前缀推进。
    private func restartSize(partDir: URL, mainPoolCount: Int, elasticStart: Int64, total: Int64) -> Int64 {
        var sum: Int64 = 0
        for index in 0..<mainPoolCount {
            sum += fileSize(partFile(partDir, "part_\(index)"))
        }
        if let urls = try? FileManager.default.contentsOfDirectory(at: partDir, includingPropertiesForKeys: [.fileSizeKey]) {
            for url in urls {
                guard let range = Self.segmentRange(url.lastPathComponent) else { continue }
                let expected = range.end - range.start + 1
                // 不完整的 seg 不能计入进度，也不能作为前缀（会错位），下面 seedAllocator 会删掉。
                if fileSize(url) >= expected { sum += expected }
            }
        }
        return min(sum, total)
    }

    /// 续传时把弹性区分配器推进到「已完成字节前缀」的末尾，并删除不完整的 seg（重下）。
    private func seedAllocator(_ allocator: ElasticAllocator, partDir: URL, elasticStart: Int64) {
        guard let urls = try? FileManager.default.contentsOfDirectory(at: partDir, includingPropertiesForKeys: [.fileSizeKey]) else { return }
        var ranges: [(start: Int64, end: Int64)] = []
        for url in urls {
            guard let range = Self.segmentRange(url.lastPathComponent) else { continue }
            let expected = range.end - range.start + 1
            if fileSize(url) < expected {
                try? FileManager.default.removeItem(at: url)
            } else {
                ranges.append(range)
            }
        }
        ranges.sort { $0.start < $1.start }
        var next = elasticStart
        for range in ranges {
            if range.start == next { next = range.end + 1 } else { break }
        }
        if next > elasticStart {
            Task { await allocator.skipTo(next) }
        }
    }

    /// 下载单个分片。返回三态结果；`allocator` 非空时把实测速度回注给弹性分配器。
    private func downloadChunk(_ id: UUID,
                               start: Int64,
                               end: Int64,
                               partURL: URL,
                               counter: ByteCounter,
                               allocator: ElasticAllocator?) async throws -> ChunkOutcome {
        guard let task = tasks[id] else { return .failed }
        let expected = end - start + 1
        if fileSize(partURL) >= expected { return .ok }

        // ★ 片内只做瞬时 IO 重试，不做指数退避：退避期间占着并发名额会让所有分片
        //   周期性集体停顿（原版注释里的“忽快忽慢”根源）。Range 被忽略立即返回上抛。
        var lastError: Error?
        for attempt in 0..<3 {
            try Task.checkCancellation()
            let existing = fileSize(partURL)
            if existing >= expected { return .ok }

            var request = URLRequest(url: task.url)
            request.httpMethod = "GET"
            request.setValue("bytes=\(start + existing)-\(end)", forHTTPHeaderField: "Range")
            task.headers.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }

            do {
                let (data, response) = try await session.data(for: request)
                guard let http = response as? HTTPURLResponse else { throw YunXError.invalidResponse }

                if http.statusCode == 206 {
                    // ★ 流式落盘：data 已由 URLSession 收完，这里只做追加写入与字节记账。
                    try append(data, to: partURL)
                    let written = fileSize(partURL)
                    let delta = max(0, written - existing)
                    if delta > 0 {
                        let total = await counter.add(delta)
                        update(id, persist: false) { item in
                            item.downloadedSize = item.totalSize > 0 ? min(total, item.totalSize) : total
                        }
                        // ★ 实时速度注入弹性分配器：块大小随真实吞吐自适应（IDM 式动态分片）。
                        if let allocator = allocator, let speed = speedSamples[id]?.smoothed, speed > 0 {
                            await allocator.setSpeed(Int64(speed))
                        }
                    }
                    if written >= expected { return .ok }
                    lastError = YunXError.server("分片下载长度不足")
                    continue
                }
                if http.statusCode == 200 {
                    // 服务器忽略 Range：不能把完整文件当成当前分片写入。
                    // 累计次数交给上层统计，偶发 200 不触发整任务回退。
                    return .rangeIgnored
                }
                if http.statusCode == 403 || http.statusCode == 404 {
                    throw YunXError.server("下载链接已失效（HTTP \(http.statusCode)），请重新解析后下载")
                }
                lastError = YunXError.server("服务器不支持断点 Range（HTTP \(http.statusCode)）")
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                lastError = error
            }
        }
        if let error = lastError as? YunXError, case .server(let message) = error,
           message.contains("已失效") {
            throw error
        }
        return .failed
    }

    private func append(_ data: Data, to url: URL) throws {
        if FileManager.default.fileExists(atPath: url.path) {
            let handle = try FileHandle(forWritingTo: url)
            defer { try? handle.close() }
            try handle.seekToEnd()
            try handle.write(contentsOf: data)
        } else {
            _ = FileManager.default.createFile(atPath: url.path, contents: nil)
            let handle = try FileHandle(forWritingTo: url)
            defer { try? handle.close() }
            try handle.write(contentsOf: data)
        }
    }

    private func downloadWhole(_ id: UUID, saveURL: URL) async throws {
        guard let task = tasks[id] else { return }
        var request = URLRequest(url: task.url)
        request.httpMethod = "GET"
        task.headers.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw YunXError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw YunXError.server("下载失败 HTTP \(http.statusCode)") }
        if http.value(forHTTPHeaderField: "Content-Type")?.contains("text/html") == true {
            throw YunXError.server("下载链接已失效或被防盗链拦截")
        }
        try data.write(to: saveURL, options: .atomic)
        update(id) { $0.downloadedSize = Int64(data.count); if $0.totalSize <= 0 { $0.totalSize = Int64(data.count) } }
    }

    /// 按 1MB 分块把主池分片 + 弹性区分片（按 start 升序）顺序写入目标文件。
    private func stitch(partDir: URL, mainPoolCount: Int, saveURL: URL, total: Int64) throws {
        var pieces: [URL] = (0..<mainPoolCount).map { partFile(partDir, "part_\($0)") }
        if let urls = try? FileManager.default.contentsOfDirectory(at: partDir, includingPropertiesForKeys: nil) {
            let segs = urls.compactMap { url -> (Int64, URL)? in
                guard let range = Self.segmentRange(url.lastPathComponent) else { return nil }
                return (range.start, url)
            }.sorted { $0.0 < $1.0 }
            pieces.append(contentsOf: segs.map { $0.1 })
        }

        if !FileManager.default.fileExists(atPath: saveURL.path) {
            _ = FileManager.default.createFile(atPath: saveURL.path, contents: nil)
        }
        let out = try FileHandle(forWritingTo: saveURL)
        defer { try? out.close() }
        try out.truncate(atOffset: 0)

        let bufferSize = 1 * 1024 * 1024
        var written: Int64 = 0
        for piece in pieces {
            guard FileManager.default.fileExists(atPath: piece.path) else { continue }
            let input = try FileHandle(forReadingFrom: piece)
            defer { try? input.close() }
            while true {
                let block = try input.read(upToCount: bufferSize) ?? Data()
                if block.isEmpty { break }
                try out.write(contentsOf: block)
                written += Int64(block.count)
            }
        }
        // 完整性校验：绝不保存截断/膨胀的文件。
        if total > 0, written != total {
            throw YunXError.server("文件校验失败：期望 \(total) 字节，实际 \(written) 字节")
        }
    }

    // MARK: - 速度统计

    private func beginSpeedSampling(_ id: UUID) {
        speedSamples[id] = SpeedSample(lastBytes: currentDownloadedSize(for: id), lastDate: Date(), smoothed: 0)
    }

    private func stopSpeedSampling(_ id: UUID, keepSpeed: Bool = false) {
        guard let sample = speedSamples[id] else { return }
        speedSamples[id] = nil
        if !keepSpeed {
            let speed = Int64(sample.smoothed)
            update(id) { $0.averageSpeed = speed }
        }
    }

    /// 由采样器定期调用，刷新实时速率。使用指数平滑避免数字剧烈跳动。
    private func sampleSpeed(_ id: UUID) {
        guard var sample = speedSamples[id], let task = tasks[id], task.status == .downloading else { return }
        let now = Date()
        let elapsed = now.timeIntervalSince(sample.lastDate)
        guard elapsed >= 0.2 else { return }
        let bytes = currentDownloadedSize(for: id)
        let delta = Double(max(0, bytes - sample.lastBytes))
        let instant = delta / elapsed
        sample.smoothed = sample.smoothed <= 0 ? instant : sample.smoothed * 0.6 + instant * 0.4
        sample.lastBytes = bytes
        sample.lastDate = now
        let speed = Int64(max(0, sample.smoothed))
        speedSamples[id] = sample
        // 高频进度更新不落盘：只要 UI 能读到最新值即可，减少 0.7s 一次的 JSON 写入。
        update(id, persist: false) { item in
            item.averageSpeed = speed
            let clamped = item.totalSize > 0 ? min(bytes, item.totalSize) : bytes
            item.downloadedSize = max(item.downloadedSize, clamped)
        }
    }

    private func currentDownloadedSize(for id: UUID) -> Int64 {
        guard let task = tasks[id] else { return 0 }
        let saveURL = URL(fileURLWithPath: task.savePath)
        let partDir = chunkDirectory(for: id, saveURL: saveURL)
        guard let urls = try? FileManager.default.contentsOfDirectory(at: partDir, includingPropertiesForKeys: [.fileSizeKey]) else { return task.downloadedSize }
        return urls.reduce(Int64(0)) { partial, url in
            partial + ((try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0)
        }
    }

    private func chunkDirectory(for id: UUID, saveURL: URL) -> URL {
        saveURL.deletingLastPathComponent().appendingPathComponent(".yunx-\(id.uuidString)", isDirectory: true)
    }

    private func destination(for name: String) -> (url: URL, path: String) {
        let base = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Downloads", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        let safe = name.replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "\0", with: "")
        let url = base.appendingPathComponent(safe)
        return (url, url.path)
    }

    private func update(_ id: UUID, persist shouldPersist: Bool = true, _ change: (inout DownloadTask) -> Void) {
        guard var task = tasks[id] else { return }
        change(&task)
        tasks[id] = task
        if shouldPersist { persist() }
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(tasks) { try? data.write(to: storeURL, options: .atomic) }
    }

    private static func readTasks(from url: URL) -> [UUID: DownloadTask] {
        guard let data = try? Data(contentsOf: url), let decoded = try? JSONDecoder().decode([UUID: DownloadTask].self, from: data) else { return [:] }
        return decoded
    }
}

// MARK: - 弹性区动态分片分配器（对齐原版 ElasticAllocator）

/// 弹性区分配器（IDM 式动态分片）。
///
/// 块太大会让尾部只剩少数几个大块 → 空闲线程空转（“最后一点特别慢”）；
/// 块太小会产生海量 Range 请求 → 拖慢快连接。故按 **实时速度自适应 + 尾部收缩**：
/// - 按字节顺序发块（物理相邻），保持连接复用；
/// - 起步块 = 主池 chunkSize；
/// - 稳定后块 ≈ 单 worker 下载 5 秒的量，夹在 [256KB, 4MB]；
/// - 尾部收缩：剩余 ≤ workers * 块 时压到 remaining / workers，下限 64KB。
private actor ElasticAllocator {
    struct Block { let start: Int64; let end: Int64 }

    private let total: Int64
    private let workers: Int
    private let chunkSize: Int64
    private var nextStart: Int64
    private var recentSpeedBps: Int64 = 0

    private static let minElasticBlock: Int64 = 256 * 1024
    private static let maxElasticBlock: Int64 = 4 * 1024 * 1024
    private static let minTailBlock: Int64 = 64 * 1024
    private static let targetSeconds: Int64 = 5

    init(total: Int64, elasticStart: Int64, workers: Int, chunkSize: Int64) {
        self.total = total
        self.workers = max(1, workers)
        self.chunkSize = chunkSize
        self.nextStart = elasticStart
    }

    func setSpeed(_ bytesPerSecond: Int64) {
        if bytesPerSecond > 0 { recentSpeedBps = bytesPerSecond }
    }

    func skipTo(_ start: Int64) {
        if start > nextStart { nextStart = start }
    }

    private func baseBlockSize() -> Int64 {
        let perWorker = recentSpeedBps / Int64(workers)
        if perWorker <= 0 { return min(max(chunkSize, Self.minElasticBlock), Self.maxElasticBlock) }
        let adaptive = perWorker * Self.targetSeconds
        return min(max(adaptive, Self.minElasticBlock), Self.maxElasticBlock)
    }

    func take() -> Block? {
        guard nextStart < total else { return nil }
        let remaining = total - nextStart
        let base = baseBlockSize()
        let block: Int64
        if remaining <= Int64(workers) * base {
            block = min(max(remaining / Int64(workers), Self.minTailBlock), base)
        } else {
            block = base
        }
        let start = nextStart
        let end = min(start + block - 1, total - 1)
        nextStart = end + 1
        return Block(start: start, end: end)
    }
}

/// 跨并发任务共享的已下载字节计数。
private actor ByteCounter {
    private var value: Int64
    init(value: Int64) { self.value = value }
    func add(_ delta: Int64) -> Int64 {
        value += delta
        return value
    }
    func current() -> Int64 { value }
}

/// 并发领取游标（主池片 / 重试区间）。用 actor 而不是 inout，因为 inout 不允许跨 await。
private actor IndexCursor {
    private var value = 0
    func next() -> Int { let v = value; value += 1; return v }
}

/// 简易并发闸门：限制同时进行的分片请求数量，避免一次性打出几百个连接。
/// `acquire()` 返回是否真正拿到了名额——被取消而退出的调用方不应调用 `release()`，
/// 否则会把不属于自己的名额转交出去，导致并发数失控。
private actor ConcurrencyGate {
    private let limit: Int
    private var running = 0
    /// 已挂起的等待者。key 是令牌，用于取消时精确定位。
    private var waiters: [UUID: CheckedContinuation<Bool, Never>] = [:]
    /// 已被取消、但 continuation 还没注册进来的令牌。
    /// 用于解决「取消先于注册」的竞态：否则 continuation 会永远挂起。
    private var cancelledBeforeWait: Set<UUID> = []

    init(limit: Int) {
        self.limit = max(1, limit)
    }

    func acquire() async -> Bool {
        if running < limit {
            running += 1
            return true
        }
        if Task.isCancelled { return false }
        let token = UUID()
        let acquired: Bool = await withTaskCancellationHandler {
            await withCheckedContinuation { continuation in
                Task { await self.registerWaiter(token: token, continuation: continuation) }
            }
        } onCancel: {
            Task { await self.cancelWaiter(token) }
        }
        return acquired
    }

    private func registerWaiter(token: UUID, continuation: CheckedContinuation<Bool, Never>) {
        // 若在注册前就被 cancelWaiter 标记过（取消先于注册），立刻以 false 唤醒，
        // 否则这个 continuation 会永远挂起。
        if cancelledBeforeWait.remove(token) != nil {
            continuation.resume(returning: false)
            return
        }
        waiters[token] = continuation
    }

    /// 名额转交：优先给排队最久的等待者，没有等待者才真正释放。
    func release() {
        if let token = waiters.keys.first, let next = waiters.removeValue(forKey: token) {
            // 名额直接转交，running 保持不变。
            next.resume(returning: true)
        } else {
            running = max(0, running - 1)
        }
    }

    private func cancelWaiter(_ token: UUID) {
        if let continuation = waiters.removeValue(forKey: token) {
            // 还在排队，从未占用名额 → 返回 false。
            continuation.resume(returning: false)
        } else {
            // continuation 尚未注册，打标记让 registerWaiter 直接放行。
            cancelledBeforeWait.insert(token)
        }
    }
}
