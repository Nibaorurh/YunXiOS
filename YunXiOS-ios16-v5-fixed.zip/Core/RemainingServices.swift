import Foundation
#if canImport(Security)
import Security
#endif

public struct C139Service: ShareResolver, Sendable {
    private let http: HTTPClient; public init(http: HTTPClient = .shared){self.http=http}
    private func encryptedBody(_ plain: String) throws -> String {
        #if canImport(CommonCrypto)
        let iv = Data((0..<16).map{_ in UInt8.random(in:0...255)}); let key=Data(C139Constants.aesKey.utf8); let ct=try CryptoSupport.aesCBCEncrypt(Data(plain.utf8),key:key,iv:iv); return (iv+ct).base64EncodedString()
        #else
        throw YunXError.unsupported("139 网盘加密接口需要 iOS CommonCrypto")
        #endif
    }
    private func requestShare(_ url:String, plain:String, authorization:String?=nil) async throws -> [String:Any] {
        let enc=try encryptedBody(plain); var r=try HTTPHelpers.request(url:url,method:"POST",headers:["hcy-cool-flag":"1","x-deviceinfo":"||3|12.27.0|||||chrome 150.0.0.0|360X444|zh-cn|||","x-huawei-channelsrc":"10245500","x-mm-source":"0002","Content-Type":"application/json;charset=UTF-8","User-Agent":"Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148","Origin":"https://yun.139.com","Referer":"https://yun.139.com/"]); if let authorization = authorization {r.setValue(authorization,forHTTPHeaderField:"Authorization")}; r.httpBody=Data(enc.utf8); r.setValue("application/json;charset=UTF-8",forHTTPHeaderField:"Content-Type"); let res=try await http.send(r); if let obj=try? JSONSerialization.jsonObject(with:res.data) as? [String:Any] { return obj }; throw YunXError.invalidResponse
    }
    public func createSession(parsed:ParsedShare,password:String?,credential:String) async throws -> ShareSession {
        var title="139分享"; var r=try JSONSerialization.data(withJSONObject:["getOutLinkGeneralReq":["linkID":parsed.shareID,"isPasswd":1,"account":""]]); let resp=try await requestShare(C139Constants.shareGeneralURL,plain:String(data:r,encoding:.utf8)!,authorization:nil); if let d=HTTPHelpers.dict(resp["data"])["getOutLinkGeneralResp"] as? [String:Any], let a=d["outLinkGeneral"] as? [[String:Any]], let first=a.first { title=HTTPHelpers.string(first["lkName"]) }; return ShareSession(shareID:parsed.shareID,token:password ?? parsed.password ?? "",title:title)
    }
    public func listFiles(session:ShareSession,parentID:String,credential:String) async throws -> [ShareFile] {
        let req:[String:Any]=["getOutLinkInfoReq":["account":"","linkID":session.shareID,"passwd":session.token,"caSrt":1,"coSrt":1,"srtDr":0,"bNum":1,"pCaID":parentID.isEmpty ? "root":parentID,"eNum":200]]; let data=try JSONSerialization.data(withJSONObject:req); let resp=try await requestShare(C139Constants.shareListURL,plain:String(data:data,encoding:.utf8)!,authorization:nil); let root=HTTPHelpers.dict(resp["data"]); var files:[ShareFile]=[]; for x in HTTPHelpers.arr(root["caLst"]) {files.append(ShareFile(fid:HTTPHelpers.string(x["caID"]),name:HTTPHelpers.string(x["caName"]),isDirectory:true,parentFID:parentID,modified:HTTPHelpers.string(x["udTime"])))}; for x in HTTPHelpers.arr(root["coLst"]) {files.append(ShareFile(fid:HTTPHelpers.string(x["coID"]),name:HTTPHelpers.string(x["coName"]),size:HTTPHelpers.int64(x["coSize"]),isDirectory:HTTPHelpers.bool(x["isdir"]) || HTTPHelpers.int64(x["coType"])==2,parentFID:parentID,modified:HTTPHelpers.string(x["udTime"])))}; return files
    }
    public func getDownloadLink(session: ShareSession, file: ShareFile, credential: String) async throws -> DownloadLink {
        let account = ""
        let inner: [String: Any] = [
            "account": account,
            "linkID": session.shareID,
            "coIDLst": ["item": [file.fid]],
            "commonAccountInfo": ["account": account, "accountType": 1]
        ]
        let req: [String: Any] = ["dlFromOutLinkReqV3": inner]
        let d = try JSONSerialization.data(withJSONObject: req)
        let resp = try await requestShare(C139Constants.shareLinkURL, plain: String(data: d, encoding: .utf8)!, authorization: nil)
        let root = HTTPHelpers.dict(resp["data"])
        guard let u = URL(string: HTTPHelpers.string(root["redrUrl"])) else { throw YunXError.server("139 获取下载链接失败") }
        let name = HTTPHelpers.string(root["fileName"]).isEmpty ? file.name : HTTPHelpers.string(root["fileName"])
        return DownloadLink(fid: file.fid, filename: name, url: u, size: HTTPHelpers.int64(root["coSize"]))
    }

}

public struct XunleiService: ShareResolver, Sendable {
    private let http: HTTPClient; public init(http:HTTPClient = .shared){self.http=http}
    private func req(_ url:String,token:String,deviceID:String,captcha:String,method:String="GET",body:Any?=nil) async throws -> [String:Any] { var r=try HTTPHelpers.request(url:url,method:method,headers:["User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36","Authorization":"Bearer \(token)","X-Device-Id":deviceID,"X-Client-Version":"8.31.0.9726","Origin":"https://pan.xunlei.com","Referer":"https://pan.xunlei.com/"]); if !captcha.isEmpty{r.setValue(captcha,forHTTPHeaderField:"X-Captcha-Token")}; if let body{try r.setJSON(body)}; let root=try JSONValue.object((try await http.send(r)).data); if let e=root["error"] as? String,!e.isEmpty{throw YunXError.server(HTTPHelpers.string(root["error_description"]).isEmpty ? e : HTTPHelpers.string(root["error_description"]))}; return HTTPHelpers.dict(root["data"]).isEmpty ? root : HTTPHelpers.dict(root["data"]) }
    public func createSession(parsed:ParsedShare,password:String?,credential:String) async throws -> ShareSession { guard !credential.isEmpty else{throw YunXError.notLoggedIn}; return ShareSession(shareID:parsed.shareID,token:password ?? parsed.password ?? "",title:"迅雷分享") }
    public func listFiles(session:ShareSession,parentID:String,credential:String) async throws -> [ShareFile] { let parts=credential.split(separator:"|",omittingEmptySubsequences:false).map(String.init); let token=parts.first ?? ""; let device=parts.count>1 ? parts[1] : UUID().uuidString.replacingOccurrences(of:"-",with:""); let captcha=parts.count>2 ? parts[2] : ""; var c=URLComponents(string:XunleiConstants.shareURL)!; c.queryItems=[URLQueryItem(name:"share_id",value:session.shareID),URLQueryItem(name:"pass_code",value:session.token),URLQueryItem(name:"limit",value:"100"),URLQueryItem(name:"page_token",value:""),URLQueryItem(name:"thumbnail_size",value:"SIZE_SMALL")]; let d=try await req(c.url!.absoluteString,token:token,deviceID:device,captcha:captcha); let status=HTTPHelpers.string(d["share_status"]); if status=="PASS_CODE_NEED" || status=="PASS_CODE_ERROR" || status=="PASS_CODE_EMPTY"{throw YunXError.server(status=="PASS_CODE_ERROR" ? "迅雷提取码错误":"请输入迅雷提取码")}; return HTTPHelpers.arr(d["files"]).map{x in ShareFile(fid:HTTPHelpers.string(x["id"]),name:HTTPHelpers.string(x["name"]),size:HTTPHelpers.int64(x["size"]),isDirectory:HTTPHelpers.string(x["kind"]).contains("folder"),parentFID:parentID)} }
    public func getDownloadLink(session:ShareSession,file:ShareFile,credential:String) async throws -> DownloadLink { let p=credential.split(separator:"|",omittingEmptySubsequences:false).map(String.init); let token=p.first ?? ""; let device=p.count>1 ? p[1] : ""; let captcha=p.count>2 ? p[2] : ""; let u="\(XunleiConstants.filesURL)/\(file.fid)?_magic=2021&usage=PLAY&thumbnail_size=SIZE_LARGE"; let d=try await req(u,token:token,deviceID:device,captcha:captcha); let links=HTTPHelpers.dict(d["links"]); let content=HTTPHelpers.dict(links["application/octet-stream"]); guard let url=URL(string:HTTPHelpers.string(content["url"])) else{throw YunXError.server("迅雷获取直链失败")}; return DownloadLink(fid:file.fid,filename:file.name,url:url,size:file.size) }
}

public actor CredentialStore {
    private var values: [String: String] = [:]
    private let service = "com.yunx.YunXiOS.credentials"

    public init(filename: String = "yunx-credentials") {
        #if canImport(Security)
        for platform in SharePlatform.allCases {
            if let value = Self.keychainGet(service: service, account: platform.rawValue) {
                values[platform.rawValue] = value
            }
        }
        #else
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        let url = base.appendingPathComponent("\(filename).json")
        if let data = try? Data(contentsOf: url), let decoded = try? JSONDecoder().decode([String:String].self, from: data) {
            values = decoded
        }
        #endif
    }

    public func set(_ key: String, _ value: String) {
        values[key] = value
        #if canImport(Security)
        Self.keychainSet(service: service, account: key, value: value)
        #else
        saveFallback()
        #endif
    }

    public func get(_ key: String) -> String? { values[key] }

    public func remove(_ key: String) {
        values.removeValue(forKey: key)
        #if canImport(Security)
        Self.keychainDelete(service: service, account: key)
        #else
        saveFallback()
        #endif
    }

    #if !canImport(Security)
    private func saveFallback() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let url = base.appendingPathComponent("yunx-credentials.json")
        if let data = try? JSONEncoder().encode(values) { try? data.write(to: url, options: .atomic) }
    }
    #endif

    #if canImport(Security)
    private static func keychainQuery(service: String, account: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: account]
    }

    private static func keychainGet(service: String, account: String) -> String? {
        var query = keychainQuery(service: service, account: account)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private static func keychainSet(service: String, account: String, value: String) {
        let query = keychainQuery(service: service, account: account)
        let data = Data(value.utf8)
        let attrs: [String: Any] = [kSecValueData as String: data,
                                     kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        if SecItemCopyMatching(query as CFDictionary, nil) == errSecSuccess {
            SecItemUpdate(query as CFDictionary, attrs as CFDictionary)
        } else {
            var item = query
            item.merge(attrs) { _, new in new }
            SecItemAdd(item as CFDictionary, nil)
        }
    }

    private static func keychainDelete(service: String, account: String) {
        let query = keychainQuery(service: service, account: account)
        SecItemDelete(query as CFDictionary)
    }
    #endif
}
