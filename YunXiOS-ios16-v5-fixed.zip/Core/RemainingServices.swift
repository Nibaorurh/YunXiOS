import Foundation
#if canImport(Security)
import Security
#endif

public struct C139Service: ShareResolver, Sendable {
    private let http: HTTPClient; public init(http: HTTPClient = .shared){self.http=http}
    private func encryptedBody(_ plain: String) throws -> String {
        #if canImport(CommonCrypto)
        let iv = Data((0..<16).map{_ in UInt8.random(in:0...255)}); let key=Data(C139Constants.aesKey.utf8); let ct=try CryptoSupport.aesCBCEncrypt(Data(plain.utf8),key:key,iv:iv); return (iv+ct).base64EncodedString()
        #else
        throw YunXError.unsupported("139 网盘加密接口需要 iOS CommonCrypto")
        #endif
    }
    private func requestShare(_ url:String, plain:String, authorization:String?=nil) async throws -> [String:Any] {
        let enc=try encryptedBody(plain); var r=try HTTPHelpers.request(url:url,method:"POST",headers:["hcy-cool-flag":"1","x-deviceinfo":"||3|12.27.0|||||chrome 150.0.0.0|360X444|zh-cn|||","x-huawei-channelsrc":"10245500","x-mm-source":"0002","Content-Type":"application/json;charset=UTF-8","User-Agent":"Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148","Origin":"https://yun.139.com","Referer":"https://yun.139.com/"]); if let authorization = authorization {r.setValue(authorization,forHTTPHeaderField:"Authorization")}; r.httpBody=Data(enc.utf8); r.setValue("application/json;charset=UTF-8",forHTTPHeaderField:"Content-Type"); let res=try await http.send(r); if let obj=try? JSONSerialization.jsonObject(with:res.data) as? [String:Any] { return obj }; throw YunXError.invalidResponse
    }
    public func createSession(parsed:ParsedShare,password:String?,credential:String) async throws -> ShareSession {
        var title="139分享"; var r=try JSONSerialization.data(withJSONObject:["getOutLinkGeneralReq":["linkID":parsed.shareID,"isPasswd":1,"account":""]]); let resp=try await requestShare(C139Constants.shareGeneralURL,plain:String(data:r,encoding:.utf8)!,authorization:nil); if let d=HTTPHelpers.dict(resp["data"])["getOutLinkGeneralResp"] as? [String:Any], let a=d["outLinkGeneral"] as? [[String:Any]], let first=a.first { title=HTTPHelpers.string(first["lkName"]) }; return ShareSession(shareID:parsed.shareID,token:password ?? parsed.password ?? "",title:title)
    }
    public func listFiles(session:ShareSession,parentID:String,credential:String) async throws -> [ShareFile] {
        let req:[String:Any]=["getOutLinkInfoReq":["account":"","linkID":session.shareID,"passwd":session.token,"caSrt":1,"coSrt":1,"srtDr":0,"bNum":1,"pCaID":parentID.isEmpty ? "root":parentID,"eNum":200]]; let data=try JSONSerialization.data(withJSONObject:req); let resp=try await requestShare(C139Constants.shareListURL,plain:String(data:data,encoding:.utf8)!,authorization:nil); let root=HTTPHelpers.dict(resp["data"]); var files:[ShareFile]=[]; for x in HTTPHelpers.arr(root["caLst"]) {files.append(ShareFile(fid:HTTPHelpers.string(x["caID"]),name:HTTPHelpers.string(x["caName"]),isDirectory:true,parentFID:parentID,modified:HTTPHelpers.string(x["udTime"])))}; for x in HTTPHelpers.arr(root["coLst"]) {files.append(ShareFile(fid:HTTPHelpers.string(x["coID"]),name:HTTPHelpers.string(x["coName"]),size:HTTPHelpers.int64(x["coSize"]),isDirectory:HTTPHelpers.bool(x["isdir"]) || HTTPHelpers.int64(x["coType"])==2,parentFID:parentID,modified:HTTPHelpers.string(x["udTime"])))}; return files
    }
    public func getDownloadLink(session: ShareSession, file: ShareFile, credential: String) async throws -> DownloadLink {
        let account = ""
        let inner: [String: Any] = [
            "account": account,
            "linkID": session.shareID,
            "coIDLst": ["item": [file.fid]],
            "commonAccountInfo": ["account": account, "accountType": 1]
        ]
        let req: [String: Any] = ["dlFromOutLinkReqV3": inner]
        let d = try JSONSerialization.data(withJSONObject: req)
        let resp = try await requestShare(C139Constants.shareLinkURL, plain: String(data: d, encoding: .utf8)!, authorization: nil)
        let root = HTTPHelpers.dict(resp["data"])
        guard let u = URL(string: HTTPHelpers.string(root["redrUrl"])) else { throw YunXError.server("139 获取下载链接失败") }
        let name = HTTPHelpers.string(root["fileName"]).isEmpty ? file.name : HTTPHelpers.string(root["fileName"])
        return DownloadLink(fid: file.fid, filename: name, url: u, size: HTTPHelpers.int64(root["coSize"]))
    }

}

extension C139Service: DriveBrowser {
    /// 个人云盘鉴权：浏览器里 `getDisk` 请求头 `Authorization` 是 `Basic xxx` 形式。
    /// 用户可能粘贴完整 Cookie 串或直接粘 JWT，这里统一抽出可用值。
    private func authHeader(_ credential: String) -> String {
        let trimmed = credential.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.contains("=") {
            for pair in trimmed.split(separator: ";") {
                let item = pair.trimmingCharacters(in: .whitespaces)
                guard let index = item.firstIndex(of: "=") else { continue }
                let name = String(item[..<index]).lowercased()
                if name == "authorization" {
                    let value = String(item[item.index(after: index)...]).trimmingCharacters(in: .whitespaces)
                    return value.hasPrefix("Basic ") || value.hasPrefix("Bearer ") ? value : "Basic \(value)"
                }
            }
            // Cookie 串里没有 authorization，退而用 ud_id 之类的账号标识拼一个。
            return ""
        }
        return trimmed.hasPrefix("Basic ") || trimmed.hasPrefix("Bearer ") ? trimmed : "Basic \(trimmed)"
    }

    private func driveRequest(_ url: String,
                              authorization: String,
                              method: String = "POST",
                              body: Any) async throws -> [String: Any] {
        var r = try HTTPHelpers.request(url: url, method: method, headers: [
            "Authorization": authorization,
            "hcy-cool-flag": C139Constants.hcyFlag,
            "x-deviceinfo": C139Constants.deviceInfo,
            "x-huawei-channelsrc": "10245500",
            "x-mm-source": "0002",
            "Content-Type": "application/json;charset=UTF-8",
            "User-Agent": C139Constants.clientUA,
            "Origin": "https://yun.139.com",
            "Referer": "https://yun.139.com/"
        ])
        try r.setJSON(body)
        let root = try JSONValue.object((try await http.send(r)).data)
        guard HTTPHelpers.string(root["code"]).isEmpty || HTTPHelpers.string(root["code"]) == "0" else {
            let message = HTTPHelpers.string(root["message"])
            if HTTPHelpers.string(root["code"]) == "401" || HTTPHelpers.string(root["code"]) == "403" {
                throw YunXError.auth(message.isEmpty ? "139 网盘登录状态已失效，请重新登录。" : message)
            }
            throw YunXError.server(message.isEmpty ? "139 网盘请求失败（code \(HTTPHelpers.string(root["code"]))）" : message)
        }
        return root
    }

    public func listDriveFiles(parentID: String, credential: String) async throws -> [ShareFile] {
        let authorization = authHeader(credential)
        guard !authorization.isEmpty else {
            throw YunXError.auth("139 网盘需要登录态（Authorization）。请在设置里登录 139 网盘并保存登录状态。")
        }
        var result: [ShareFile] = []
        var cursor = ""
        var page = 0
        while page < 100 {
            var body: [String: Any] = [
                "parentFileId": parentID.isEmpty ? C139Constants.rootCatalog : parentID,
                "size": 100,
                "sortBy": "file_name",
                "sortOrder": "asc",
                "imageThumbnailStyle": "1080x1920"
            ]
            if !cursor.isEmpty { body["cursor"] = cursor }
            let root = try await driveRequest(C139Constants.fileListURL, authorization: authorization, body: body)
            let data = HTTPHelpers.dict(root["data"])
            let batch = HTTPHelpers.arr(data["items"]).map { item in
                let type = HTTPHelpers.string(item["type"])
                return ShareFile(
                    fid: HTTPHelpers.string(item["fileId"]),
                    name: HTTPHelpers.string(item["name"]),
                    size: HTTPHelpers.int64(item["size"]),
                    isDirectory: type == "folder" || HTTPHelpers.bool(item["isdir"]),
                    parentFID: HTTPHelpers.string(item["parentFileId"]),
                    modified: HTTPHelpers.string(item["updateTime"])
                )
            }
            result.append(contentsOf: batch)
            cursor = HTTPHelpers.string(data["nextPageCursor"])
            page += 1
            if cursor.isEmpty || batch.count < 100 { break }
        }
        return result
    }

    public func getDriveDownloadLink(file: ShareFile, credential: String) async throws -> DownloadLink {
        let authorization = authHeader(credential)
        guard !authorization.isEmpty else {
            throw YunXError.auth("139 网盘需要登录态（Authorization），请重新登录。")
        }
        let root = try await driveRequest(C139Constants.downloadURL,
                                          authorization: authorization,
                                          body: ["fileId": file.fid])
        let data = HTTPHelpers.dict(root["data"])
        var raw = HTTPHelpers.string(data["downloadUrl"])
        if raw.isEmpty { raw = HTTPHelpers.string(data["url"]) }
        if raw.isEmpty { raw = HTTPHelpers.string(data["cdnUrl"]) }
        if raw.isEmpty {
            // 部分版本把直链放在 cdnUrl 的数组里。
            let urls = HTTPHelpers.arr(data["cdnUrl"])
            if let first = urls.first { raw = HTTPHelpers.string(first["url"]) }
        }
        guard let url = URL(string: raw), !raw.isEmpty else {
            throw YunXError.server("139 网盘没有返回下载链接。")
        }
        return DownloadLink(fid: file.fid,
                            filename: HTTPHelpers.string(data["fileName"]).isEmpty ? file.name : HTTPHelpers.string(data["fileName"]),
                            url: url,
                            size: HTTPHelpers.int64(data["fileSize"]) > 0 ? HTTPHelpers.int64(data["fileSize"]) : file.size,
                            headers: ["Referer": "https://yun.139.com/"])
    }
}

/// 迅雷凭据解析结果。
///
/// 迅雷有两个彼此独立的鉴权体系：
/// 1. **分享**：`token|deviceID|captcha`，走 `share_id + pass_code`；
/// 2. **个人盘**：登录后的 `access_token`（Web 端 localStorage 里的 `credentials.access_token`，
///    或请求头 `pan-auth`），走 `Authorization: Bearer`。
///
/// 网页登录（`pan.xunlei.com`）拿到的 Cookie 里可能同时含 `pan_auth` / `access_token` /
/// `deviceid`，这里统一抽成一个结构，个人盘接口按需取用。
struct XunleiCredential: Sendable {
    let accessToken: String
    let deviceID: String
    let captchaToken: String
    let space: String
    let clientID: String
    /// 是否为“分享场景”的三段式凭据。
    let isShareStyle: Bool

    var isEmpty: Bool { accessToken.isEmpty && !isShareStyle }

    /// 迅雷 Android 客户端 UA。个人盘接口对 UA 校验比分享接口更严。
    static func userAgent(clientID: String) -> String {
        return "ANDROID-com.xunlei.downloadprovider/8.31.0.9726 netlib/3.15.0 android/12 sdkVersion/512000"
    }

    static func parse(_ raw: String, http: HTTPClient) async -> XunleiCredential {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        // 形态一：分享三段式 token|device|captcha
        if trimmed.contains("|"), !trimmed.contains("=") {
            let parts = trimmed.split(separator: "|", omittingEmptySubsequences: false).map(String.init)
            let device = parts.count > 1 && !parts[1].isEmpty
                ? parts[1]
                : UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased()
            return XunleiCredential(accessToken: parts.first ?? "",
                                    deviceID: device,
                                    captchaToken: parts.count > 2 ? parts[2] : "",
                                    space: "",
                                    clientID: XunleiConstants.clientID,
                                    isShareStyle: true)
        }

        var token = ""
        var device = ""
        var captcha = ""
        var space = ""
        var client = XunleiConstants.clientID

        // 形态二：`key=value; key=value` 的 Cookie 串
        for pair in trimmed.split(separator: ";") {
            let item = pair.trimmingCharacters(in: .whitespaces)
            guard let index = item.firstIndex(of: "=") else { continue }
            let name = String(item[..<index]).trimmingCharacters(in: .whitespaces).lowercased()
            let value = String(item[item.index(after: index)...]).trimmingCharacters(in: .whitespaces)
            guard !value.isEmpty else { continue }
            switch name {
            case "pan_auth", "access_token", "accesstoken", "token", "authorization":
                if token.isEmpty { token = value.replacingOccurrences(of: "Bearer ", with: "") }
            case "deviceid", "x-device-id", "device_id":
                if device.isEmpty { device = value }
            case "x-captcha-token", "captchatoken", "captcha_token":
                if captcha.isEmpty { captcha = value }
            case "space", "device_space":
                if space.isEmpty { space = value }
            case "clientid", "client_id", "x-client-id":
                if client == XunleiConstants.clientID { client = value }
            default: break
            }
        }

        // Cookie 里没有 token 时，尝试用 Cookie 调一次会话接口，让服务端把 access_token 换出来。
        if token.isEmpty, !trimmed.isEmpty {
            if let exchanged = try? await Self.fetchAccessToken(cookie: trimmed, deviceID: device, http: http) {
                token = exchanged
            }
        }
        if device.isEmpty {
            device = UserDefaults.standard.string(forKey: "yunx.xunlei.deviceID")
                ?? UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased()
            UserDefaults.standard.set(device, forKey: "yunx.xunlei.deviceID")
        }
        return XunleiCredential(accessToken: token, deviceID: device, captchaToken: captcha,
                                space: space, clientID: client, isShareStyle: false)
    }

    /// 用网页 Cookie 换取个人盘 `access_token`。
    private static func fetchAccessToken(cookie: String, deviceID: String, http: HTTPClient) async throws -> String {
        let url = "\(XunleiConstants.panBase)/drive/v1/session"
        let request = try HTTPHelpers.request(url: url,
                                              cookie: cookie,
                                              headers: ["User-Agent": userAgent(clientID: XunleiConstants.clientID),
                                                        "Origin": "https://pan.xunlei.com",
                                                        "Referer": "https://pan.xunlei.com/"])
        let root = try JSONValue.object((try await http.send(request)).data)
        let direct = HTTPHelpers.string(root["access_token"])
        if !direct.isEmpty { return direct }
        return HTTPHelpers.string(HTTPHelpers.dict(root["data"])["access_token"])
    }

    /// 由 access_token 反查当前账号的 space（部分接口必须带上）。
    static func fetchSpace(accessToken: String, deviceID: String, clientID: String, http: HTTPClient) async throws -> String {
        var components = URLComponents(string: "\(XunleiConstants.panBase)/drive/v1/account/info")!
        components.queryItems = [URLQueryItem(name: "device_space", value: "")]
        var request = try HTTPHelpers.request(url: components.url!.absoluteString,
                                              headers: ["User-Agent": userAgent(clientID: clientID),
                                                        "Authorization": "Bearer \(accessToken)",
                                                        "X-Device-Id": deviceID,
                                                        "X-Client-Id": clientID,
                                                        "Origin": "https://pan.xunlei.com",
                                                        "Referer": "https://pan.xunlei.com/"])
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        let root = try JSONValue.object((try await http.send(request)).data)
        let spaces = HTTPHelpers.arr(root["device_spaces"])
        if let first = spaces.first(where: { HTTPHelpers.string($0["device_space"]).isEmpty == false }) {
            return HTTPHelpers.string(first["device_space"])
        }
        return HTTPHelpers.string(root["device_space"])
    }
}

public struct XunleiService: ShareResolver, Sendable {
    private let http: HTTPClient; public init(http:HTTPClient = .shared){self.http=http}
    private func req(_ url:String,token:String,deviceID:String,captcha:String,method:String="GET",body:Any?=nil) async throws -> [String:Any] { var r=try HTTPHelpers.request(url:url,method:method,headers:["User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36","Authorization":"Bearer \(token)","X-Device-Id":deviceID,"X-Client-Version":"8.31.0.9726","Origin":"https://pan.xunlei.com","Referer":"https://pan.xunlei.com/"]); if !captcha.isEmpty{r.setValue(captcha,forHTTPHeaderField:"X-Captcha-Token")}; if let body = body { try r.setJSON(body) }; let root=try JSONValue.object((try await http.send(r)).data); if let e=root["error"] as? String,!e.isEmpty{throw YunXError.server(HTTPHelpers.string(root["error_description"]).isEmpty ? e : HTTPHelpers.string(root["error_description"]))}; return HTTPHelpers.dict(root["data"]).isEmpty ? root : HTTPHelpers.dict(root["data"]) }
    public func createSession(parsed:ParsedShare,password:String?,credential:String) async throws -> ShareSession { guard !credential.isEmpty else{throw YunXError.notLoggedIn}; return ShareSession(shareID:parsed.shareID,token:password ?? parsed.password ?? "",title:"迅雷分享") }
    public func listFiles(session:ShareSession,parentID:String,credential:String) async throws -> [ShareFile] { let parts=credential.split(separator:"|",omittingEmptySubsequences:false).map(String.init); let token=parts.first ?? ""; let device=parts.count>1 ? parts[1] : UUID().uuidString.replacingOccurrences(of:"-",with:""); let captcha=parts.count>2 ? parts[2] : ""; var c=URLComponents(string:XunleiConstants.shareURL)!; c.queryItems=[URLQueryItem(name:"share_id",value:session.shareID),URLQueryItem(name:"pass_code",value:session.token),URLQueryItem(name:"limit",value:"100"),URLQueryItem(name:"page_token",value:""),URLQueryItem(name:"thumbnail_size",value:"SIZE_SMALL")]; let d=try await req(c.url!.absoluteString,token:token,deviceID:device,captcha:captcha); let status=HTTPHelpers.string(d["share_status"]); if status=="PASS_CODE_NEED" || status=="PASS_CODE_ERROR" || status=="PASS_CODE_EMPTY"{throw YunXError.server(status=="PASS_CODE_ERROR" ? "迅雷提取码错误":"请输入迅雷提取码")}; return HTTPHelpers.arr(d["files"]).map{x in ShareFile(fid:HTTPHelpers.string(x["id"]),name:HTTPHelpers.string(x["name"]),size:HTTPHelpers.int64(x["size"]),isDirectory:HTTPHelpers.string(x["kind"]).contains("folder"),parentFID:parentID)} }
    public func getDownloadLink(session:ShareSession,file:ShareFile,credential:String) async throws -> DownloadLink { let p=credential.split(separator:"|",omittingEmptySubsequences:false).map(String.init); let token=p.first ?? ""; let device=p.count>1 ? p[1] : ""; let captcha=p.count>2 ? p[2] : ""; let u="\(XunleiConstants.filesURL)/\(file.fid)?_magic=2021&usage=PLAY&thumbnail_size=SIZE_LARGE"; let d=try await req(u,token:token,deviceID:device,captcha:captcha); let links=HTTPHelpers.dict(d["links"]); let content=HTTPHelpers.dict(links["application/octet-stream"]); guard let url=URL(string:HTTPHelpers.string(content["url"])) else{throw YunXError.server("迅雷获取直链失败")}; return DownloadLink(fid:file.fid,filename:file.name,url:url,size:file.size) }
}

extension XunleiService: DriveBrowser {
    /// 个人盘请求。鉴权走 `Authorization: Bearer <access_token>`，
    /// 与分享接口使用的 `token|device|captcha` 三段式凭据不是同一套体系。
    private func personalRequest(_ url: String,
                                 credential: XunleiCredential,
                                 method: String = "GET",
                                 body: Any? = nil) async throws -> [String: Any] {
        var headers: [String: String] = [
            "User-Agent": XunleiCredential.userAgent(clientID: credential.clientID),
            "Authorization": "Bearer \(credential.accessToken)",
            "X-Device-Id": credential.deviceID,
            "X-Client-Id": credential.clientID,
            "Origin": "https://pan.xunlei.com",
            "Referer": "https://pan.xunlei.com/",
            "Accept": "application/json, text/plain, */*"
        ]
        if !credential.captchaToken.isEmpty {
            headers["X-Captcha-Token"] = credential.captchaToken
        }
        var request = try HTTPHelpers.request(url: url, method: method, headers: headers)
        if !credential.accessToken.isEmpty {
            request.setValue("Bearer \(credential.accessToken)", forHTTPHeaderField: "Authorization")
        }
        if let body = body { try request.setJSON(body) }
        let root = try JSONValue.object((try await http.send(request)).data)
        if let error = root["error"] as? String, !error.isEmpty {
            let description = HTTPHelpers.string(root["error_description"])
            if error == "invalid_token" || error == "unauthenticated" {
                throw YunXError.auth("迅雷登录状态已失效，请在设置里重新登录迅雷网盘。")
            }
            throw YunXError.server(description.isEmpty ? error : description)
        }
        if let code = root["code"] as? NSNumber, code.intValue != 0 {
            let message = HTTPHelpers.string(root["message"]).isEmpty ? HTTPHelpers.string(root["msg"]) : HTTPHelpers.string(root["message"])
            throw YunXError.server(message.isEmpty ? "迅雷请求失败（code \(code)）" : message)
        }
        return root
    }

    /// 解析出个人盘需要的 space，结果缓存复用，避免每次翻页都请求一次。
    private func resolveSpace(_ credential: XunleiCredential) async -> String {
        if !credential.space.isEmpty { return credential.space }
        let key = "yunx.xunlei.space.\(credential.deviceID)"
        if let cached = UserDefaults.standard.string(forKey: key), !cached.isEmpty { return cached }
        guard let space = try? await XunleiCredential.fetchSpace(accessToken: credential.accessToken,
                                                                 deviceID: credential.deviceID,
                                                                 clientID: credential.clientID,
                                                                 http: http),
              !space.isEmpty else { return "" }
        UserDefaults.standard.set(space, forKey: key)
        return space
    }

    public func listDriveFiles(parentID: String, credential: String) async throws -> [ShareFile] {
        let context = await XunleiCredential.parse(credential, http: http)
        if context.isShareStyle && context.accessToken.isEmpty {
            throw YunXError.auth("迅雷个人网盘需要登录态，分享用的凭据无法浏览个人网盘。请在“设置 → 迅雷 → 打开网盘官网登录并保存登录状态”里重新登录。")
        }
        guard !context.accessToken.isEmpty else {
            throw YunXError.auth("未能从迅雷登录状态中取得 access_token。请在设置里重新登录迅雷网盘后再试。")
        }
        let space = await resolveSpace(context)

        var result: [ShareFile] = []
        var pageToken = ""
        var page = 0
        while page < 100 {
            var components = URLComponents(string: XunleiConstants.filesURL)!
            var items = [
                URLQueryItem(name: "parent_id", value: parentID),
                URLQueryItem(name: "page_token", value: pageToken),
                URLQueryItem(name: "limit", value: "100"),
                URLQueryItem(name: "filters", value: XunleiConstants.personalFilters),
                URLQueryItem(name: "with_audit", value: "true"),
                URLQueryItem(name: "thumbnail_size", value: "SIZE_SMALL")
            ]
            if !space.isEmpty { items.insert(URLQueryItem(name: "space", value: space), at: 0) }
            components.queryItems = items

            let root = try await personalRequest(components.url!.absoluteString, credential: context)
            let files = HTTPHelpers.arr(root["files"])
            let batch = files.map { item in
                let kind = HTTPHelpers.string(item["kind"])
                return ShareFile(
                    fid: HTTPHelpers.string(item["id"]),
                    name: HTTPHelpers.string(item["name"]),
                    size: HTTPHelpers.int64(item["size"]),
                    isDirectory: kind.contains("folder"),
                    parentFID: HTTPHelpers.string(item["parent_id"]),
                    modified: HTTPHelpers.string(item["modified_time"])
                )
            }
            result.append(contentsOf: batch)
            pageToken = HTTPHelpers.string(root["next_page_token"])
            page += 1
            if pageToken.isEmpty || batch.count < 100 { break }
        }
        return result
    }

    public func getDriveDownloadLink(file: ShareFile, credential: String) async throws -> DownloadLink {
        let context = await XunleiCredential.parse(credential, http: http)
        guard !context.accessToken.isEmpty else {
            throw YunXError.auth("迅雷个人网盘需要登录态，请先在设置里重新登录迅雷网盘。")
        }
        let space = await resolveSpace(context)
        var components = URLComponents(string: "\(XunleiConstants.filesURL)/\(file.fid)")!
        var items = [
            URLQueryItem(name: "_magic", value: "2021"),
            URLQueryItem(name: "usage", value: "PLAY"),
            URLQueryItem(name: "thumbnail_size", value: "SIZE_LARGE")
        ]
        if !space.isEmpty { items.insert(URLQueryItem(name: "space", value: space), at: 0) }
        components.queryItems = items

        let root = try await personalRequest(components.url!.absoluteString, credential: context)
        let links = HTTPHelpers.dict(root["links"])
        var raw = HTTPHelpers.string(HTTPHelpers.dict(links["application/octet-stream"])["url"])
        if raw.isEmpty { raw = HTTPHelpers.string(root["web_content_link"]) }
        if raw.isEmpty {
            for (_, value) in links {
                let candidate = HTTPHelpers.string(HTTPHelpers.dict(value)["url"])
                if !candidate.isEmpty { raw = candidate; break }
            }
        }
        guard let url = URL(string: raw), !raw.isEmpty else {
            throw YunXError.server("迅雷没有返回可用的下载链接（可能该文件需要会员权限）。")
        }
        return DownloadLink(fid: file.fid,
                            filename: file.name,
                            url: url,
                            size: file.size,
                            headers: ["User-Agent": XunleiCredential.userAgent(clientID: context.clientID),
                                      "Referer": "https://pan.xunlei.com/"])
    }
}

public actor CredentialStore {
    private var values: [String: String] = [:]
    private let service = "com.yunx.YunXiOS.credentials"

    public init(filename: String = "yunx-credentials") {
        #if canImport(Security)
        for platform in SharePlatform.allCases {
            if let value = Self.keychainGet(service: service, account: platform.rawValue) {
                values[platform.rawValue] = value
            }
        }
        #else
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        let url = base.appendingPathComponent("\(filename).json")
        if let data = try? Data(contentsOf: url), let decoded = try? JSONDecoder().decode([String:String].self, from: data) {
            values = decoded
        }
        #endif
    }

    public func set(_ key: String, _ value: String) {
        values[key] = value
        #if canImport(Security)
        Self.keychainSet(service: service, account: key, value: value)
        #else
        saveFallback()
        #endif
    }

    public func get(_ key: String) -> String? { values[key] }

    public func remove(_ key: String) {
        values.removeValue(forKey: key)
        #if canImport(Security)
        Self.keychainDelete(service: service, account: key)
        #else
        saveFallback()
        #endif
    }

    #if !canImport(Security)
    private func saveFallback() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let url = base.appendingPathComponent("yunx-credentials.json")
        if let data = try? JSONEncoder().encode(values) { try? data.write(to: url, options: .atomic) }
    }
    #endif

    #if canImport(Security)
    private static func keychainQuery(service: String, account: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: account]
    }

    private static func keychainGet(service: String, account: String) -> String? {
        var query = keychainQuery(service: service, account: account)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private static func keychainSet(service: String, account: String, value: String) {
        let query = keychainQuery(service: service, account: account)
        let data = Data(value.utf8)
        let attrs: [String: Any] = [kSecValueData as String: data,
                                     kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        if SecItemCopyMatching(query as CFDictionary, nil) == errSecSuccess {
            SecItemUpdate(query as CFDictionary, attrs as CFDictionary)
        } else {
            var item = query
            item.merge(attrs) { _, new in new }
            SecItemAdd(item as CFDictionary, nil)
        }
    }

    private static func keychainDelete(service: String, account: String) {
        let query = keychainQuery(service: service, account: account)
        SecItemDelete(query as CFDictionary)
    }
    #endif
}
