import Foundation

public enum QuarkConstants {
    public static let ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) quark-cloud-drive/2.5.20 Chrome/100.0.4896.160 Electron/18.3.5.12-a038f7b798 Safari/537.36 Channel/pckk_other_ch"
    public static let apiBase = "https://drive-pc.quark.cn"
    public static let tokenURL = "\(apiBase)/1/clouddrive/share/sharepage/token?pr=ucpro&fr=pc"
    public static let detailURL = "\(apiBase)/1/clouddrive/share/sharepage/detail?pr=ucpro&fr=pc"
    public static let fileURL = "\(apiBase)/1/clouddrive/file?pr=ucpro&fr=pc"
    public static let sortURL = "\(apiBase)/1/clouddrive/file/sort?pr=ucpro&fr=pc"
    public static let saveURL = "\(apiBase)/1/clouddrive/share/sharepage/save?pr=ucpro&fr=pc"
    public static let taskURL = "\(apiBase)/1/clouddrive/task?pr=ucpro&fr=pc"
    public static let downloadURL = "\(apiBase)/1/clouddrive/file/download?pr=ucpro&fr=pc&sys=win32&ve=3.23.2"
    public static let deleteURL = "\(apiBase)/1/clouddrive/file/delete?pr=ucpro&fr=pc&uc_param_str="
    public static let configURL = "\(apiBase)/1/clouddrive/config?pr=ucpro&fr=pc"
    public static let defaultParent = "0"
    public static let tempName = "YunX临时转存"
    public static let refreshInterval: TimeInterval = 90 * 60
}

public enum UCConstants {
    public static let ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    public static let origin = "https://drive.uc.cn"
    public static let apiBase = "https://pc-api.uc.cn"
    public static let tokenURL = "\(apiBase)/1/clouddrive/share/sharepage/token?pr=UCBrowser&fr=pc"
    public static let detailURL = "\(apiBase)/1/clouddrive/share/sharepage/v2/detail?pr=UCBrowser&fr=pc"
    public static let fileURL = "\(apiBase)/1/clouddrive/file?pr=UCBrowser&fr=pc"
    public static let saveURL = "\(apiBase)/1/clouddrive/share/sharepage/save?pr=UCBrowser&fr=pc"
    public static let taskURL = "\(apiBase)/1/clouddrive/task?pr=UCBrowser&fr=pc"
    public static let downloadURL = "\(apiBase)/1/clouddrive/file/download?entry=ft&fr=pc&pr=UCBrowser"
    public static let defaultParent = "0"
    public static let tempName = "YunX临时转存"
}

public enum Pan123Constants {
    public static let apiBase = "https://yun.123pan.cn"
    public static let bApi = "\(apiBase)/b/api"
    public static let downloadBase = "https://www.123865.com"
    public static let shareURL = "\(apiBase)/b/api/share/get"
    public static let shareDownloadInfoURL = "\(downloadBase)/b/api/share/download/info"
    public static let fileListURL = "\(bApi)/file/list/new"
    public static let fileInfoURL = "\(bApi)/file/info"
    public static let fileDownloadInfoURL = "\(apiBase)/api/file/download_info"
    public static let trafficURL = "\(apiBase)/b/api/file/download/traffic/check"
    public static let signTable = Array("adefghlmyijnopkqrstubcvwsz")
}

public enum BaiduConstants {
    public static let uaWeb = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36"
    public static let uaDisk = "netdisk;8.0.1;android;"
    public static let appID = "250528"
}

public enum C139Constants {
    public static let shareBase = "https://share-kd-njs.yun.139.com"
    public static let shareListURL = "\(shareBase)/yun-share/richlifeApp/devapp/IOutLink/getOutLinkInfoV6"
    public static let shareLinkURL = "\(shareBase)/yun-share/richlifeApp/devapp/IOutLink/dlFromOutLinkV3"
    public static let shareGeneralURL = "\(shareBase)/yun-share/richlifeApp/devapp/IOutLink/getOutLinkGeneral"
    public static let aesKey = "PVGDwmcvfs1uV3d1"
    public static let cloudBase = "https://personal-kd-njs.yun.139.com"
    public static let fileListURL = "\(cloudBase)/hcy/file/list"
    public static let downloadURL = "\(cloudBase)/hcy/file/getDownloadUrl"
    public static let taskURL = "\(cloudBase)/hcy/task/get"
    /// 新个人云盘根目录标识。
    public static let rootCatalog = "/"
    /// 个人云盘请求所需的固定头。
    public static let clientUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36"
    public static let hcyFlag = "1"
    public static let deviceInfo = "||3|12.27.0|||||chrome 150.0.0.0|360X444|zh-cn|||"
}

public enum XunleiConstants {
    public static let panBase = "https://api-pan.xunlei.com"
    public static let filesURL = "\(panBase)/drive/v1/files"
    public static let shareURL = "\(panBase)/drive/v1/share"
    public static let shareDetailURL = "\(panBase)/drive/v1/share/detail"
    public static let restoreURL = "\(panBase)/drive/v1/share/restore"
    public static let tasksURL = "\(panBase)/drive/v1/tasks"
    public static let moveURL = "\(panBase)/drive/v1/files:batchMove"
    public static let trashURL = "\(panBase)/drive/v1/files:batchTrash"
    public static let clientID = "Xp6pAdwyJv9sQuoN"
    public static let clientSecret = "standard_a@api#"
    public static let tempName = "YunX临时转存"
    public static let uaMobile = "ANDROID-com.xunlei.downloadprovider/8.31.0.9726 netlib/3.15.0 android/12 sdkVersion/512000"
    /// 个人盘的过滤器：只保留已完成、未进回收站的对象。与官方 App 行为一致。
    public static let personalFilters =
        "%7B%22phase%22%3A%7B%22eq%22%3A%22PHASE_TYPE_COMPLETE%22%7D%2C%22trashed%22%3A%7B%22eq%22%3Afalse%7D%7D"
}
