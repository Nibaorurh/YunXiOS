import Foundation

public enum SharePlatform: String, Codable, CaseIterable, Identifiable, Hashable, Sendable {
    case quark = "夸克"
    case uc = "UC"
    case xunlei = "迅雷"
    case baidu = "百度"
    case c139 = "139"
    case pan123 = "123云盘"
    public var id: String { rawValue }
}

public struct ParsedShare: Codable, Sendable {
    public let shareID: String
    public let password: String?
    public let platform: SharePlatform
}

public struct ShareSession: Codable, Sendable {
    public let shareID: String
    public let token: String
    public let title: String
    public let firstFID: String?
    public init(shareID: String, token: String, title: String, firstFID: String? = nil) {
        self.shareID = shareID; self.token = token; self.title = title; self.firstFID = firstFID
    }
}

public struct ShareFile: Codable, Identifiable, Sendable {
    public let fid: String
    public let name: String
    public let size: Int64
    public let isDirectory: Bool
    public let parentFID: String
    public let fidToken: String
    public let modified: String
    public let path: String?
    public init(fid: String, name: String, size: Int64 = 0, isDirectory: Bool = false,
                parentFID: String = "", fidToken: String = "", modified: String = "", path: String? = nil) {
        self.fid = fid; self.name = name; self.size = size; self.isDirectory = isDirectory
        self.parentFID = parentFID; self.fidToken = fidToken; self.modified = modified; self.path = path
    }
    public var id: String { "\(fid)-\(isDirectory ? "d" : "f")" }
}

public struct DownloadLink: Codable, Identifiable, Sendable {
    public let fid: String
    public let filename: String
    public let url: URL
    public let size: Int64
    public let headers: [String: String]
    public let cleanupDirectoryFID: String?
    public init(fid: String, filename: String, url: URL, size: Int64 = 0,
                headers: [String: String] = [:], cleanupDirectoryFID: String? = nil) {
        self.fid = fid; self.filename = filename; self.url = url; self.size = size
        self.headers = headers; self.cleanupDirectoryFID = cleanupDirectoryFID
    }
    public var id: String { fid + filename }
}

public struct QuotaInfo: Codable, Sendable { public let used: Int64; public let total: Int64 }

public enum YunXError: LocalizedError, Sendable {
    case invalidURL, invalidResponse, server(String), notLoggedIn, unsupported(String), parsing(String), auth(String)
    public var errorDescription: String? {
        switch self {
        case .invalidURL: return "无效的链接"
        case .invalidResponse: return "服务器响应无效"
        case .server(let s), .parsing(let s), .auth(let s), .unsupported(let s): return s
        case .notLoggedIn: return "请先登录对应网盘账号"
        }
    }
}

public protocol DriveBrowser: Sendable {
    func listDriveFiles(parentID: String, credential: String) async throws -> [ShareFile]
    func getDriveDownloadLink(file: ShareFile, credential: String) async throws -> DownloadLink
}

public struct DownloadTask: Codable, Identifiable, Sendable {
    public enum Status: String, Codable, Sendable { case pending, downloading, paused, completed, failed }
    public let id: UUID
    public let url: URL
    public let filename: String
    public var totalSize: Int64
    public var downloadedSize: Int64
    public var status: Status
    public var error: String?
    public var savePath: String
    public var headers: [String: String]
    public var cleanupFID: String?
    public var platform: SharePlatform?
    public var averageSpeed: Int64
    public var createdAt: Date
    public init(id: UUID = UUID(), url: URL, filename: String, totalSize: Int64 = 0, downloadedSize: Int64 = 0,
                status: Status = .pending, error: String? = nil, savePath: String = "", headers: [String: String] = [:],
                cleanupFID: String? = nil, platform: SharePlatform? = nil, averageSpeed: Int64 = 0, createdAt: Date = .now) {
        self.id=id; self.url=url; self.filename=filename; self.totalSize=totalSize; self.downloadedSize=downloadedSize
        self.status=status; self.error=error; self.savePath=savePath; self.headers=headers; self.cleanupFID=cleanupFID
        self.platform=platform; self.averageSpeed=averageSpeed; self.createdAt=createdAt
    }
}
